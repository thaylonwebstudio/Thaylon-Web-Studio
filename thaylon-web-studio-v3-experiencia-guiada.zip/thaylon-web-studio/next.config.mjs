/**
 * Build modes
 * - Default: standard Next.js build (ideal for Vercel, Netlify, or any Node host).
 * - STATIC_EXPORT=true: outputs plain static files to /out for any static host
 *   (Cloudflare Pages, GitHub Pages, S3, shared hosting, etc.).
 */
const isStaticExport = process.env.STATIC_EXPORT === "true";

/** @type {import('next').NextConfig} */
const nextConfig = {
  reactStrictMode: true,
  poweredByHeader: false,
  trailingSlash: false,
  images: { unoptimized: isStaticExport },
  ...(isStaticExport ? { output: "export" } : {}),
};

export default nextConfig;
