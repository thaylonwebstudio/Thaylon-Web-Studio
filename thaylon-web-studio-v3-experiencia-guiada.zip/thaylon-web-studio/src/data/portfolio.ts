/**
 * Fictional demonstration projects.
 * IMPORTANT: every business below is a fictional concept created only to
 * demonstrate design capabilities. None of them is (or claims to be) a client.
 */

export type Project = {
  slug: string;
  name: string;
  category: string;
  industry: string;
  short: string;
  /** The project's objective, in one sentence. */
  goal: string;
  /** Why this kind of website helps this kind of business. */
  benefit: string;
  description: string;
  features: string[];
  goals: string[];
  /** Visual identity used by the portfolio thumbnail */
  theme: {
    bg: string;
    fg: string;
    accent: string;
    muted: string;
    fontVar: string;
    fontLabel: string;
    headline: string;
    nav: string[];
    cta: string;
    swatches: string[];
    darkArt?: boolean;
  };
};

export const projects: Project[] = [
  {
    slug: "bella-napoli",
    name: "Bella Napoli",
    category: "Restaurant",
    industry: "Restaurants & Pizzerias",
    short: "A warm, editorial website for a wood-fired Italian restaurant.",
    goal: "Make the menu easy to read on a phone and turn hungry visitors into reservation requests.",
    benefit: "Guests can check the menu, hours and directions before they arrive — and request a table in seconds.",
    description:
      "An appetite-first design built around the menu: an elegant serif type system, warm terracotta tones, an organized menu with dietary tags, a food gallery, and a simple reservation request.",
    features: ["Full menu with categories", "Food gallery", "Reservation request", "Location & hours", "Contact information"],
    goals: ["Make the menu easy to scan on a phone", "Turn visitors into reservation requests", "Show hours & directions instantly"],
    theme: {
      bg: "#1c1410",
      fg: "#f6ecdc",
      accent: "#d1492e",
      muted: "#bba68a",
      fontVar: "var(--font-playfair)",
      fontLabel: "Playfair Display",
      headline: "Wood-fired, the Neapolitan way.",
      nav: ["Menu", "Gallery", "Reserve"],
      cta: "Reserve a Table",
      swatches: ["#1c1410", "#d1492e", "#e9b872", "#f6ecdc"],
      darkArt: true,
    },
  },
  {
    slug: "freshhome-cleaning",
    name: "FreshHome Cleaning",
    category: "Cleaning Company",
    industry: "Cleaning Services",
    short: "A bright, trustworthy site for a residential cleaning company.",
    goal: "Explain cleaning packages and prices clearly, then collect detailed quote requests.",
    benefit: "Homeowners understand what's included and what it costs without a phone call, so the requests that come in are better informed.",
    description:
      "A friendly, high-clarity layout that answers the big questions fast: what's included, what it costs, and whether they serve your area — finished with a multi-field quote request form.",
    features: ["Cleaning services", "Service packages", "Quote request form", "Service areas", "Contact section"],
    goals: ["Explain packages without a phone call", "Collect detailed quote requests", "Build trust with clear policies"],
    theme: {
      bg: "#f3fbf8",
      fg: "#0f3d3e",
      accent: "#25b39a",
      muted: "#5b7d7b",
      fontVar: "var(--font-dmsans)",
      fontLabel: "DM Sans",
      headline: "A cleaner home, without the hassle.",
      nav: ["Services", "Pricing", "Areas"],
      cta: "Get a Free Quote",
      swatches: ["#0f3d3e", "#25b39a", "#f6b73c", "#f3fbf8"],
    },
  },
  {
    slug: "gentlemans-cut",
    name: "The Gentleman's Cut",
    category: "Barbershop",
    industry: "Barbershops",
    short: "A bold, classic barbershop brand with a premium feel.",
    goal: "Show services and prices at a glance and make it simple to request an appointment with a favorite barber.",
    benefit: "Clients see prices upfront and can pick their barber, which keeps the booking conversation short and easy.",
    description:
      "Condensed headlines, a deep charcoal palette and brass accents give this concept a classic-meets-modern attitude. Services and prices are front and center, with barber profiles and an appointment request.",
    features: ["Services", "Price list", "Barber profiles", "Appointment request", "Gallery"],
    goals: ["Show prices without friction", "Let clients choose their barber", "Fill the chair with appointment requests"],
    theme: {
      bg: "#151515",
      fg: "#f3efe7",
      accent: "#c9a24a",
      muted: "#9b958a",
      fontVar: "var(--font-oswald)",
      fontLabel: "Oswald",
      headline: "SHARP CUTS. CLASSIC SHAVES.",
      nav: ["Services", "Barbers", "Book"],
      cta: "Book a Chair",
      swatches: ["#151515", "#c9a24a", "#a7262b", "#f3efe7"],
      darkArt: true,
    },
  },
  {
    slug: "greenleaf-landscaping",
    name: "GreenLeaf Landscaping",
    category: "Landscaping",
    industry: "Landscaping & Gardening",
    short: "An earthy, organic site for a landscaping & garden design company.",
    goal: "Let before-and-after photos show the quality of the work and qualify leads by project type.",
    benefit: "Visual proof of past transformations helps homeowners picture their own yard — and the form asks the right questions upfront.",
    description:
      "A natural palette and soft serif headlines frame the work. Includes an interactive before-and-after slider, a project portfolio, service areas, and a quote request.",
    features: ["Landscaping services", "Before-and-after gallery", "Project portfolio", "Quote request", "Service areas"],
    goals: ["Let the transformations sell the service", "Qualify leads by project type", "Show the area served"],
    theme: {
      bg: "#f4f1e8",
      fg: "#1f3a24",
      accent: "#5d9a52",
      muted: "#6b7a64",
      fontVar: "var(--font-fraunces)",
      fontLabel: "Fraunces",
      headline: "Outdoor spaces, beautifully grown.",
      nav: ["Services", "Projects", "Quote"],
      cta: "Request a Quote",
      swatches: ["#1f3a24", "#5d9a52", "#f2c14e", "#f4f1e8"],
    },
  },
  {
    slug: "summit-roofing",
    name: "Summit Roofing",
    category: "Roofing Company",
    industry: "Roofing & Construction",
    short: "A strong, no-nonsense site for a residential roofing contractor.",
    goal: "Communicate reliability and make it easy to request a roofing estimate.",
    benefit: "Clear services, service areas and a simple estimate form help homeowners take the next step with confidence.",
    description:
      "Built to generate estimate requests: a confident industrial look, safety-orange highlights, a clear service breakdown, project gallery, service-area map and a short estimate form.",
    features: ["Roofing services", "Project gallery", "Estimate request", "Service areas", "Contact information"],
    goals: ["Generate estimate requests", "Communicate reliability", "Make the service area obvious"],
    theme: {
      bg: "#1b2130",
      fg: "#ffffff",
      accent: "#f28c28",
      muted: "#a9b2c3",
      fontVar: "var(--font-archivo)",
      fontLabel: "Archivo",
      headline: "Roofs built to weather anything.",
      nav: ["Services", "Projects", "Estimate"],
      cta: "Free Estimate",
      swatches: ["#1b2130", "#f28c28", "#b9c8d6", "#ffffff"],
      darkArt: true,
    },
  },
  {
    slug: "elite-auto-detailing",
    name: "Elite Auto Detailing",
    category: "Auto Detailing",
    industry: "Automotive Services",
    short: "A sleek, high-gloss site for a mobile detailing business.",
    goal: "Present detailing packages clearly and let customers estimate a price before booking.",
    benefit: "An instant price estimate removes guesswork and helps customers choose the package that fits their car and budget.",
    description:
      "Black, chrome and electric blue communicate precision. Packages are compared side by side, with an add-on menu, vehicle gallery and booking request.",
    features: ["Service packages", "Vehicle gallery", "Booking request", "Pricing", "Contact information"],
    goals: ["Upsell premium packages", "Simplify booking requests", "Look as polished as the cars"],
    theme: {
      bg: "#07080a",
      fg: "#f5f7fa",
      accent: "#3da9fc",
      muted: "#8a93a3",
      fontVar: "var(--font-bebas)",
      fontLabel: "Bebas Neue",
      headline: "SHOWROOM SHINE. EVERY TIME.",
      nav: ["Packages", "Gallery", "Book"],
      cta: "Book a Detail",
      swatches: ["#07080a", "#3da9fc", "#9aa3ad", "#f5f7fa"],
      darkArt: true,
    },
  },
  {
    slug: "luxe-beauty",
    name: "Luxe Beauty Studio",
    category: "Beauty Salon",
    industry: "Hair & Beauty Salons",
    short: "A soft, elegant site for a boutique hair & beauty studio.",
    goal: "Feel premium from the first second and make services easy to browse by category.",
    benefit: "Organized service menus and a calm design reflect the salon experience and invite appointment requests.",
    description:
      "Blush neutrals, generous whitespace and a refined serif create a calm, luxurious atmosphere. Tabbed services and prices, a gallery, location, and an appointment request.",
    features: ["Services", "Price list", "Gallery", "Appointment request", "Location"],
    goals: ["Feel premium from the first second", "Make prices easy to browse", "Encourage appointment requests"],
    theme: {
      bg: "#faf5f1",
      fg: "#3b2a26",
      accent: "#b07466",
      muted: "#8b7670",
      fontVar: "var(--font-cormorant)",
      fontLabel: "Cormorant Garamond",
      headline: "Beauty, thoughtfully crafted.",
      nav: ["Services", "Gallery", "Visit"],
      cta: "Book Appointment",
      swatches: ["#3b2a26", "#b07466", "#ead6cc", "#faf5f1"],
    },
  },
  {
    slug: "proflow-plumbing",
    name: "ProFlow Plumbing",
    category: "Plumbing Company",
    industry: "Plumbing & Home Services",
    short: "A high-trust, high-urgency site for a local plumbing company.",
    goal: "Help urgent visitors reach the plumber fast and confirm the company serves their area.",
    benefit: "A prominent call button and a ZIP code check help people with an urgent problem act quickly.",
    description:
      "Designed for the moment something goes wrong: an emergency call bar, fast-scanning service cards, service areas and an estimate request — plus a reviews layout shown with clearly labeled sample content.",
    features: ["Services", "Emergency contact CTA", "Service areas", "Estimate request", "Reviews section (sample content)"],
    goals: ["Convert urgent visitors", "Explain services clearly", "Build trust with a reviews layout"],
    theme: {
      bg: "#ffffff",
      fg: "#0b1f44",
      accent: "#1d4ed8",
      muted: "#5a6a85",
      fontVar: "var(--font-archivo)",
      fontLabel: "Archivo",
      headline: "Fast, honest plumbing — day or night.",
      nav: ["Services", "Areas", "Estimate"],
      cta: "Request Service",
      swatches: ["#0b1f44", "#1d4ed8", "#f97316", "#e6f0ff"],
    },
  },
  {
    slug: "urban-goods",
    name: "Urban Goods",
    category: "Retail Store",
    industry: "Local Retail",
    short: "A modern catalog site for an independent home-goods shop.",
    goal: "Showcase products beautifully and bring more visitors into the physical store.",
    benefit: "A filterable catalog lets shoppers browse from home, then visit the store knowing what they want.",
    description:
      "A gallery-like catalog with category filters, product cards and store information. Built so a local shop can showcase products online without a full e-commerce system.",
    features: ["Product catalog", "Product cards", "Category filters", "Store information", "Contact details"],
    goals: ["Showcase products beautifully", "Drive foot traffic to the store", "Keep it simple to update"],
    theme: {
      bg: "#efe9df",
      fg: "#1f1d1a",
      accent: "#a95a30",
      muted: "#7a7166",
      fontVar: "var(--font-grotesk)",
      fontLabel: "Space Grotesk",
      headline: "Good things for everyday living.",
      nav: ["Shop", "Categories", "Visit"],
      cta: "Browse the Shop",
      swatches: ["#1f1d1a", "#a95a30", "#2d3b36", "#efe9df"],
    },
  },
];

export const getProject = (slug: string) => projects.find((p) => p.slug === slug);
