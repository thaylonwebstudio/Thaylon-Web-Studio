/**
 * Editable site content. Plain US English, no jargon.
 * Nothing here promises specific results (rankings, sales, number of customers).
 */

export type Service = {
  id: string;
  title: string;
  icon: "PenTool" | "Smartphone" | "Building2" | "MousePointerClick" | "MessageSquare" | "Search" | "ShieldCheck" | "Puzzle";
  /** One-line summary used on cards. */
  summary: string;
  what: string;
  forWho: string;
  helps: string;
  includes: string[];
  /** Optional demo slug that shows this service in action. */
  example?: string;
  /** Optional "learn more" link. */
  link?: { label: string; href: string };
};

export const services: Service[] = [
  {
    id: "design",
    title: "Custom Website Design",
    icon: "PenTool",
    summary: "A website designed around your business — not a template with your logo dropped in.",
    what: "We design the look and layout of your website from scratch: colors, fonts, photos and page structure that fit your brand and the kind of customers you serve. Already have a website that feels outdated? We can redesign it, too.",
    forWho: "Businesses launching their first website, and owners whose current site no longer reflects the quality of their work.",
    helps: "A thoughtful design helps visitors quickly understand what you do, makes your business look established, and guides people toward calling or contacting you.",
    includes: ["Custom design based on your brand", "Clear calls to action", "Redesigns of existing websites", "Two revision rounds per package"],
    example: "luxe-beauty",
  },
  {
    id: "responsive",
    title: "Responsive Development",
    icon: "Smartphone",
    summary: "Your site looks right and works smoothly on phones, tablets and computers.",
    what: "“Responsive” simply means the website adjusts to any screen. We build and test every page on phones first, then tablets and desktops, so buttons are easy to tap and text is easy to read.",
    forWho: "Every business — many local customers look you up on their phone, often while they're on the go.",
    helps: "Visitors can find your hours, call you or request a quote in a couple of taps, instead of pinching and zooming.",
    includes: ["Mobile-first layouts", "Tap-to-call and tap-to-email buttons", "Tested on phone, tablet and desktop", "Fast, lightweight pages"],
    example: "proflow-plumbing",
  },
  {
    id: "business-websites",
    title: "Business Websites",
    icon: "Building2",
    summary: "Complete multi-page websites with room for your services, gallery, about page and more.",
    what: "A full website with separate pages for the things customers want to know: services, prices or menu, photos of your work, your story and how to reach you.",
    forWho: "Established local businesses — restaurants, salons, contractors, cleaning and home-service companies.",
    helps: "Gives you a professional home online where customers can learn about you at their own pace and feel confident choosing you.",
    includes: ["Up to 5 pages (Professional) or 8 pages (Business)", "Image gallery (Business)", "Social media links", "Contact form"],
    example: "summit-roofing",
    link: { label: "Compare packages", href: "/pricing" },
  },
  {
    id: "landing-pages",
    title: "Landing Pages",
    icon: "MousePointerClick",
    summary: "One focused page for a single service, offer or goal.",
    what: "A landing page is a single page built around one clear goal — for example, getting quote requests for a new service or promoting a seasonal offer.",
    forWho: "New businesses, single-service providers, or anyone who wants a simple, polished page to share.",
    helps: "Keeps the message simple so visitors know exactly what you offer and what to do next.",
    includes: ["One-page website (Starter package)", "Contact or quote form", "Click-to-call button", "Basic on-page SEO"],
    example: "freshhome-cleaning",
  },
  {
    id: "contact-forms",
    title: "Contact Forms",
    icon: "MessageSquare",
    summary: "Easy forms that let customers ask for a quote, a table or an appointment.",
    what: "Forms that collect the details you actually need — like service type, ZIP code or preferred date — and send the request to you.",
    forWho: "Businesses that get inquiries by phone today and want an easier option for customers who prefer to write.",
    helps: "Customers can reach you any time, even after hours, and you get organized requests instead of missed calls.",
    includes: ["Basic contact form (all packages)", "Advanced forms with extra fields (Business)", "Spam protection", "Clear confirmation messages"],
    example: "elite-auto-detailing",
  },
  {
    id: "seo",
    title: "Basic SEO",
    icon: "Search",
    summary: "The search-engine basics, done right from day one.",
    what: "SEO (search engine optimization) is how search engines understand your website. We set up the fundamentals: page titles, descriptions, headings, image descriptions, a sitemap and fast loading.",
    forWho: "Every business that wants its website to be easy for search engines to read.",
    helps: "A clean foundation makes it easier for search engines to understand your site. Rankings depend on many factors we don't control, so we never guarantee positions on Google.",
    includes: ["Page titles and descriptions", "Search-friendly headings and structure", "Sitemap", "Fast, mobile-friendly pages"],
  },
  {
    id: "maintenance",
    title: "Website Maintenance",
    icon: "ShieldCheck",
    summary: "Optional monthly care so your website keeps working while you run your business.",
    what: "After launch, a website still needs a little attention: checking that forms work, fixing small issues and updating things like prices, hours or photos.",
    forWho: "Owners who'd rather not deal with the technical side, or whose information changes from time to time.",
    helps: "Keeps your information current and your site working, within clear monthly limits — so there are no surprise bills.",
    includes: ["Monthly technical checks", "Small fixes and content updates (by plan)", "Email support", "Plans from $29/month"],
    link: { label: "See maintenance plans", href: "/maintenance" },
  },
  {
    id: "integrations",
    title: "Additional Integrations",
    icon: "Puzzle",
    summary: "Connect tools you already use, like booking, maps or social media.",
    what: "We can connect your website with outside tools — for example a map, your social profiles, an online booking service or a newsletter sign-up.",
    forWho: "Businesses that already use (or want to use) a specific tool and want it to work with their website.",
    helps: "Customers can take the next step — book, follow or find you — without leaving your website.",
    includes: ["Simple integrations (Business package)", "Larger integrations quoted separately", "Third-party fees are listed upfront", "Advice on what you really need"],
    example: "bella-napoli",
  },
];

/** What a professional website can do — honest possibilities, no guarantees. */
export const benefits = [
  { title: "Explain what you offer", body: "Your services, prices or menu in one clear place, ready to share any time." },
  { title: "Look credible from the first click", body: "A polished site helps new customers feel comfortable choosing you." },
  { title: "Make it easy to get in touch", body: "Tap-to-call buttons and simple forms, day or night." },
  { title: "Show your work and products", body: "Photos, galleries and catalogs that let your work speak for itself." },
  { title: "Share important information", body: "Hours, service areas, specials and updates, always current." },
  { title: "Be easier to find in search", body: "A solid SEO foundation helps search engines understand your site." },
  { title: "Give visitors a better experience", body: "Fast, easy-to-use pages on any device." },
];

export const reasons = [
  {
    title: "Fair, transparent pricing",
    body: "Clear packages starting at $299, written estimates, and no surprise invoices. You'll know the cost before any work starts.",
  },
  {
    title: "Custom design — not a template",
    body: "Every site is designed around your business, your customers and your brand, so you don't look like everyone else.",
  },
  {
    title: "Built mobile-first",
    body: "Many of your customers will find you on a phone. We design and test for small screens first, then scale up.",
  },
  {
    title: "Direct communication",
    body: "You work directly with the person designing and building your site. Straight answers, plain English, no account managers.",
  },
  {
    title: "Fast and search-friendly",
    body: "Lightweight, modern code with solid on-page SEO fundamentals, so your site loads quickly and is easy for search engines to read.",
  },
  {
    title: "You own your website",
    body: "Once the project is paid in full, the website is yours — including the files and access to your accounts.",
  },
];

/** "From the First Conversation to Launch" — shared by Home, Services and Pricing. */
export const processSteps = [
  {
    title: "Tell Us About Your Business",
    short: "Tell us about your business",
    body: "Fill out a short form about your business and what you'd like to build. A rough idea is perfectly fine.",
  },
  {
    title: "Get a Clear Estimate",
    short: "Receive a clear project estimate",
    body: "We review your request and send a written estimate with the scope, price and estimated timeline. No obligation.",
  },
  {
    title: "Build and Review",
    short: "Review your website",
    body: "Once you approve the estimate and the agreed deposit is paid, we design and build your site and share it with you for review.",
  },
  {
    title: "Your Feedback Matters",
    short: "Approve the final version",
    body: "You tell us what to change. Every package includes two revision rounds, so the final version feels right to you.",
  },
  {
    title: "Launch with Confidence",
    short: "Launch your new website",
    body: "After your final approval, we publish the website, help connect your domain and hand everything over to you.",
  },
];

export const faqs = [
  {
    q: "How does the website design process work?",
    a: "It happens in five steps: you tell us about your business, we send a written estimate, we build your site after you approve it and the deposit is paid, you review it (two revision rounds are included), and we launch it after your final approval. Everything is handled online, by email and, if you like, a video call.",
  },
  {
    q: "How much does a website cost?",
    a: "Our packages are $299 (Starter, one page), $499 (Professional, up to five pages) and $699 (Business, up to eight pages). These are one-time prices for design and development. Custom features, hosting, a domain name and third-party services can add costs, and we always list them in your estimate before any work begins.",
  },
  {
    q: "Do I own my website?",
    a: "Yes. Once the project is paid in full, you own the website design and the content we created for you, and we hand over access to the files and accounts. Third-party tools, fonts or services stay subject to their own licenses.",
  },
  {
    q: "Who pays for the domain and hosting?",
    a: "Hosting and the domain name are not included in package prices. Usually you register them in your own name, so you stay in control, and we help you set them up. If you'd rather have us manage them, we can agree on that in your estimate. Either way, they are recurring costs: a .com domain usually costs around $10–$25 per year from a registrar, and many small business sites can run on free or low-cost hosting plans. We don't offer a “free domain forever.”",
  },
  {
    q: "Can I request changes?",
    a: "Yes. Every package includes two revision rounds. A round is one list of changes sent together. Extra rounds, or changes that substantially alter an approved design, are quoted in advance so there are no surprises.",
  },
  {
    q: "Will my website work on mobile devices?",
    a: "Yes. Every website is designed mobile-first and tested on phones, tablets and desktop computers before launch.",
  },
  {
    q: "Can I update my website later?",
    a: "Yes. You can request one-time updates, which we quote individually, or choose an optional monthly care plan that includes a set amount of updates each month.",
  },
  {
    q: "Do you offer ongoing maintenance?",
    a: "Yes, optionally. Plans start at $29/month (Basic Care), with Standard Care at $59/month and Premium Care at $99/month. Each plan has clear monthly limits. New features and redesigns are quoted separately.",
  },
  {
    q: "How do payments work?",
    a: "We typically ask for a 50% deposit to begin and the remaining 50% before the site goes live. Maintenance plans are billed monthly. Exact payment details are confirmed in your written estimate.",
  },
  {
    q: "What happens after I submit a quote request?",
    a: "We read your request personally and reply by email, usually within 1–2 business days. If something is unclear, we'll ask a question or two. Then you receive a written estimate. You're under no obligation to move forward.",
  },
  {
    q: "How long does it take to build my website?",
    a: "Most Starter websites take about 5–7 business days, Professional websites 1–2 weeks and Business websites 2–3 weeks. The clock starts once we have your content (text, logo, photos) and the deposit.",
  },
  {
    q: "What do I need to provide?",
    a: "Your logo (if you have one), photos of your work or business, and basic information like services, prices and hours. Not sure what to write? We'll send a simple questionnaire and can help organize and polish your text.",
  },
];

export const industries = [
  "Restaurants", "Pizzerias", "Coffee Shops", "Cleaning Companies", "Landscaping", "Gardening Services",
  "Barbershops", "Hair Salons", "Roofing", "Construction", "Plumbing", "Electricians",
  "Auto Detailing", "Car Repair", "Local Retail", "Professional Services",
];
