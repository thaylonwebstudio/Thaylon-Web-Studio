export type Plan = {
  id: string;
  name: string;
  price: string;
  cadence: string;
  tagline: string;
  bestFor: string;
  features: string[];
  featured?: boolean;
  timeline?: string;
};

export const websitePlans: Plan[] = [
  {
    id: "starter",
    name: "Starter Website",
    price: "$299",
    cadence: "one-time",
    tagline: "A polished one-page site to get your business online fast.",
    bestFor: "New businesses, side businesses, single-service providers",
    timeline: "Typically 5–7 business days after content is received",
    features: [
      "One-page website",
      "Custom visual design",
      "Responsive layout (phone, tablet, desktop)",
      "Click-to-call & email contact buttons",
      "Basic contact form",
      "Basic on-page SEO",
      "Two revision rounds",
    ],
  },
  {
    id: "professional",
    name: "Professional Website",
    price: "$499",
    cadence: "one-time",
    tagline: "A complete multi-page site for an established local business.",
    bestFor: "Restaurants, salons, cleaning & home-service companies",
    timeline: "Typically 1–2 weeks after content is received",
    featured: true,
    features: [
      "Up to five pages",
      "Custom design",
      "Responsive layout",
      "Contact form",
      "Social media integration",
      "Basic SEO",
      "Two revision rounds",
    ],
  },
  {
    id: "business",
    name: "Business Website",
    price: "$699",
    cadence: "one-time",
    tagline: "More pages, richer visuals and smarter forms for growing businesses.",
    bestFor: "Contractors, multi-service companies, growing brands",
    timeline: "Typically 2–3 weeks after content is received",
    features: [
      "Up to eight pages",
      "Advanced visual design",
      "Responsive layout",
      "Image gallery",
      "Advanced contact forms",
      "Simple external integrations",
      "Basic SEO",
      "Two revision rounds",
    ],
  },
];

export const maintenancePlans: Plan[] = [
  {
    id: "basic-care",
    name: "Basic Care",
    price: "$29",
    cadence: "/month",
    tagline: "Peace of mind that your site is up and working.",
    bestFor: "Sites that rarely change",
    features: [
      "Basic website monitoring",
      "Monthly technical check (links, forms, mobile display)",
      "Small technical corrections — up to 30 minutes/month",
      "Email support — reply within 3 business days",
    ],
  },
  {
    id: "standard-care",
    name: "Standard Care",
    price: "$59",
    cadence: "/month",
    tagline: "Keep your content fresh without lifting a finger.",
    bestFor: "Menus, prices or hours that change now and then",
    featured: true,
    features: [
      "Everything in Basic Care",
      "Small content updates — up to 1 hour/month",
      "Minor visual changes (text, images, colors)",
      "Backup monitoring where your hosting supports it",
      "Email support — reply within 2 business days",
    ],
  },
  {
    id: "premium-care",
    name: "Premium Care",
    price: "$99",
    cadence: "/month",
    tagline: "A dedicated web partner for busy businesses.",
    bestFor: "Businesses that update their site regularly",
    features: [
      "Everything in Standard Care",
      "Additional content updates — up to 3 hours/month total",
      "Priority support — reply within 1 business day",
      "Monthly website performance report",
    ],
  },
];

export const pricingNote =
  "Custom functionality, e-commerce systems, advanced booking integrations, hosting, domain registration, and third-party services may require additional costs.";

export const maintenanceLimits = [
  "Included time is per calendar month and does not roll over.",
  "“Content updates” means editing existing pages: text, images, prices, hours, menu items and similar.",
  "New pages, new features, redesigns and new integrations are quoted separately before any work begins.",
  "Support is provided by email during business days (Monday–Friday, U.S. holidays excluded).",
  "Monitoring and backups depend on what your hosting provider supports; hosting fees are not included.",
  "Plans are month-to-month and can be canceled with 30 days’ notice.",
];
