import type { Metadata } from "next";
import { notFound } from "next/navigation";
import { getProject, projects } from "@/data/portfolio";
import { demoComponents } from "@/demos";
import { DemoBanner, DemoCTA } from "@/demos/shared";
import { AGENCY_NAME } from "@/config/site";

export const dynamicParams = false;

export function generateStaticParams() {
  return projects.map((p) => ({ slug: p.slug }));
}

export async function generateMetadata({ params }: { params: Promise<{ slug: string }> }): Promise<Metadata> {
  const { slug } = await params;
  const project = getProject(slug);
  if (!project) return {};
  const title = `${project.name} — ${project.category} Website Design Demo`;
  const description = `${project.short} A fictional demo project by ${AGENCY_NAME} showing ${project.industry.toLowerCase()} website design: ${project.features.join(", ").toLowerCase()}.`;
  return {
    title,
    description,
    alternates: { canonical: `/portfolio/${slug}` },
    openGraph: { title, description, url: `/portfolio/${slug}` },
  };
}

export default async function DemoPage({ params }: { params: Promise<{ slug: string }> }) {
  const { slug } = await params;
  const project = getProject(slug);
  const Demo = demoComponents[slug];
  if (!project || !Demo) notFound();
  return (
    <>
      <DemoBanner name={project.name} />
      <main id="main" className="demo">
        <Demo />
      </main>
      <DemoCTA name={project.name} category={project.category} />
    </>
  );
}
