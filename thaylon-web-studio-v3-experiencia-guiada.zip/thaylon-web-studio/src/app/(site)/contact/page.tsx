import type { Metadata } from "next";
import { Clock, FileText, Mail, MessageSquare } from "lucide-react";
import { QuoteForm } from "@/components/QuoteForm";
import { SocialIcon } from "@/components/SocialIcon";
import { AGENCY_EMAIL, AGENCY_NAME, socialLinks } from "@/config/site";

export const metadata: Metadata = {
  title: "Get a Free Quote — Small Business Website Design",
  description:
    "Tell us about your business and project. Get a clear, written website estimate — no commitment, no pressure.",
  alternates: { canonical: "/contact" },
};

const steps = [
  { icon: MessageSquare, title: "1. Tell us about your project", body: "Share a few details using the form. It takes about 3 minutes." },
  { icon: FileText, title: "2. Get a written estimate", body: "We review your request and reply with recommendations, price and timeline." },
  { icon: Clock, title: "3. Kick off when you're ready", body: "No pressure. Ask questions, adjust the scope, and start when it suits you." },
];

export default function ContactPage() {
  return (
    <section className="relative overflow-hidden bg-paper">
      <div className="grid-bg pointer-events-none absolute inset-0 [mask-image:radial-gradient(ellipse_at_top_left,black,transparent_60%)]" />
      <div className="container-x relative grid grid-cols-1 gap-10 py-12 sm:py-20 lg:grid-cols-[0.85fr_1.15fr] lg:grid-rows-[auto_1fr] lg:gap-x-16 lg:gap-y-0">
        <div className="animate-fade-up lg:col-start-1 lg:row-start-1">
          <p className="eyebrow">Get a free quote</p>
          <h1 className="mt-4 text-[36px] leading-[1.05] font-extrabold text-ink sm:text-[52px]">Let&apos;s talk about your website.</h1>
          <p className="mt-5 text-lg leading-relaxed text-muted">
            Tell us about your business and what you need. We&apos;ll get back to you with a clear, written estimate — free and without obligation.
          </p>
        </div>

        {/* On phones the form comes right after the intro; on desktop it sits in the right column. */}
        <div id="quote-form" className="animate-fade-up scroll-mt-24 [animation-delay:120ms] lg:col-start-2 lg:row-span-2 lg:row-start-1">
          <QuoteForm />
        </div>

        <div className="lg:col-start-1 lg:row-start-2">

          <h2 className="font-display text-[13px] font-bold tracking-[0.14em] text-muted uppercase lg:mt-10">What happens next</h2>
          <ol className="mt-5 space-y-6">
            {steps.map(({ icon: Icon, title, body }) => (
              <li key={title} className="flex gap-4">
                <span className="flex h-10 w-10 shrink-0 items-center justify-center rounded-lg border border-line bg-white text-ink">
                  <Icon className="h-5 w-5" />
                </span>
                <div>
                  <h3 className="font-display text-[16px] font-bold text-ink">{title}</h3>
                  <p className="mt-0.5 text-[15px] text-muted">{body}</p>
                </div>
              </li>
            ))}
          </ol>

          <div className="mt-10 rounded-xl border border-line bg-white p-6">
            <h2 className="font-display text-[16px] font-bold text-ink">{AGENCY_EMAIL ? "Prefer email?" : "Direct contact"}</h2>
            {AGENCY_EMAIL ? (
              <a href={`mailto:${AGENCY_EMAIL}`} className="mt-2 inline-flex items-center gap-2 text-[15px] font-semibold text-accent hover:underline">
                <Mail className="h-4 w-4" /> {AGENCY_EMAIL}
              </a>
            ) : (
              <p className="mt-2 text-[15px] leading-relaxed text-muted">
                {/* When NEXT_PUBLIC_AGENCY_EMAIL is set, the email address appears here instead. */}
                The quote form is the best way to reach us. Every request is read and answered personally, by email.
              </p>
            )}
            {socialLinks.length > 0 && (
              <div className="mt-4 flex gap-2">
                {socialLinks.map((s) => (
                  <a key={s.label} href={s.href} target="_blank" rel="noopener noreferrer" aria-label={`${AGENCY_NAME} on ${s.label}`} className="inline-flex h-10 w-10 items-center justify-center rounded-lg border border-line text-ink/70 hover:text-ink">
                    <SocialIcon name={s.icon} />
                  </a>
                ))}
              </div>
            )}
            <p className="mt-4 text-[13px] text-muted">We typically reply within 1–2 business days.</p>
          </div>
        </div>
      </div>
    </section>
  );
}
