import Link from "next/link";
import type { Metadata } from "next";
import { Activity, ArrowRight, Ban, CalendarClock, FileText, LifeBuoy, PencilLine, Wrench } from "lucide-react";
import { CTASection, PageHero, PlanCard, SectionHeading } from "@/components/ui";
import { maintenanceLimits, maintenancePlans } from "@/data/pricing";
import { QUOTE_PATH } from "@/config/site";

export const metadata: Metadata = {
  title: "Monthly Website Maintenance Plans",
  description:
    "Optional website care plans from $29/month: monitoring, technical checks, small content updates and priority support — with clearly defined monthly limits.",
  alternates: { canonical: "/maintenance" },
};

const why = [
  { icon: CalendarClock, title: "Your information changes", body: "Prices, hours, menus, services and photos change over time. Outdated details can confuse customers." },
  { icon: Wrench, title: "Small things can break", body: "A form stops sending, a link changes, a browser update shifts a layout. Catching it early keeps your site reliable." },
  { icon: LifeBuoy, title: "You have a business to run", body: "Instead of learning the technical side, just send an email and we'll take care of it within your plan." },
];

const guide = [
  { plan: "Basic Care", fit: "Your site rarely changes and you mainly want to know it keeps working." },
  { plan: "Standard Care", fit: "You update prices, hours, menus or photos now and then." },
  { plan: "Premium Care", fit: "You update your site regularly and want faster replies and a monthly report." },
];

const notCovered = [
  "New pages, new features or new integrations",
  "Redesigns or major layout changes",
  "Work beyond your plan's monthly time allowance",
  "Hosting, domain and third-party subscription fees",
  "Unlimited support or unlimited changes",
];

const included = [
  { icon: Activity, title: "Monitoring & checks", body: "We keep an eye on your site and run monthly technical checks on links, forms and mobile display." },
  { icon: PencilLine, title: "Content updates", body: "New prices, updated hours, a fresh photo or a new menu item — just email us the change." },
  { icon: LifeBuoy, title: "Small fixes", body: "If something small breaks, we fix it within your plan's monthly time allowance." },
  { icon: FileText, title: "Performance reports", body: "Premium Care includes a short monthly report on speed and technical health." },
];

export default function MaintenancePage() {
  return (
    <>
      <PageHero
        eyebrow="Monthly maintenance"
        title="We keep your website running. You run your business."
        intro="A website isn't finished the day it launches. Our optional care plans keep it working and up to date — with simple monthly pricing, clear limits and no long-term contracts."
      />

      <section className="py-16 sm:py-20">
        <div className="container-x">
          <SectionHeading eyebrow="Why it matters" title="Why a website may need care after launch." />
          <div className="mt-10 grid gap-4 md:grid-cols-3">
            {why.map(({ icon: Icon, title, body }) => (
              <div key={title} className="reveal rounded-2xl border border-line bg-white p-6">
                <span className="flex h-10 w-10 items-center justify-center rounded-lg bg-paper text-ink"><Icon className="h-5 w-5" aria-hidden="true" /></span>
                <h3 className="mt-4 text-[17px] font-bold text-ink">{title}</h3>
                <p className="mt-1.5 text-[15px] leading-relaxed text-muted">{body}</p>
              </div>
            ))}
          </div>
          <p className="mt-6 text-[15px] text-muted">Maintenance is completely optional. You can also request one-time updates whenever you need them, quoted individually.</p>
        </div>
      </section>

      <section id="plans" className="bg-paper py-16 sm:py-20">
        <div className="container-x">
          <SectionHeading eyebrow="Plans" title="Three simple plans." intro="Pick the level of care that matches how often your website changes." />
          <div className="mt-12 grid gap-6 lg:grid-cols-3">
            {maintenancePlans.map((p) => (
              <PlanCard key={p.id} plan={p} ctaLabel="Ask About This Plan" />
            ))}
          </div>
          <div className="mt-10 overflow-hidden rounded-2xl border border-line bg-white">
            <h3 className="border-b border-line px-6 py-4 font-display text-[16px] font-bold text-ink">Which plan is right for me?</h3>
            <dl className="divide-y divide-line">
              {guide.map((g) => (
                <div key={g.plan} className="grid gap-1 px-6 py-4 sm:grid-cols-[180px_1fr] sm:gap-6">
                  <dt className="font-semibold text-ink">{g.plan}</dt>
                  <dd className="text-[15px] leading-relaxed text-muted">{g.fit}</dd>
                </div>
              ))}
            </dl>
          </div>
        </div>
      </section>

      <section className="py-20 sm:py-28">
        <div className="container-x grid gap-12 lg:grid-cols-2 lg:gap-16">
          <div>
            <SectionHeading eyebrow="What's included" title="Practical care, not vague promises." />
            <div className="mt-10 grid gap-6 sm:grid-cols-2">
              {included.map(({ icon: Icon, title, body }) => (
                <div key={title} className="reveal">
                  <span className="flex h-10 w-10 items-center justify-center rounded-lg bg-paper text-ink">
                    <Icon className="h-5 w-5" />
                  </span>
                  <h3 className="mt-4 font-bold text-ink">{title}</h3>
                  <p className="mt-1.5 text-[15px] leading-relaxed text-muted">{body}</p>
                </div>
              ))}
            </div>
          </div>
          <div className="reveal rounded-xl border border-line bg-paper p-7 sm:p-9">
            <h2 className="text-2xl font-extrabold text-ink">Plan limits</h2>
            <p className="mt-2 text-[15px] text-muted">So there are never any surprises:</p>
            <ul className="mt-6 space-y-4">
              {maintenanceLimits.map((l) => (
                <li key={l} className="flex gap-3 text-[15px] leading-relaxed text-ink/85">
                  <span className="mt-2 h-1.5 w-1.5 shrink-0 rounded-full bg-accent" />
                  {l}
                </li>
              ))}
            </ul>
            <div className="mt-6 border-t border-line pt-6">
              <h3 className="flex items-center gap-2 font-bold text-ink"><Ban className="h-4 w-4 text-accent" aria-hidden="true" /> Not covered by maintenance plans</h3>
              <ul className="mt-3 space-y-2">
                {notCovered.map((l) => (
                  <li key={l} className="text-[14.5px] leading-relaxed text-ink/80">— {l}</li>
                ))}
              </ul>
              <p className="mt-4 text-[14px] leading-relaxed text-muted">
                Anything outside your plan is quoted first and only starts after you approve it.
              </p>
            </div>
          </div>
        </div>
      </section>

      <section className="border-t border-line py-16">
        <div className="container-x flex flex-col items-start justify-between gap-6 sm:flex-row sm:items-center">
          <div>
            <h2 className="text-2xl font-extrabold text-ink">Have a website we didn&apos;t build?</h2>
            <p className="mt-2 max-w-xl text-muted">We may still be able to help. Send us the link and we&apos;ll review it before recommending a plan.</p>
          </div>
          <Link href={`${QUOTE_PATH}?project=maintenance`} className="btn-dark shrink-0">
            Tell Us About Your Website <ArrowRight className="h-4 w-4" />
          </Link>
        </div>
      </section>

      <CTASection title="Let's keep your website in good shape." body="Questions about which plan fits? Send us a quick message. We'll give you an honest recommendation — even if that's no plan at all." />
    </>
  );
}
