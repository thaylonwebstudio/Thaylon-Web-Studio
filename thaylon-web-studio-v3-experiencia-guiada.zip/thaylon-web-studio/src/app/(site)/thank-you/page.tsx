import type { Metadata } from "next";
import Link from "next/link";
import { ArrowRight, CheckCircle2, FileText, Mail, MessageSquare } from "lucide-react";

export const metadata: Metadata = {
  title: "Thank You",
  description: "Thanks for reaching out. Here's what happens next.",
  robots: { index: false, follow: true },
  alternates: { canonical: "/thank-you" },
};

const next = [
  { icon: Mail, title: "We read your request", body: "Every request is reviewed personally. No automated sales emails." },
  { icon: MessageSquare, title: "We may ask a question or two", body: "If anything is unclear, we'll reply by email to make sure we understand what you need." },
  { icon: FileText, title: "You get a clear estimate", body: "Scope, price and estimated timeline in writing — usually within 1–2 business days. No obligation." },
];

export default function ThankYouPage() {
  return (
    <section className="relative overflow-hidden bg-paper">
      <div className="grid-bg pointer-events-none absolute inset-0 [mask-image:radial-gradient(ellipse_at_top,black,transparent_65%)]" />
      <div className="container-x relative py-16 sm:py-24">
        <div className="mx-auto max-w-2xl text-center">
          <span className="animate-pop mx-auto flex h-16 w-16 items-center justify-center rounded-full bg-emerald-50 text-emerald-600 ring-8 ring-emerald-50/60">
            <CheckCircle2 className="h-9 w-9" />
          </span>
          <h1 className="mt-7 text-[36px] leading-[1.08] font-extrabold text-ink sm:text-[48px]">Thank you for reaching out.</h1>
          <p className="mt-5 text-lg leading-relaxed text-muted">
            Your request is in good hands. We&apos;re looking forward to learning more about your business. Here&apos;s what happens next.
          </p>
        </div>

        <ol className="mx-auto mt-12 grid max-w-4xl gap-4 sm:grid-cols-3">
          {next.map(({ icon: Icon, title, body }, i) => (
            <li key={title} className="rounded-2xl border border-line bg-white p-6">
              <div className="flex items-center gap-3">
                <span className="flex h-10 w-10 items-center justify-center rounded-lg bg-paper text-ink"><Icon className="h-5 w-5" /></span>
                <span className="text-[12px] font-bold tracking-[0.14em] text-muted uppercase">Step {i + 1}</span>
              </div>
              <h2 className="mt-4 text-[17px] font-bold text-ink">{title}</h2>
              <p className="mt-1.5 text-[15px] leading-relaxed text-muted">{body}</p>
            </li>
          ))}
        </ol>

        <div className="mt-12 flex flex-col justify-center gap-3 sm:flex-row">
          <Link href="/portfolio" className="btn-dark">Explore Our Work <ArrowRight className="h-4 w-4" /></Link>
          <Link href="/" className="btn-ghost">Back to Home</Link>
        </div>
        <p className="mt-6 text-center text-[13px] text-muted">Didn&apos;t hear back in 2 business days? Please check your spam folder.</p>
      </div>
    </section>
  );
}
