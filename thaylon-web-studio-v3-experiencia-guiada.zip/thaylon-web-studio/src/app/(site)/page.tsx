import Link from "next/link";
import type { Metadata } from "next";
import { ArrowDown, ArrowRight, ArrowUpRight, Check } from "lucide-react";
import { DeviceShowcase } from "@/components/DeviceShowcase";
import { WelcomeTour } from "@/components/WelcomeTour";
import {
  CTASection,
  FAQList,
  PlanCard,
  PortfolioCard,
  ProcessSection,
  SectionHeading,
  serviceIcons,
} from "@/components/ui";
import { benefits, faqs, industries, reasons, services } from "@/data/content";
import { projects } from "@/data/portfolio";
import { pricingNote, websitePlans } from "@/data/pricing";
import { PORTFOLIO_URL, QUOTE_PATH } from "@/config/site";

export const metadata: Metadata = {
  alternates: { canonical: "/" },
};

export default function HomePage() {
  return (
    <>
      {/* ───────── HERO ───────── */}
      <section className="relative -mt-[72px] overflow-hidden bg-paper pt-[72px]">
        <div className="grid-bg pointer-events-none absolute inset-0 [mask-image:radial-gradient(ellipse_at_top_left,black,transparent_75%)]" />
        <div className="container-x relative grid items-center gap-14 pt-14 pb-20 sm:pt-20 lg:grid-cols-[1fr_1.05fr] lg:gap-10 lg:pt-24 lg:pb-28">
          <div className="animate-fade-up">
            <p className="inline-flex items-center gap-2 rounded-full border border-line bg-white px-3 py-1.5 text-[13px] font-medium text-ink/80 shadow-sm">
              <span className="h-1.5 w-1.5 rounded-full bg-accent" />
              Web design for U.S. small businesses
            </p>
            <h1 className="mt-6 text-[34px] leading-[1.06] font-extrabold text-ink min-[380px]:text-[40px] sm:text-[56px] lg:text-[60px]">
              Your business deserves more than just a <span className="text-accent">website.</span>
            </h1>
            <p className="mt-5 max-w-xl font-display text-[19px] leading-snug font-semibold text-ink/85 sm:text-[22px]">
              It deserves a digital presence that makes people trust you.
            </p>
            <p className="mt-4 max-w-xl text-[17px] leading-relaxed text-muted sm:text-lg">
              We create thoughtful, professional websites designed around your business, your customers, and the way you want to grow.
            </p>
            <div className="mt-8 flex flex-col gap-3 sm:flex-row">
              <a href="#welcome" className="btn-dark !px-6 !py-4 !text-base">
                Explore What We Do <ArrowDown className="h-4 w-4" />
              </a>
              <Link href={QUOTE_PATH} className="btn-primary !px-6 !py-4 !text-base">
                Get Your Free Quote <ArrowRight className="h-4 w-4" />
              </Link>
            </div>
            <ul className="mt-8 flex flex-wrap gap-x-6 gap-y-2.5 text-[14.5px] text-ink/80">
              {["Packages from $299", "No obligation", "You own your site"].map((t) => (
                <li key={t} className="flex items-center gap-2">
                  <Check className="h-4 w-4 text-accent" /> {t}
                </li>
              ))}
            </ul>
          </div>
          <div className="animate-fade-up [animation-delay:150ms]">
            <DeviceShowcase />
          </div>
        </div>

        {/* industries marquee-style strip (static, no fake logos) */}
        <div className="relative border-t border-line bg-white/70">
          <div className="container-x flex items-center gap-6 overflow-x-auto py-5 no-scrollbar" tabIndex={0} role="region" aria-label="Industries we build websites for">
            <span className="shrink-0 text-[12px] font-semibold tracking-[0.16em] text-muted uppercase">Built for</span>
            <ul className="flex shrink-0 items-center gap-2">
              {industries.map((i) => (
                <li key={i} className="shrink-0 rounded-full border border-line bg-white px-3 py-1 text-[13px] text-ink/70">{i}</li>
              ))}
            </ul>
          </div>
        </div>
      </section>

      <WelcomeTour />

      {/* ───────── VALUE ───────── */}
      <section id="after-welcome" className="py-20 sm:py-28">
        <div className="container-x grid gap-12 lg:grid-cols-[1fr_1.35fr] lg:gap-16">
          <div className="lg:sticky lg:top-28 lg:self-start">
            <SectionHeading
              eyebrow="Why it matters"
              title="What a professional website can do for your business."
              intro="A website works for you around the clock. Here's what a well-built one makes possible — explained simply, without big promises."
            />
            <p className="reveal mt-6 rounded-xl border border-line bg-paper p-4 text-[14px] leading-relaxed text-muted">
              Honest note: no website can guarantee a number of customers, sales or a spot on Google. What we can promise is a clear, professional site built with care, and straight answers along the way.
            </p>
          </div>
          <ul className="grid gap-px overflow-hidden rounded-2xl border border-line bg-line sm:grid-cols-2">
            {benefits.map((b, i) => (
              <li key={b.title} className={`reveal flex gap-4 bg-white p-5 sm:block sm:p-7 ${i === benefits.length - 1 ? "sm:col-span-2" : ""}`}>
                <span className="flex h-9 w-9 shrink-0 items-center justify-center rounded-lg bg-paper text-accent"><Check className="h-4 w-4" strokeWidth={3} aria-hidden="true" /></span>
                <div>
                  <h3 className="text-[17px] font-bold text-ink sm:mt-4">{b.title}</h3>
                  <p className="mt-1 text-[15px] leading-relaxed text-muted sm:mt-1.5">{b.body}</p>
                </div>
              </li>
            ))}
          </ul>
        </div>
      </section>

      {/* ───────── SERVICES ───────── */}
      <section className="bg-paper py-20 sm:py-28">
        <div className="container-x">
          <div className="flex flex-col justify-between gap-6 lg:flex-row lg:items-end">
            <SectionHeading
              eyebrow="Services"
              title="Everything you need to look professional online."
              intro="From a simple one-page site to a complete multi-page website, we handle design, development and launch — so you can focus on running your business."
            />
            <Link href="/services" className="btn-ghost shrink-0 self-start lg:self-auto">
              All services <ArrowRight className="h-4 w-4" />
            </Link>
          </div>
          <div className="mt-14 grid gap-px overflow-hidden rounded-xl border border-line bg-line sm:grid-cols-2 lg:grid-cols-3">
            {services.slice(0, 5).map((s, i) => {
              const Icon = serviceIcons[s.icon];
              return (
                <Link
                  key={s.id}
                  href={`/services#${s.id}`}
                  className={`group reveal relative flex flex-col bg-white p-8 transition-colors hover:bg-paper ${i === 0 ? "lg:row-span-1" : ""}`}
                >
                  <span className="flex h-11 w-11 items-center justify-center rounded-lg bg-ink text-white transition-colors group-hover:bg-accent">
                    <Icon className="h-5 w-5" />
                  </span>
                  <h3 className="mt-6 text-xl font-bold text-ink">{s.title}</h3>
                  <p className="mt-2 text-[15px] leading-relaxed text-muted">{s.summary}</p>
                  <span className="mt-6 inline-flex items-center gap-1 text-sm font-semibold text-ink group-hover:text-accent">
                    Learn more <ArrowUpRight className="h-4 w-4" />
                  </span>
                </Link>
              );
            })}
            <div className="flex flex-col justify-between bg-ink p-8 text-white">
              <div>
                <p className="text-[12px] font-semibold tracking-[0.16em] text-white/65 uppercase">Not sure what you need?</p>
                <p className="mt-4 font-display text-2xl leading-snug font-bold">Tell us about your business and we&apos;ll recommend the right fit.</p>
              </div>
              <Link href={QUOTE_PATH} className="btn-primary mt-8 self-start">
                Tell Us About Your Business <ArrowRight className="h-4 w-4" />
              </Link>
            </div>
          </div>
        </div>
      </section>

      {/* ───────── PORTFOLIO PREVIEW ───────── */}
      <section className="py-20 sm:py-28">
        <div className="container-x">
          <div className="flex flex-col justify-between gap-6 lg:flex-row lg:items-end">
            <SectionHeading
              eyebrow="Portfolio"
              title="Design concepts for real-world businesses."
              intro={
                <>
                  Explore complete, clickable demo websites built for fictional businesses — so you can see exactly what we can create for yours.{" "}
                  <span className="text-ink/80">All projects shown are fictional concepts.</span>
                </>
              }
            />
            <Link href={PORTFOLIO_URL} className="btn-ghost shrink-0 self-start lg:self-auto">
              Explore Our Work <ArrowRight className="h-4 w-4" />
            </Link>
          </div>
          <div className="mt-14 grid gap-6 md:grid-cols-2 lg:grid-cols-3">
            {projects.slice(0, 3).map((p) => (
              <PortfolioCard key={p.slug} project={p} />
            ))}
          </div>
        </div>
      </section>

      {/* ───────── WHY CHOOSE US ───────── */}
      <section className="bg-paper py-20 sm:py-28">
        <div className="container-x grid gap-14 lg:grid-cols-[1fr_1.4fr]">
          <div className="lg:sticky lg:top-28 lg:self-start">
            <SectionHeading
              eyebrow="Why choose us"
              title="A professional website, without the agency price tag."
              intro="We keep things simple: honest pricing, thoughtful design and direct communication from start to finish."
            />
            <Link href="/about" className="btn-ghost mt-8">
              About the studio <ArrowRight className="h-4 w-4" />
            </Link>
          </div>
          <div className="grid gap-px overflow-hidden rounded-xl border border-line bg-line sm:grid-cols-2">
            {reasons.map((r, i) => (
              <div key={r.title} className="reveal bg-white p-7 sm:p-8">
                <span className="font-display text-sm font-bold text-accent">{String(i + 1).padStart(2, "0")}</span>
                <h3 className="mt-3 text-lg font-bold text-ink">{r.title}</h3>
                <p className="mt-2 text-[15px] leading-relaxed text-muted">{r.body}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      <ProcessSection />

      {/* ───────── PRICING PREVIEW ───────── */}
      <section className="py-20 sm:py-28">
        <div className="container-x">
          <SectionHeading
            align="center"
            eyebrow="Pricing"
            title="Simple packages. Clear, one-time prices."
            intro="Choose a package or ask for a custom quote. Every package includes custom design, responsive layout and two revision rounds."
          />
          <div className="mt-14 grid gap-6 lg:grid-cols-3">
            {websitePlans.map((p) => (
              <PlanCard key={p.id} plan={p} />
            ))}
          </div>
          <p className="mx-auto mt-8 max-w-3xl text-center text-sm leading-relaxed text-muted">{pricingNote}</p>
          <div className="mt-6 text-center">
            <Link href="/pricing" className="inline-flex items-center gap-1.5 font-semibold text-ink hover:text-accent">
              Compare packages &amp; maintenance plans <ArrowRight className="h-4 w-4" />
            </Link>
          </div>
        </div>
      </section>

      {/* ───────── FAQ ───────── */}
      <section id="faq" className="bg-paper py-20 sm:py-28">
        <div className="container-x grid gap-12 lg:grid-cols-[1fr_1.6fr]">
          <SectionHeading
            eyebrow="FAQ"
            title="Questions you might have before reaching out."
            intro={
              <>
                Don&apos;t see your question?{" "}
                <Link href={QUOTE_PATH} className="font-semibold text-ink underline decoration-accent decoration-2 underline-offset-4">
                  Send us a message
                </Link>
                .
              </>
            }
          />
          <FAQList items={faqs.slice(0, 10)} />
        </div>
      </section>

      <CTASection />
    </>
  );
}
