import type { Metadata } from "next";
import Link from "next/link";
import { LegalLayout, Ph } from "@/components/LegalLayout";
import { AGENCY_EMAIL, AGENCY_NAME, SITE_HOST } from "@/config/site";

/*
 * Owner: before final publication, complete the highlighted placeholders:
 *   DATE · BUSINESS LEGAL NAME / OWNER NAME · RETENTION PERIOD ·
 *   CONTACT EMAIL (set NEXT_PUBLIC_AGENCY_EMAIL) · BUSINESS MAILING ADDRESS (optional).
 * The domain is filled automatically from NEXT_PUBLIC_AGENCY_DOMAIN or, if unset,
 * from the Netlify site address. Have the final text reviewed by an attorney.
 */

export const metadata: Metadata = {
  title: "Privacy Policy",
  description: `How ${AGENCY_NAME} collects, uses and protects information submitted through this website.`,
  alternates: { canonical: "/privacy" },
};

export default function PrivacyPage() {
  const email = AGENCY_EMAIL ? <a href={`mailto:${AGENCY_EMAIL}`}>{AGENCY_EMAIL}</a> : <Ph>CONTACT EMAIL</Ph>;
  return (
    <LegalLayout title="Privacy Policy" updated={<Ph>DATE</Ph>}>
      <p>
        This Privacy Policy explains how {AGENCY_NAME} (&quot;we,&quot; &quot;us,&quot; or &quot;our&quot;), operated by <Ph>BUSINESS LEGAL NAME / OWNER NAME</Ph>, collects, uses and protects information when you visit {SITE_HOST || <Ph>YOUR DOMAIN</Ph>} (the &quot;Website&quot;) or contact us.
      </p>

      <h2>1. Information we collect</h2>
      <h3>Information you provide</h3>
      <p>When you submit our quote request form or email us, we collect the information you choose to share, such as:</p>
      <ul>
        <li>Your full name and business name</li>
        <li>Your email address</li>
        <li>Your business website address (optional)</li>
        <li>Your business category, project type, estimated budget and project description</li>
      </ul>
      <h3>Information collected automatically</h3>
      <p>
        This Website does not use advertising trackers or analytics cookies. Our hosting provider, Netlify, may automatically process technical information such as IP addresses, browser type and request logs to deliver and secure the Website. When you submit the quote form, Netlify may also record technical details of the submission (such as the date and time and your IP address) to deliver it and to filter spam. If we add analytics in the future, we will update this policy and, where required, ask for your consent.
      </p>

      <h2>2. How we use your information</h2>
      <ul>
        <li>To respond to your inquiry and prepare a quote</li>
        <li>To communicate with you about a project you have requested</li>
        <li>To provide, maintain and improve our services</li>
        <li>To comply with legal obligations and protect against fraud or abuse</li>
      </ul>
      <p>We do not sell or rent your personal information, and we do not use it for unrelated marketing without your permission.</p>

      <h2>3. Service providers</h2>
      <p>
        We use the following service provider to operate the Website:
      </p>
      <ul>
        <li>
          <strong>Netlify, Inc.</strong> hosts the Website. Quote requests are handled by <strong>Netlify Forms</strong>: your submission is sent to and stored in our Netlify account, where we can review it, and Netlify may send us an email notification containing the information you submitted so we can reply. Netlify applies automated spam filtering to form submissions.
        </li>
      </ul>
      <p>
        Netlify processes this information on our behalf and under its own privacy policy, available at{" "}
        <a href="https://www.netlify.com/privacy/" target="_blank" rel="noopener noreferrer">netlify.com/privacy</a>. When we reply to you by email, your message is also handled by our email provider.
      </p>

      <h2>4. Cookies</h2>
      <p>
        The Website itself does not set cookies for tracking or advertising. Fonts are served from our own website, not from third-party font services.
      </p>

      <h2>5. Data retention</h2>
      <p>
        We keep inquiry information only as long as needed to respond to you, manage an ongoing project, or meet legal and accounting requirements — typically no longer than <Ph>RETENTION PERIOD</Ph> after our last communication.
      </p>

      <h2>6. Your choices and rights</h2>
      <p>
        You may ask us to access, correct or delete the personal information you have shared with us by contacting {email}. Depending on where you live (for example, California), you may have additional rights under applicable privacy laws. We will respond to verified requests as required by law.
      </p>

      <h2>7. Security</h2>
      <p>
        The Website is served over HTTPS. We take reasonable measures to protect your information, but no method of transmission or storage is completely secure.
      </p>

      <h2>8. Children&apos;s privacy</h2>
      <p>Our services are intended for businesses and are not directed to children under 13. We do not knowingly collect information from children.</p>

      <h2>9. Changes to this policy</h2>
      <p>We may update this Privacy Policy from time to time. The &quot;Last updated&quot; date above shows when it was last revised.</p>

      <h2>10. Contact</h2>
      <p>
        Questions about this policy? Contact {AGENCY_NAME} at {email} or through our <Link href="/contact">contact page</Link>. Mailing address: <Ph>BUSINESS MAILING ADDRESS (optional)</Ph>.
      </p>
    </LegalLayout>
  );
}
