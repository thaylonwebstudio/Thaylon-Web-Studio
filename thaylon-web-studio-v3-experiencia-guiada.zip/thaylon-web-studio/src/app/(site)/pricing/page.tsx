import Link from "next/link";
import type { Metadata } from "next";
import { ArrowRight, Check, CircleDollarSign, Info, Minus, X } from "lucide-react";
import { CTASection, FAQList, PageHero, PlanCard, SectionHeading } from "@/components/ui";
import { maintenancePlans, pricingNote, websitePlans } from "@/data/pricing";
import { faqs } from "@/data/content";
import { QUOTE_PATH } from "@/config/site";

export const metadata: Metadata = {
  title: "Pricing — Affordable Small Business Website Packages",
  description:
    "Transparent, one-time website packages from $299: Starter, Professional and Business websites, plus optional monthly maintenance from $29/month.",
  alternates: { canonical: "/pricing" },
};

type Cell = boolean | string;
const compare: { label: string; values: [Cell, Cell, Cell] }[] = [
  { label: "Pages", values: ["1", "Up to 5", "Up to 8"] },
  { label: "Custom design", values: ["Custom", "Custom", "Advanced"] },
  { label: "Responsive (phone, tablet, desktop)", values: [true, true, true] },
  { label: "Contact buttons (call / email)", values: [true, true, true] },
  { label: "Contact form", values: ["Basic", "Standard", "Advanced"] },
  { label: "Social media integration", values: [false, true, true] },
  { label: "Image gallery", values: [false, false, true] },
  { label: "Simple external integrations", values: [false, false, true] },
  { label: "On-page SEO basics", values: [true, true, true] },
  { label: "Revision rounds", values: ["2", "2", "2"] },
  { label: "Help launching & connecting your domain", values: [true, true, true] },
  { label: "Estimated timeline*", values: ["5–7 business days", "1–2 weeks", "2–3 weeks"] },
];

const included = [
  "Custom design for your business",
  "Works on phones, tablets and computers",
  "Tap-to-call and email buttons",
  "A contact form that sends requests to you",
  "Search-engine basics (titles, descriptions, sitemap)",
  "Two revision rounds",
  "Help launching and connecting your domain",
  "Full ownership once paid in full",
];

const notIncluded = [
  { item: "Domain name", note: "Recurring yearly cost, paid to a registrar (a .com is usually about $10–$25/year)." },
  { item: "Website hosting", note: "Recurring cost, if your plan isn't free. Paid to the hosting provider." },
  { item: "Online store, ordering or full booking systems", note: "Quoted separately, often with third-party fees." },
  { item: "Third-party tools & subscriptions", note: "Any monthly fees are listed in your estimate first." },
  { item: "Extra revision rounds or major design changes", note: "Quoted in advance — never billed by surprise." },
  { item: "Monthly maintenance", note: "Optional, from $29/month. You can also request one-time updates." },
];

const terms = [
  { title: "Payment schedule", body: "Typically a 50% deposit to start and the remaining 50% before launch. Exact terms are confirmed in your written estimate." },
  { title: "Project scope", body: "Your estimate lists exactly what's included — pages, features and integrations. Anything new is quoted separately before work begins." },
  { title: "Revision limits", body: "Every package includes two revision rounds. A round is one consolidated list of changes. Additional rounds can be added at a quoted rate." },
  { title: "Delivery", body: "Timelines start once we receive your content and deposit. Delays in feedback or content may shift the delivery date." },
  { title: "Hosting & domain", body: "Not included in package prices. Usually you purchase and own these accounts and we help set them up; if you'd like us to manage them, we'll agree on it in your estimate." },
  { title: "Ownership & handover", body: "When the project is paid in full, the website is yours. We hand over files and access. Third-party assets follow their own licenses." },
];

function CellValue({ v }: { v: Cell }) {
  if (v === true) return <Check className="mx-auto h-5 w-5 text-accent" aria-label="Included" />;
  if (v === false) return <Minus className="mx-auto h-5 w-5 text-muted" aria-label="Not included" />;
  return <span className="text-[14.5px] font-medium text-ink">{v}</span>;
}

export default function PricingPage() {
  return (
    <>
      <PageHero
        eyebrow="Pricing"
        title="Professional websites. Fair, upfront pricing."
        intro="One-time packages, clear limits and no hidden fees. You'll know exactly what you're getting — and what costs extra — before any work starts."
      />

      <section className="py-16 sm:py-20">
        <div className="container-x">
          <div className="grid gap-6 lg:grid-cols-3">
            {websitePlans.map((p) => (
              <PlanCard key={p.id} plan={p} />
            ))}
          </div>

          <div className="mt-10 flex gap-4 rounded-xl border border-accent/25 bg-accent/[0.04] p-5 sm:p-6">
            <Info className="mt-0.5 h-5 w-5 shrink-0 text-accent" />
            <p className="text-[15px] leading-relaxed text-ink/85">
              <strong className="font-semibold text-ink">Please note:</strong> {pricingNote}
            </p>
          </div>
        </div>
      </section>

      {/* Included / not included */}
      <section className="pb-20 sm:pb-24">
        <div className="container-x">
          <SectionHeading eyebrow="No surprises" title="What's included — and what costs extra." intro="Every package includes the essentials below. Anything outside them is always listed in your written estimate before you decide." />
          <div className="mt-10 grid gap-6 lg:grid-cols-2">
            <div className="reveal rounded-2xl border border-line bg-white p-6 sm:p-8">
              <h3 className="flex items-center gap-2 text-lg font-bold text-ink"><Check className="h-5 w-5 text-emerald-600" aria-hidden="true" /> Included in every package</h3>
              <ul className="mt-5 grid gap-3">
                {included.map((t) => (
                  <li key={t} className="flex items-start gap-3 text-[15px] text-ink/85">
                    <Check className="mt-0.5 h-[18px] w-[18px] shrink-0 text-accent" aria-hidden="true" /> {t}
                  </li>
                ))}
              </ul>
            </div>
            <div className="reveal rounded-2xl border border-line bg-paper/70 p-6 sm:p-8">
              <h3 className="flex items-center gap-2 text-lg font-bold text-ink"><CircleDollarSign className="h-5 w-5 text-ink/70" aria-hidden="true" /> Not included (paid or quoted separately)</h3>
              <ul className="mt-5 grid gap-4">
                {notIncluded.map((t) => (
                  <li key={t.item} className="flex items-start gap-3">
                    <X className="mt-0.5 h-[18px] w-[18px] shrink-0 text-muted" aria-hidden="true" />
                    <span>
                      <span className="block text-[15px] font-semibold text-ink">{t.item}</span>
                      <span className="block text-[14px] leading-relaxed text-muted">{t.note}</span>
                    </span>
                  </li>
                ))}
              </ul>
            </div>
          </div>
        </div>
      </section>

      {/* Comparison */}
      <section className="pb-20 sm:pb-28">
        <div className="container-x">
          <SectionHeading eyebrow="Compare" title="Side-by-side comparison." />
          <div className="mt-10 overflow-x-auto rounded-xl border border-line" tabIndex={0} role="region" aria-label="Package comparison table (scrolls sideways on small screens)">
            <table className="w-full min-w-[640px] border-collapse text-left">
              <caption className="sr-only">Website package comparison</caption>
              <thead>
                <tr className="bg-paper">
                  <th scope="col" className="px-5 py-4 text-sm font-semibold text-muted">Feature</th>
                  {websitePlans.map((p) => (
                    <th key={p.id} scope="col" className="px-5 py-4 text-center">
                      <span className="block font-display text-[15px] font-bold text-ink">{p.name}</span>
                      <span className="text-sm text-muted">{p.price}</span>
                    </th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {compare.map((row) => (
                  <tr key={row.label} className="border-t border-line">
                    <th scope="row" className="px-5 py-4 text-[15px] font-medium text-ink/85">{row.label}</th>
                    {row.values.map((v, i) => (
                      <td key={i} className="px-5 py-4 text-center"><CellValue v={v} /></td>
                    ))}
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
          <p className="mt-3 text-[13px] text-muted">*Timelines start once we receive your content and the deposit.</p>
        </div>
      </section>

      {/* Custom quote */}
      <section id="custom" className="bg-ink py-20 text-white sm:py-24">
        <div className="container-x grid items-center gap-10 lg:grid-cols-[1.4fr_1fr]">
          <div>
            <p className="eyebrow !text-[#f28b82]">Custom quote</p>
            <h2 className="mt-4 text-[32px] leading-[1.08] font-extrabold sm:text-[44px]">Need something different?</h2>
            <p className="mt-5 max-w-xl text-lg text-white/75">
              More pages, online ordering, e-commerce, a booking system or a special integration? Tell us what you need and we&apos;ll send a custom, itemized estimate.
            </p>
          </div>
          <div className="flex flex-col gap-3 sm:flex-row lg:justify-end">
            <Link href={`${QUOTE_PATH}?package=custom`} className="btn-primary !px-6 !py-4">
              Request a Custom Quote <ArrowRight className="h-4 w-4" />
            </Link>
          </div>
        </div>
      </section>

      {/* Maintenance teaser */}
      <section className="py-20 sm:py-28">
        <div className="container-x">
          <div className="flex flex-col justify-between gap-6 lg:flex-row lg:items-end">
            <SectionHeading
              eyebrow="After launch"
              title="Optional monthly maintenance."
              intro="Keep your website secure, working and up to date with a simple monthly plan. No long-term contracts."
            />
            <Link href="/maintenance" className="btn-ghost shrink-0 self-start lg:self-auto">
              Plan details &amp; limits <ArrowRight className="h-4 w-4" />
            </Link>
          </div>
          <div className="mt-12 grid gap-6 lg:grid-cols-3">
            {maintenancePlans.map((p) => (
              <PlanCard key={p.id} plan={p} ctaLabel="Ask About This Plan" />
            ))}
          </div>
        </div>
      </section>

      {/* Terms */}
      <section className="bg-paper py-20 sm:py-28">
        <div className="container-x">
          <SectionHeading
            eyebrow="Project terms"
            title="Transparent terms, in plain English."
            intro={
              <>
                The essentials of how projects work. Full details are in our{" "}
                <Link href="/terms" className="font-semibold text-ink underline decoration-accent decoration-2 underline-offset-4">Terms of Service</Link>.
              </>
            }
          />
          <div className="mt-12 grid gap-px overflow-hidden rounded-xl border border-line bg-line sm:grid-cols-2 lg:grid-cols-3">
            {terms.map((t) => (
              <div key={t.title} className="reveal bg-white p-7">
                <h3 className="text-lg font-bold text-ink">{t.title}</h3>
                <p className="mt-2 text-[15px] leading-relaxed text-muted">{t.body}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className="py-20 sm:py-28">
        <div className="container-x grid gap-12 lg:grid-cols-[1fr_1.6fr]">
          <SectionHeading eyebrow="FAQ" title="Pricing questions." />
          <FAQList items={faqs.filter((f) => /cost|domain|payments|changes|own my/i.test(f.q))} />
        </div>
      </section>

      <CTASection />
    </>
  );
}
