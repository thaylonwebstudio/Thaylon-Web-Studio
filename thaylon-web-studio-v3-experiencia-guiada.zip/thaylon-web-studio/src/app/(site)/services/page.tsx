import Link from "next/link";
import type { Metadata } from "next";
import { ArrowRight, Check, Info, Lightbulb, Users } from "lucide-react";
import { CTASection, PageHero, ProcessSection, SectionHeading, serviceIcons } from "@/components/ui";
import { industries, services } from "@/data/content";
import { projects } from "@/data/portfolio";
import { PORTFOLIO_URL, QUOTE_PATH } from "@/config/site";

export const metadata: Metadata = {
  title: "Website Design & Development Services for Small Businesses",
  description:
    "Custom website design, responsive development, business websites, landing pages, contact forms, basic SEO, maintenance and integrations for U.S. small businesses — explained in plain English.",
  alternates: { canonical: "/services" },
};

export default function ServicesPage() {
  return (
    <>
      <PageHero
        eyebrow="Services"
        title="Websites that work as hard as you do."
        intro="Never hired a web designer before? No problem. Here's everything we offer, what it means in plain English, and how it can help your business."
      >
        <nav aria-label="Services on this page" className="mt-10 flex flex-wrap gap-2">
          {services.map((s) => (
            <a key={s.id} href={`#${s.id}`} className="inline-flex min-h-10 items-center rounded-full border border-line bg-white px-4 py-2 text-sm font-medium text-ink/80 transition hover:border-ink/30 hover:text-ink">
              {s.title}
            </a>
          ))}
        </nav>
      </PageHero>

      <div className="container-x divide-y divide-line">
        {services.map((s, i) => {
          const Icon = serviceIcons[s.icon];
          const example = s.example ? projects.find((p) => p.slug === s.example) : undefined;
          return (
            <section key={s.id} id={s.id} aria-labelledby={`${s.id}-title`} className="grid gap-8 py-14 sm:py-20 lg:grid-cols-[0.9fr_1.1fr] lg:gap-16">
              <div className="reveal">
                <div className="flex items-center gap-4">
                  <span className="flex h-12 w-12 items-center justify-center rounded-lg bg-ink text-white">
                    <Icon className="h-5 w-5" aria-hidden="true" />
                  </span>
                  <span className="font-display text-sm font-bold text-muted">{String(i + 1).padStart(2, "0")}</span>
                </div>
                <h2 id={`${s.id}-title`} className="mt-6 text-[28px] font-extrabold text-ink sm:text-4xl">{s.title}</h2>
                <p className="mt-4 text-lg leading-relaxed text-muted">{s.summary}</p>
                <div className="mt-6 space-y-4">
                  <div>
                    <h3 className="text-[12px] font-bold tracking-[0.14em] text-ink/70 uppercase">What it is</h3>
                    <p className="mt-1.5 text-[16px] leading-relaxed text-ink/80">{s.what}</p>
                  </div>
                </div>
              </div>
              <div className="reveal space-y-4">
                <div className="grid gap-4 sm:grid-cols-2">
                  <div className="rounded-xl border border-line bg-white p-5">
                    <h3 className="flex items-center gap-2 text-[12px] font-bold tracking-[0.14em] text-ink/70 uppercase"><Users className="h-4 w-4 text-accent" aria-hidden="true" /> Who it's for</h3>
                    <p className="mt-2 text-[15px] leading-relaxed text-ink/80">{s.forWho}</p>
                  </div>
                  <div className="rounded-xl border border-line bg-white p-5">
                    <h3 className="flex items-center gap-2 text-[12px] font-bold tracking-[0.14em] text-ink/70 uppercase"><Lightbulb className="h-4 w-4 text-accent" aria-hidden="true" /> How it helps</h3>
                    <p className="mt-2 text-[15px] leading-relaxed text-ink/80">{s.helps}</p>
                  </div>
                </div>
                <div className="rounded-xl border border-line bg-paper/60 p-5">
                  <h3 className="text-[12px] font-bold tracking-[0.14em] text-ink/70 uppercase">What&apos;s included</h3>
                  <ul className="mt-3 grid gap-2.5 sm:grid-cols-2">
                    {s.includes.map((pt) => (
                      <li key={pt} className="flex items-start gap-2.5 text-[15px] text-ink/85">
                        <Check className="mt-0.5 h-[18px] w-[18px] shrink-0 text-accent" aria-hidden="true" /> {pt}
                      </li>
                    ))}
                  </ul>
                </div>
                <div className="flex flex-wrap items-center gap-x-6 gap-y-3 pt-2">
                  <Link href={s.link?.href ?? QUOTE_PATH} className="btn-dark">
                    {s.link?.label ?? "Get Your Free Estimate"} <ArrowRight className="h-4 w-4" aria-hidden="true" />
                  </Link>
                  {example && (
                    <Link href={`/portfolio/${example.slug}`} className="inline-flex min-h-11 items-center text-[15px] font-semibold text-ink underline decoration-line decoration-2 underline-offset-4 hover:decoration-accent">
                      See it in a demo: {example.name}
                    </Link>
                  )}
                </div>
              </div>
            </section>
          );
        })}
      </div>

      <section className="container-x pb-6">
        <div className="reveal flex gap-4 rounded-xl border border-line bg-paper p-6 sm:p-8">
          <Info className="mt-0.5 h-5 w-5 shrink-0 text-accent" />
          <div>
            <h2 className="text-lg font-bold text-ink">About additional costs</h2>
            <p className="mt-2 text-[15px] leading-relaxed text-muted">
              Advanced integrations (for example, online ordering, payment processing or full booking systems), third-party subscriptions, website hosting and domain registration are not included in our package prices and may require separate fees. We&apos;ll always list these clearly in your estimate before any work begins.
            </p>
          </div>
        </div>
      </section>

      <section className="pt-14 pb-20 sm:pb-24">
        <div className="container-x">
          <SectionHeading
            eyebrow="Industries"
            title="Made for local businesses."
            intro="We understand what customers look for when they're choosing a local business — and design every page around it."
          />
          <ul className="mt-10 flex flex-wrap gap-2">
            {industries.map((i) => (
              <li key={i} className="rounded-lg border border-line bg-white px-4 py-2.5 text-[15px] font-medium text-ink/80">{i}</li>
            ))}
          </ul>
          <Link href={PORTFOLIO_URL} className="mt-10 inline-flex items-center gap-1.5 font-semibold text-ink hover:text-accent">
            Browse demo projects by industry <ArrowRight className="h-4 w-4" />
          </Link>
        </div>
      </section>

      <ProcessSection compact />

      <CTASection title="Not sure which service you need?" body="That's completely fine. Tell us about your business and goals, and we'll recommend what makes sense — and what you can skip." />
    </>
  );
}
