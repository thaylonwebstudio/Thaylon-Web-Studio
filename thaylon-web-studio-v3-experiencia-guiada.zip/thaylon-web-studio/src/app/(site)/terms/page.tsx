import type { Metadata } from "next";
import Link from "next/link";
import { LegalLayout, Ph } from "@/components/LegalLayout";
import { AGENCY_EMAIL, AGENCY_NAME, SITE_HOST } from "@/config/site";

/*
 * Owner: before final publication, complete the highlighted placeholders:
 *   DATE · BUSINESS LEGAL NAME / OWNER NAME · PAYMENT METHODS · HOURLY RATE ·
 *   STATE / JURISDICTION · CONTACT EMAIL (set NEXT_PUBLIC_AGENCY_EMAIL) ·
 *   the day counts marked [30] (quote validity, maintenance cancellation notice,
 *   inactive-project pause, post-launch fix window).
 * The 50% deposit and the two revision rounds match what the rest of the site
 * already states. Have the final text reviewed by an attorney.
 */

export const metadata: Metadata = {
  title: "Terms of Service",
  description: `Terms for using the ${AGENCY_NAME} website and for website design and development projects.`,
  alternates: { canonical: "/terms" },
};

export default function TermsPage() {
  const email = AGENCY_EMAIL ? <a href={`mailto:${AGENCY_EMAIL}`}>{AGENCY_EMAIL}</a> : <Ph>CONTACT EMAIL</Ph>;
  return (
    <LegalLayout title="Terms of Service" updated={<Ph>DATE</Ph>}>
      <p>
        These Terms of Service (&quot;Terms&quot;) govern your use of {SITE_HOST || <Ph>YOUR DOMAIN</Ph>} (the &quot;Website&quot;) and the website design, development and maintenance services (&quot;Services&quot;) provided by {AGENCY_NAME}, operated by <Ph>BUSINESS LEGAL NAME / OWNER NAME</Ph> (&quot;we,&quot; &quot;us,&quot; or &quot;our&quot;). Each project is also governed by a written estimate or agreement (&quot;Project Agreement&quot;). If the Project Agreement conflicts with these Terms, the Project Agreement controls.
      </p>

      <h2>1. Use of the Website</h2>
      <p>
        You may browse the Website for lawful purposes. The portfolio on this Website contains <strong>fictional demonstration projects</strong> created to show our design capabilities; the businesses shown are not real and are not clients.
      </p>

      <h2>2. Quotes and project scope</h2>
      <ul>
        <li>Quotes are free and valid for <Ph>30</Ph> days unless stated otherwise.</li>
        <li>The Project Agreement defines the scope: number of pages, features, integrations and deliverables.</li>
        <li>Work outside the agreed scope (&quot;change requests&quot;) is quoted separately and begins only after your written approval.</li>
      </ul>

      <h2>3. Payment schedule</h2>
      <ul>
        <li>Unless otherwise agreed, a non-refundable deposit of 50% of the project price is due before work begins.</li>
        <li>The remaining balance is due before the website is launched or files are transferred.</li>
        <li>Monthly maintenance plans are billed in advance each month and may be canceled with <Ph>30</Ph> days&apos; written notice.</li>
        <li>Accepted payment methods: <Ph>PAYMENT METHODS</Ph>. Late payments may pause work.</li>
      </ul>

      <h2>4. Revisions</h2>
      <p>
        Each website package includes two (2) revision rounds. A revision round is a single, consolidated list of changes submitted at one time. Additional rounds, or changes that substantially alter an approved design, may be billed at <Ph>HOURLY RATE</Ph> or quoted in advance. Packages do not include unlimited revisions.
      </p>

      <h2>5. Client responsibilities and content</h2>
      <ul>
        <li>You agree to provide text, images, logos and other materials needed for the project in a timely manner.</li>
        <li>You confirm that you own or have permission to use all materials you provide, and that they do not infringe anyone&apos;s rights.</li>
        <li>You are responsible for the accuracy of business information, prices and claims on your website.</li>
      </ul>

      <h2>6. Delivery and timelines</h2>
      <p>
        Timelines are estimates and begin once we receive the deposit and the required content. Delays in feedback, approvals or content may extend the timeline. If a project is inactive for more than <Ph>30</Ph> days due to client delays, we may pause it and reschedule based on availability.
      </p>

      <h2>7. Hosting, domains and third-party services</h2>
      <ul>
        <li>Hosting, domain registration and third-party services (for example form providers, booking or payment tools) are not included in package prices unless stated in the Project Agreement.</li>
        <li>These accounts should be registered in your name, and you are responsible for their fees and renewals.</li>
        <li>We are not responsible for outages, price changes or policy changes of third-party providers.</li>
      </ul>

      <h2>8. Ownership and handover</h2>
      <p>
        Upon payment in full, you own the final website design and the content created specifically for you, and we will provide access to the website files and any accounts we set up on your behalf. Third-party components (such as fonts, open-source libraries, plugins or stock media) remain subject to their own licenses. Until payment is complete, all work remains our property. We may display the completed project in our portfolio unless you request otherwise in writing.
      </p>

      <h2>9. Maintenance plans</h2>
      <p>
        Maintenance plans include the services and monthly time allowances described on our <Link href="/maintenance">Maintenance page</Link>. Unused time does not roll over. Maintenance does not include new features, redesigns or unlimited changes.
      </p>

      <h2>10. Warranties and limitation of liability</h2>
      <p>
        We will perform the Services with reasonable care and skill. We will fix defects in our own work reported within <Ph>30</Ph> days of launch at no charge. We do not guarantee specific search rankings, traffic or sales. To the maximum extent permitted by law, our total liability for any claim relating to the Services is limited to the amount you paid for the Services giving rise to the claim.
      </p>

      <h2>11. Cancellation</h2>
      <p>
        Either party may cancel a project in writing. If you cancel, you remain responsible for work completed up to the cancellation date; the deposit is non-refundable.
      </p>

      <h2>12. Governing law</h2>
      <p>These Terms are governed by the laws of <Ph>STATE / JURISDICTION</Ph>, without regard to conflict-of-law rules.</p>

      <h2>13. Changes</h2>
      <p>We may update these Terms from time to time. Changes do not affect Project Agreements already signed.</p>

      <h2>14. Contact</h2>
      <p>Questions about these Terms? Contact us at {email} or via our <Link href="/contact">contact page</Link>.</p>
    </LegalLayout>
  );
}
