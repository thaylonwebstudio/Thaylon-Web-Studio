import Link from "next/link";
import type { Metadata } from "next";
import { ArrowRight, Compass, Ear, MessageSquareText, Sparkles } from "lucide-react";
import { CTASection, PageHero, ProcessSection, SectionHeading } from "@/components/ui";
import { AGENCY_EMAIL, AGENCY_NAME, FOUNDER_NAME, FOUNDER_ROLE, PORTFOLIO_URL } from "@/config/site";

export const metadata: Metadata = {
  title: "About — Independent Web Design & Development Studio",
  description:
    "Thaylon Web Studio is an independent web design and development studio helping small businesses build modern, trustworthy websites.",
  alternates: { canonical: "/about" },
};

const values = [
  { icon: Ear, title: "We listen first", body: "Every business is different. Before suggesting anything, we take time to understand your customers, your goals and your budget." },
  { icon: Sparkles, title: "Quality in the details", body: "Clean design, readable text, buttons that are easy to tap. Small details add up to a website people trust." },
  { icon: MessageSquareText, title: "Clarity, always", body: "Plain-English updates, written estimates and honest timelines. You'll always know what's happening and what comes next." },
  { icon: Compass, title: "With you the whole way", body: "From the first message to launch day, you have one person to talk to — and we're still here after launch if you need us." },
];

export default function AboutPage() {
  return (
    <>
      <PageHero
        eyebrow="About"
        title="Behind every business is a person with an idea, a goal, and a story worth sharing."
        intro="We believe your website should reflect that. That's why we build websites around the people behind the business — not around templates."
      />

      <section className="py-20 sm:py-28">
        <div className="container-x grid gap-12 lg:grid-cols-[1fr_1.3fr] lg:gap-20">
          <SectionHeading eyebrow="Our purpose" title="Helping small businesses look as good online as they are in real life." />
          <div className="reveal space-y-5 text-[17px] leading-relaxed text-ink/80 sm:text-lg">
            <p>
              {AGENCY_NAME} is an independent web design and development studio working with small and local businesses across the United States — restaurants, salons, contractors, cleaning companies, shops and more.
            </p>
            <p>
              Many great businesses are held back by a website that&apos;s outdated, hard to use on a phone, or doesn&apos;t exist at all. Our purpose is to change that with websites that are professional, easy to use and fairly priced.
            </p>
            <p>
              We&apos;re committed to small businesses because we know every dollar matters. So we keep pricing clear, recommend only what you actually need, and make sure you understand every step.
            </p>
          </div>
        </div>
      </section>

      {/* Founder — edit name/role via env vars; edit bio text below */}
      <section className="bg-paper py-20 sm:py-28">
        <div className="container-x">
          <div className="reveal grid items-center gap-10 overflow-hidden rounded-2xl border border-line bg-white lg:grid-cols-[0.8fr_1.2fr]">
            {/*
              Founder visual: brand monogram (no photo is used, so nothing is faked).
              To use a real photo later, replace this block with
              <Image src="/founder.jpg" alt="..." fill className="object-cover" /> (see README).
            */}
            <div className="relative flex aspect-[4/3] items-center justify-center overflow-hidden bg-navy lg:aspect-auto lg:h-full lg:min-h-[440px]">
              <div className="grid-bg-dark absolute inset-0 [mask-image:radial-gradient(circle_at_center,black,transparent_75%)]" />
              <div className="pointer-events-none absolute -top-20 -right-20 h-64 w-64 rounded-full bg-accent/20 blur-3xl" />
              <div className="pointer-events-none absolute -bottom-24 -left-16 h-64 w-64 rounded-full bg-white/[0.06] blur-3xl" />
              <figure className="relative flex flex-col items-center px-6 text-center">
                <div className="relative">
                  <div className="absolute -inset-4 rounded-[36px] border border-white/10" aria-hidden="true" />
                  <svg viewBox="0 0 120 120" className="relative h-28 w-28 drop-shadow-[0_20px_40px_rgba(0,0,0,.35)] sm:h-36 sm:w-36" role="img" aria-label={`${AGENCY_NAME} monogram`}>
                    <defs>
                      <linearGradient id="founder-mark" x1="0" y1="0" x2="1" y2="1">
                        <stop offset="0" stopColor="#232b3f" />
                        <stop offset="1" stopColor="#111318" />
                      </linearGradient>
                    </defs>
                    <rect x="1" y="1" width="118" height="118" rx="30" fill="url(#founder-mark)" stroke="rgba(255,255,255,.14)" strokeWidth="2" />
                    <path d="M31 40h40" stroke="#fff" strokeWidth="9" strokeLinecap="round" />
                    <path d="M51 40v46" stroke="#fff" strokeWidth="9" strokeLinecap="round" />
                    <circle cx="84" cy="80" r="9.5" fill="#E44848" />
                  </svg>
                </div>
                <figcaption className="mt-8">
                  <span className="block font-display text-xl font-extrabold tracking-tight text-white">{AGENCY_NAME}</span>
                  <span className="mt-1 block text-[13px] font-medium tracking-[0.16em] text-white/65 uppercase">Independent web studio</span>
                </figcaption>
                <ul className="mt-6 flex flex-wrap justify-center gap-2" aria-label="What the studio does">
                  {["Design", "Development", "Ongoing care"].map((t) => (
                    <li key={t} className="rounded-full border border-white/15 bg-white/5 px-3 py-1 text-[12.5px] font-medium text-white/75">{t}</li>
                  ))}
                </ul>
              </figure>
            </div>
            <div className="p-8 sm:p-12 lg:pl-0">
              <p className="eyebrow">Meet the founder</p>
              <h2 className="mt-4 text-3xl font-extrabold text-ink sm:text-4xl">Hi, I&apos;m {FOUNDER_NAME.split(" ")[0]}.</h2>
              <p className="mt-1 font-medium text-muted">{FOUNDER_ROLE}</p>
              <div className="mt-6 space-y-4 text-[16.5px] leading-relaxed text-ink/80">
                <p>
                  I started {AGENCY_NAME} to give small business owners something that&apos;s surprisingly hard to find: a professional, custom website at a fair price — built by someone who actually listens.
                </p>
                <p>
                  When you work with the studio, you work directly with me, from the first conversation to launch day and beyond. I handle the design and development personally, and I&apos;ll always give you honest advice about what your business really needs.
                </p>
              </div>
              <div className="mt-8 flex flex-wrap gap-3">
                <Link href="/contact" className="btn-primary">
                  Let&apos;s Talk About Your Website <ArrowRight className="h-4 w-4" />
                </Link>
                {AGENCY_EMAIL && (
                  <a href={`mailto:${AGENCY_EMAIL}`} className="btn-ghost">Email {FOUNDER_NAME.split(" ")[0]}</a>
                )}
              </div>
            </div>
          </div>
        </div>
      </section>

      <section className="py-20 sm:py-28">
        <div className="container-x">
          <SectionHeading eyebrow="How we work" title="What you can expect from us." align="center" />
          <div className="mt-14 grid gap-px overflow-hidden rounded-xl border border-line bg-line sm:grid-cols-2 lg:grid-cols-4">
            {values.map(({ icon: Icon, title, body }) => (
              <div key={title} className="reveal bg-white p-8">
                <Icon className="h-6 w-6 text-accent" />
                <h3 className="mt-5 text-lg font-bold text-ink">{title}</h3>
                <p className="mt-2 text-[15px] leading-relaxed text-muted">{body}</p>
              </div>
            ))}
          </div>
          <div className="mt-12 text-center">
            <Link href={PORTFOLIO_URL} className="inline-flex items-center gap-1.5 font-semibold text-ink hover:text-accent">
              Explore Our Work <ArrowRight className="h-4 w-4" />
            </Link>
          </div>
        </div>
      </section>

      <ProcessSection compact />

      <CTASection title="We'd love to hear about your business." body="Tell us a little about what you do and what you have in mind. No pressure — just a friendly conversation and a clear estimate." />
    </>
  );
}
