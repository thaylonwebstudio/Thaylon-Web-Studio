import type { Metadata } from "next";
import { Info } from "lucide-react";
import { CTASection, PageHero } from "@/components/ui";
import { PortfolioGrid } from "@/components/PortfolioGrid";

export const metadata: Metadata = {
  title: "Portfolio — Website Design Demo Projects",
  description:
    "Explore nine complete demo websites for fictional restaurants, cleaning companies, barbershops, landscapers, roofers, detailers, salons, plumbers and retail stores.",
  alternates: { canonical: "/portfolio" },
};

export default function PortfolioPage() {
  return (
    <>
      <PageHero
        eyebrow="Portfolio"
        title="Picture your business here."
        intro="Nine complete, clickable demo websites — each with its own brand, goal and features — designed for the kinds of businesses we work with every day. Open one that's close to yours and imagine your name, photos and services on it."
      >
        <div className="mt-10 flex max-w-2xl gap-3 rounded-xl border border-line bg-white p-4 text-[14.5px] leading-relaxed text-ink/80 sm:p-5">
          <Info className="mt-0.5 h-5 w-5 shrink-0 text-accent" />
          <p>
            <strong className="font-semibold text-ink">Transparency note:</strong> every project on this page is a fictional business concept created to demonstrate our design and development capabilities. They are not real companies or paying clients.
          </p>
        </div>
      </PageHero>

      <section className="py-16 sm:py-20">
        <div className="container-x">
          <PortfolioGrid />
        </div>
      </section>

      <CTASection
        title="Like what you see? Let's talk about your website."
        body="Tell us which demo feels closest to your business and what you'd change. We'll shape it around your brand, your services and your customers."
      />
    </>
  );
}
