import Link from "next/link";
import type { Metadata } from "next";
import { ArrowLeft, ArrowRight } from "lucide-react";
import { Header } from "@/components/Header";
import { Footer } from "@/components/Footer";
import { PORTFOLIO_URL, QUOTE_PATH } from "@/config/site";

export const metadata: Metadata = {
  title: "Page Not Found",
  robots: { index: false, follow: true },
};

export default function NotFound() {
  return (
    <>
      <Header />
      <main id="main" className="relative overflow-hidden bg-paper">
        <div className="grid-bg pointer-events-none absolute inset-0 [mask-image:radial-gradient(ellipse_at_center,black,transparent_70%)]" />
        <div className="container-x relative flex min-h-[70vh] flex-col items-center justify-center py-24 text-center">
          <p className="font-display text-[120px] leading-none font-extrabold tracking-tighter text-ink sm:text-[180px]">
            4<span className="text-accent">0</span>4
          </p>
          <h1 className="mt-4 text-3xl font-extrabold text-ink sm:text-4xl">This page took a wrong turn.</h1>
          <p className="mt-4 max-w-md text-lg text-muted">
            The page you&apos;re looking for doesn&apos;t exist or has moved. Let&apos;s get you back on track.
          </p>
          <div className="mt-9 flex flex-col gap-3 sm:flex-row">
            <Link href="/" className="btn-dark"><ArrowLeft className="h-4 w-4" /> Back to Home</Link>
            <Link href={PORTFOLIO_URL} className="btn-ghost">View Portfolio</Link>
            <Link href={QUOTE_PATH} className="btn-primary">Get a Free Quote <ArrowRight className="h-4 w-4" /></Link>
          </div>
        </div>
      </main>
      <Footer />
    </>
  );
}
