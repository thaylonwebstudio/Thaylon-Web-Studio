import type { Metadata, Viewport } from "next";
import "@fontsource-variable/inter";
import "@fontsource-variable/manrope";
// Demo-project fonts (only @font-face rules; files download only when used)
import "@fontsource-variable/playfair-display";
import "@fontsource-variable/fraunces";
import "@fontsource-variable/cormorant-garamond";
import "@fontsource-variable/oswald";
import "@fontsource-variable/space-grotesk";
import "@fontsource-variable/archivo";
import "@fontsource-variable/dm-sans";
import "@fontsource/bebas-neue";
import "./globals.css";
import { AGENCY_NAME, SITE_DESCRIPTION, SITE_URL, TAGLINE } from "@/config/site";

export const metadata: Metadata = {
  metadataBase: new URL(SITE_URL),
  title: {
    default: `${AGENCY_NAME} — Affordable Website Design for Small Businesses`,
    template: `%s | ${AGENCY_NAME}`,
  },
  description: SITE_DESCRIPTION,
  applicationName: AGENCY_NAME,
  keywords: [
    "affordable website design for small businesses",
    "small business website development",
    "website redesign",
    "website designer for local businesses",
    "restaurant website design",
    "cleaning company website design",
    "landscaping website design",
  ],
  alternates: { canonical: "/" },
  openGraph: {
    type: "website",
    siteName: AGENCY_NAME,
    title: `${AGENCY_NAME} — ${TAGLINE}`,
    description: SITE_DESCRIPTION,
    url: "/",
    locale: "en_US",
  },
  twitter: {
    card: "summary_large_image",
    title: `${AGENCY_NAME} — ${TAGLINE}`,
    description: SITE_DESCRIPTION,
  },
  robots: { index: true, follow: true },
};

export const viewport: Viewport = {
  themeColor: "#101827",
  width: "device-width",
  initialScale: 1,
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en-US">
      <body className="min-h-dvh">{children}</body>
    </html>
  );
}
