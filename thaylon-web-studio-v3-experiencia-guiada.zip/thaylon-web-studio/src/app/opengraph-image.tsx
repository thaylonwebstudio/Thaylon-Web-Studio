import { ImageResponse } from "next/og";
import { AGENCY_NAME, TAGLINE } from "@/config/site";

export const dynamic = "force-static";
export const alt = `${AGENCY_NAME} — ${TAGLINE}`;
export const size = { width: 1200, height: 630 };
export const contentType = "image/png";

export default function OpengraphImage() {
  return new ImageResponse(
    (
      <div
        style={{
          width: "100%",
          height: "100%",
          display: "flex",
          flexDirection: "column",
          justifyContent: "space-between",
          padding: 80,
          background: "#101827",
          color: "#fff",
          fontFamily: "sans-serif",
        }}
      >
        <div style={{ display: "flex", alignItems: "center", gap: 20 }}>
          <div style={{ width: 64, height: 64, borderRadius: 16, background: "#111318", border: "2px solid #2a3348", display: "flex", alignItems: "center", justifyContent: "center", position: "relative" }}>
            <div style={{ position: "absolute", left: 16, top: 20, width: 22, height: 5, background: "#fff", borderRadius: 3 }} />
            <div style={{ position: "absolute", left: 25, top: 20, width: 5, height: 26, background: "#fff", borderRadius: 3 }} />
            <div style={{ position: "absolute", left: 38, top: 37, width: 11, height: 11, background: "#E44848", borderRadius: 99 }} />
          </div>
          <div style={{ fontSize: 34, fontWeight: 800 }}>{AGENCY_NAME}</div>
        </div>
        <div style={{ display: "flex", flexDirection: "column" }}>
          <div style={{ fontSize: 76, fontWeight: 800, lineHeight: 1.05, letterSpacing: -2 }}>Your Business Deserves</div>
          <div style={{ fontSize: 76, fontWeight: 800, lineHeight: 1.05, letterSpacing: -2, color: "#E44848" }}>a Better Website.</div>
        </div>
        <div style={{ display: "flex", justifyContent: "space-between", fontSize: 26, color: "#a5adbb" }}>
          <span>{TAGLINE}</span>
          <span>Web Design · Development · Redesign</span>
        </div>
      </div>
    ),
    size,
  );
}
