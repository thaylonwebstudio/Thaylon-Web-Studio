"use client";

import { useState } from "react";
import { Building2, CalendarCheck, Check, Home, Leaf, Mail, MapPin, Phone, ShieldCheck, Sparkles, Truck, UserCheck } from "lucide-react";
import { HomeSparkleArt, MapArt } from "@/components/art/Art";
import { DemoForm, DemoNav } from "./shared";

const NAME = "FreshHome Cleaning";

const services = [
  { icon: Home, t: "Standard Cleaning", d: "Dusting, vacuuming, mopping, kitchens and bathrooms — the full refresh, on your schedule." },
  { icon: Sparkles, t: "Deep Cleaning", d: "Baseboards, inside appliances, grout and the hard-to-reach spots. Perfect for spring." },
  { icon: Truck, t: "Move-In / Move-Out", d: "A top-to-bottom clean so you can hand over the keys — or move in — with confidence." },
  { icon: Building2, t: "Small Office", d: "After-hours cleaning for small offices and studios, weekly or bi-weekly." },
];

const packages = [
  { n: "Essential", base: 129, desc: "Studios & 1-bedroom homes", f: ["Kitchen & bathrooms", "Dusting & vacuuming", "Floors mopped", "Trash removal"] },
  { n: "Family", base: 169, desc: "2–3 bedroom homes", f: ["Everything in Essential", "Bedrooms & living areas", "Interior windows (reachable)", "Bed making"], pop: true },
  { n: "Spotless", base: 229, desc: "4+ bedroom homes", f: ["Everything in Family", "Inside microwave & oven", "Baseboards & doors", "Priority scheduling"] },
];

const freq = [
  { k: "once", l: "One-time", m: 1 },
  { k: "biweekly", l: "Every 2 weeks", m: 0.85 },
  { k: "weekly", l: "Weekly", m: 0.8 },
] as const;

const areas = ["Maple Grove", "Cedar Falls", "Riverside", "Oak Hill", "Brookfield", "Lakeview", "Pine Ridge", "Westbrook"];

export default function FreshHome() {
  const [f, setF] = useState<(typeof freq)[number]["k"]>("biweekly");
  const mult = freq.find((x) => x.k === f)!.m;

  return (
    <div id="top" className="bg-[#f3fbf8] font-[family-name:var(--font-dmsans)] text-[#0f3d3e]">
      <DemoNav
        brand={
          <span className="flex items-center gap-2 text-xl font-bold tracking-tight">
            <span className="flex h-9 w-9 items-center justify-center rounded-xl bg-[#25b39a] text-white"><Sparkles className="h-5 w-5" /></span>
            FreshHome
          </span>
        }
        links={[
          { label: "Services", href: "#services" },
          { label: "Pricing", href: "#pricing" },
          { label: "Service Areas", href: "#areas" },
          { label: "Contact", href: "#contact" },
        ]}
        cta={{ label: "Get a Free Quote", href: "#quote" }}
        className="bg-white/90 backdrop-blur border-b border-[#0f3d3e]/10 text-[#0f3d3e]"
        linkClass="text-[15px] font-medium text-[#0f3d3e]/70 hover:text-[#0f3d3e]"
        ctaClass="rounded-xl bg-[#0f3d3e] px-5 py-2.5 text-sm font-semibold text-white hover:bg-[#145052]"
        menuClass="bg-white border-t border-[#0f3d3e]/10"
      />

      {/* HERO */}
      <section className="mx-auto grid max-w-[1200px] items-center gap-12 px-5 py-14 sm:px-8 md:grid-cols-2 md:py-20">
        <div>
          <span className="inline-flex items-center gap-2 rounded-full bg-[#25b39a]/10 px-3 py-1.5 text-sm font-semibold text-[#11705f]">
            <Leaf className="h-4 w-4" /> Eco-friendly products, always
          </span>
          <h1 className="mt-6 text-[44px] leading-[1.05] font-bold tracking-tight sm:text-[60px]">
            A cleaner home, <span className="text-[#25b39a]">without the hassle.</span>
          </h1>
          <p className="mt-5 max-w-lg text-lg text-[#5b7d7b]">
            Reliable, detail-obsessed residential cleaning. Book a one-time deep clean or set up a recurring schedule — we bring everything.
          </p>
          <div className="mt-8 flex flex-wrap gap-3">
            <a href="#quote" className="rounded-xl bg-[#25b39a] px-6 py-3.5 font-semibold text-white shadow-lg shadow-[#25b39a]/30 transition hover:bg-[#1e9c86]">Get a Free Quote</a>
            <a href="#pricing" className="rounded-xl border border-[#0f3d3e]/15 bg-white px-6 py-3.5 font-semibold transition hover:border-[#0f3d3e]/35">See Pricing</a>
          </div>
          <ul className="mt-10 grid gap-3 sm:grid-cols-3">
            {[{ i: UserCheck, t: "Background-checked team" }, { i: ShieldCheck, t: "Insured & bonded" }, { i: CalendarCheck, t: "Flexible scheduling" }].map(({ i: I, t }) => (
              <li key={t} className="flex items-center gap-2 text-sm font-medium"><I className="h-5 w-5 text-[#25b39a]" />{t}</li>
            ))}
          </ul>
        </div>
        <div className="relative">
          <div className="absolute inset-0 -z-0 rounded-[40px] bg-gradient-to-br from-[#bfe9df] to-[#fff3d6]" />
          <HomeSparkleArt className="relative w-full p-6" />
          <div className="absolute -bottom-5 left-6 rounded-2xl bg-white px-5 py-4 shadow-xl">
            <p className="text-xs font-semibold tracking-wide text-[#5b7d7b] uppercase">Next available</p>
            <p className="mt-0.5 font-bold">This Thursday · 9:00 AM</p>
          </div>
        </div>
      </section>

      {/* SERVICES */}
      <section id="services" className="bg-white py-20 sm:py-24">
        <div className="mx-auto max-w-[1200px] px-5 sm:px-8">
          <div className="max-w-xl">
            <p className="font-semibold text-[#25b39a]">Our services</p>
            <h2 className="mt-2 text-4xl font-bold tracking-tight sm:text-5xl">Cleaning for every corner of your life.</h2>
          </div>
          <div className="mt-12 grid gap-5 sm:grid-cols-2 lg:grid-cols-4">
            {services.map(({ icon: I, t, d }) => (
              <div key={t} className="group rounded-3xl border border-[#0f3d3e]/10 bg-[#f3fbf8] p-7 transition hover:-translate-y-1 hover:border-[#25b39a]/40 hover:shadow-xl hover:shadow-[#25b39a]/10">
                <span className="flex h-12 w-12 items-center justify-center rounded-2xl bg-white text-[#25b39a] shadow-sm transition group-hover:bg-[#25b39a] group-hover:text-white"><I className="h-6 w-6" /></span>
                <h3 className="mt-5 text-lg font-bold">{t}</h3>
                <p className="mt-2 text-[15px] leading-relaxed text-[#5b7d7b]">{d}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* PRICING */}
      <section id="pricing" className="py-20 sm:py-24">
        <div className="mx-auto max-w-[1200px] px-5 sm:px-8">
          <div className="flex flex-col items-start justify-between gap-6 md:flex-row md:items-end">
            <div className="max-w-xl">
              <p className="font-semibold text-[#25b39a]">Service packages</p>
              <h2 className="mt-2 text-4xl font-bold tracking-tight sm:text-5xl">Simple, honest pricing.</h2>
              <p className="mt-3 text-[#5b7d7b]">Starting prices per visit. Save with a recurring schedule.</p>
            </div>
            <div role="group" aria-label="Cleaning frequency" className="inline-flex max-w-full flex-wrap rounded-2xl border border-[#0f3d3e]/10 bg-white p-1">
              {freq.map((x) => (
                <button key={x.k} type="button" aria-pressed={f === x.k} onClick={() => setF(x.k)} className={`min-h-10 rounded-xl px-3 py-2 text-sm font-semibold transition sm:px-4 ${f === x.k ? "bg-[#0f3d3e] text-white" : "text-[#0f3d3e]/70 hover:text-[#0f3d3e]"}`}>
                  {x.l}
                  {x.m < 1 && <span className={`ml-1.5 text-xs ${f === x.k ? "text-[#7fe0cd]" : "text-[#25b39a]"}`}>-{Math.round((1 - x.m) * 100)}%</span>}
                </button>
              ))}
            </div>
          </div>
          <div className="mt-12 grid gap-6 md:grid-cols-3">
            {packages.map((p) => (
              <div key={p.n} className={`relative flex flex-col rounded-3xl p-8 ${p.pop ? "bg-[#0f3d3e] text-white shadow-2xl shadow-[#0f3d3e]/30" : "border border-[#0f3d3e]/10 bg-white"}`}>
                {p.pop && <span className="absolute -top-3 right-6 rounded-full bg-[#f6b73c] px-3 py-1 text-xs font-bold text-[#0f3d3e]">Most booked</span>}
                <h3 className="text-xl font-bold">{p.n}</h3>
                <p className={p.pop ? "text-white/70" : "text-[#5b7d7b]"}>{p.desc}</p>
                <p className="mt-6 flex items-baseline gap-1">
                  <span className="text-sm">from</span>
                  <span className="text-5xl font-bold tracking-tight">${Math.round(p.base * mult)}</span>
                  <span className={p.pop ? "text-white/60" : "text-[#5b7d7b]"}>/visit</span>
                </p>
                <ul className="mt-6 space-y-3">
                  {p.f.map((x) => (
                    <li key={x} className="flex gap-3 text-[15px]"><Check className="h-5 w-5 shrink-0 text-[#25b39a]" />{x}</li>
                  ))}
                </ul>
                <a href="#quote" className={`mt-8 rounded-xl py-3.5 text-center font-semibold transition ${p.pop ? "bg-[#25b39a] text-white hover:bg-[#1e9c86]" : "bg-[#f3fbf8] hover:bg-[#e2f5ef]"}`}>Choose {p.n}</a>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* AREAS */}
      <section id="areas" className="bg-white py-20 sm:py-24">
        <div className="mx-auto grid max-w-[1200px] items-center gap-12 px-5 sm:px-8 md:grid-cols-2">
          <div className="overflow-hidden rounded-3xl border border-[#0f3d3e]/10">
            <MapArt className="aspect-[4/3] w-full" land="#eef7f3" water="#cbe8f0" park="#cfeedd" pin="#25b39a" />
          </div>
          <div>
            <p className="font-semibold text-[#25b39a]">Service areas</p>
            <h2 className="mt-2 text-4xl font-bold tracking-tight">Proudly serving the greater Anytown area.</h2>
            <p className="mt-4 text-[#5b7d7b]">Don&apos;t see your neighborhood? Ask us — we&apos;re expanding regularly.</p>
            <ul className="mt-8 grid grid-cols-2 gap-3">
              {areas.map((a) => (
                <li key={a} className="flex items-center gap-2 rounded-xl bg-[#f3fbf8] px-4 py-3 font-medium"><MapPin className="h-4 w-4 text-[#25b39a]" />{a}</li>
              ))}
            </ul>
          </div>
        </div>
      </section>

      {/* QUOTE */}
      <section id="quote" className="py-20 sm:py-24">
        <div className="mx-auto max-w-[900px] px-5 sm:px-8">
          <div className="text-center">
            <p className="font-semibold text-[#25b39a]">Free, no-obligation quote</p>
            <h2 className="mt-2 text-4xl font-bold tracking-tight sm:text-5xl">Get your price in minutes.</h2>
          </div>
          <DemoForm
            demoName={NAME}
            submitLabel="Get My Free Quote"
            className="mt-10 grid gap-5 rounded-3xl border border-[#0f3d3e]/10 bg-white p-6 shadow-xl shadow-[#0f3d3e]/5 sm:grid-cols-2 sm:p-10"
            buttonClass="sm:col-span-2 rounded-xl bg-[#25b39a] py-4 font-semibold text-white hover:bg-[#1e9c86] transition"
            noticeClass="sm:col-span-2 border-[#25b39a]/30 bg-[#f3fbf8] text-[#0f3d3e]"
          >
            {[
              { l: "Full name", n: "name", t: "text", ac: "name" },
              { l: "Email", n: "email", t: "email", ac: "email" },
              { l: "Phone", n: "phone", t: "tel", ac: "tel" },
              { l: "ZIP code", n: "zip", t: "text", ac: "postal-code" },
            ].map((x) => (
              <label key={x.n} className="block text-sm font-semibold">
                {x.l}
                <input required name={x.n} type={x.t} autoComplete={x.ac} className="mt-2 w-full rounded-xl border border-[#0f3d3e]/15 px-4 py-3 font-normal outline-none focus:border-[#25b39a] focus:ring-4 focus:ring-[#25b39a]/15" />
              </label>
            ))}
            {[
              { l: "Service", n: "service", o: ["Standard Cleaning", "Deep Cleaning", "Move-In / Move-Out", "Small Office"] },
              { l: "Frequency", n: "frequency", o: ["One-time", "Weekly", "Every 2 weeks", "Monthly"] },
              { l: "Bedrooms", n: "beds", o: ["Studio", "1", "2", "3", "4", "5+"] },
              { l: "Bathrooms", n: "baths", o: ["1", "1.5", "2", "2.5", "3+"] },
            ].map((x) => (
              <label key={x.n} className="block text-sm font-semibold">
                {x.l}
                <select required name={x.n} defaultValue="" className="mt-2 w-full rounded-xl border border-[#0f3d3e]/15 bg-white px-4 py-3 font-normal outline-none focus:border-[#25b39a]">
                  <option value="" disabled>Select…</option>
                  {x.o.map((o) => <option key={o}>{o}</option>)}
                </select>
              </label>
            ))}
            <label className="block text-sm font-semibold sm:col-span-2">
              Anything we should know? <span className="font-normal text-[#5b7d7b]">(optional)</span>
              <textarea name="notes" rows={3} className="mt-2 w-full rounded-xl border border-[#0f3d3e]/15 px-4 py-3 font-normal outline-none focus:border-[#25b39a]" placeholder="Pets, access instructions, areas to focus on…" />
            </label>
          </DemoForm>
        </div>
      </section>

      {/* CONTACT */}
      <section id="contact" className="bg-[#0f3d3e] text-white">
        <div className="mx-auto grid max-w-[1200px] gap-10 px-5 py-16 sm:px-8 md:grid-cols-3">
          <div>
            <p className="flex items-center gap-2 text-xl font-bold"><Sparkles className="h-5 w-5 text-[#25b39a]" /> FreshHome Cleaning</p>
            <p className="mt-3 text-white/65">Residential cleaning you can count on. Fictional company created for demonstration.</p>
          </div>
          <div className="space-y-3">
            <a href="tel:+15550100147" className="flex items-center gap-3 text-white/85 hover:text-white"><Phone className="h-5 w-5 text-[#25b39a]" /> (555) 010-0147</a>
            <a href="mailto:hello@freshhome.example" className="flex items-center gap-3 text-white/85 hover:text-white"><Mail className="h-5 w-5 text-[#25b39a]" /> hello@freshhome.example</a>
            <p className="flex items-center gap-3 text-white/85"><MapPin className="h-5 w-5 text-[#25b39a]" /> Serving Anytown & nearby</p>
          </div>
          <div>
            <p className="font-semibold">Office hours</p>
            <p className="mt-2 text-white/65">Mon–Fri · 8:00 AM – 6:00 PM<br />Sat · 9:00 AM – 2:00 PM</p>
          </div>
        </div>
        <p className="border-t border-white/10 py-6 text-center text-sm text-white/45">© FreshHome Cleaning (demo). All rights reserved.</p>
      </section>
    </div>
  );
}
