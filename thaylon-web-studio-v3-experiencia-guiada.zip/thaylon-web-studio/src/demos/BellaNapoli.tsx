import { CakeSlice, Clock, Flame, MapPin, Phone, Pizza, Salad, Soup, Wine, Wheat } from "lucide-react";
import { MapArt, PizzaArt } from "@/components/art/Art";
import { DemoForm, DemoNav } from "./shared";

const NAME = "Bella Napoli";
const c = { bg: "#1c1410", bg2: "#241a14", cream: "#f6ecdc", red: "#d1492e", gold: "#e9b872", muted: "#bba68a" };

const menu = [
  {
    cat: "Antipasti",
    items: [
      { n: "Burrata Pugliese", d: "Creamy burrata, heirloom tomatoes, basil oil, sea salt", p: "16", t: ["V", "GF"] },
      { n: "Arancini Siciliani", d: "Saffron risotto, mozzarella, slow-cooked ragù", p: "13", t: [] },
      { n: "Calamari Fritti", d: "Crispy squid, lemon aioli, Calabrian chili", p: "15", t: [] },
    ],
  },
  {
    cat: "Pizze al Forno",
    items: [
      { n: "Margherita D.O.P.", d: "San Marzano tomato, fior di latte, basil, olive oil", p: "17", t: ["V"] },
      { n: "Diavola", d: "Spicy salame, tomato, mozzarella, chili honey", p: "19", t: [] },
      { n: "Tartufo Bianco", d: "White base, mushrooms, truffle cream, arugula", p: "22", t: ["V"] },
      { n: "Quattro Formaggi", d: "Mozzarella, gorgonzola, fontina, parmigiano", p: "20", t: ["V"] },
    ],
  },
  {
    cat: "Pasta Fresca",
    items: [
      { n: "Cacio e Pepe", d: "Tonnarelli, pecorino romano, cracked black pepper", p: "18", t: ["V"] },
      { n: "Pappardelle al Ragù", d: "Hand-cut pasta, eight-hour beef & pork ragù", p: "23", t: [] },
      { n: "Linguine alle Vongole", d: "Littleneck clams, garlic, white wine, parsley", p: "25", t: [] },
    ],
  },
  {
    cat: "Dolci",
    items: [
      { n: "Tiramisù della Casa", d: "Espresso-soaked savoiardi, mascarpone, cocoa", p: "10", t: ["V"] },
      { n: "Cannoli Siciliani", d: "Ricotta, pistachio, candied orange", p: "9", t: ["V"] },
    ],
  },
];

const gallery = [
  { icon: Pizza, label: "Margherita from the wood oven", bg: "linear-gradient(135deg,#7a2a17,#d1492e)", span: "md:col-span-2 md:row-span-2" },
  { icon: Wine, label: "Italian wine list", bg: "linear-gradient(135deg,#3b1020,#7a2340)", span: "" },
  { icon: Soup, label: "Fresh pasta, made daily", bg: "linear-gradient(135deg,#8a5a1f,#e9b872)", span: "" },
  { icon: Salad, label: "Seasonal antipasti", bg: "linear-gradient(135deg,#2d4a22,#6c8f3d)", span: "" },
  { icon: CakeSlice, label: "House tiramisù", bg: "linear-gradient(135deg,#3a2618,#8a6448)", span: "" },
];

export default function BellaNapoli() {
  return (
    <div id="top" style={{ background: c.bg, color: c.cream }} className="font-[family-name:var(--font-playfair)]">
      <DemoNav
        brand={
          <span className="flex flex-col leading-none">
            <span className="text-2xl font-semibold italic" style={{ color: c.cream }}>Bella Napoli</span>
            <span className="mt-1 font-sans text-[9px] tracking-[0.35em] uppercase" style={{ color: c.gold }}>Pizzeria · Cucina</span>
          </span>
        }
        links={[
          { label: "Menu", href: "#menu" },
          { label: "Gallery", href: "#gallery" },
          { label: "Reservations", href: "#reserve" },
          { label: "Visit", href: "#visit" },
        ]}
        cta={{ label: "Reserve a Table", href: "#reserve" }}
        className="border-b border-[#f6ecdc]/10 bg-[#1c1410]/90 text-[#f6ecdc] backdrop-blur"
        linkClass="font-sans text-sm tracking-wide text-[#f6ecdc]/75 hover:text-[#e9b872] transition"
        ctaClass="font-sans text-sm font-semibold rounded-full bg-[#d1492e] px-5 py-2.5 text-white hover:bg-[#b83b23] transition"
        menuClass="border-t border-[#f6ecdc]/10 bg-[#1c1410] font-sans"
      />

      {/* HERO */}
      <section className="relative overflow-hidden">
        <div className="pointer-events-none absolute -top-40 -right-40 h-[520px] w-[520px] rounded-full opacity-30 blur-3xl" style={{ background: c.red }} />
        <div className="relative mx-auto grid max-w-[1200px] items-center gap-12 px-5 py-16 sm:px-8 md:grid-cols-[1.1fr_1fr] md:py-24">
          <div>
            <p className="font-sans text-[12px] font-semibold tracking-[0.3em] uppercase" style={{ color: c.gold }}>
              Est. on Mulberry Lane · Anytown
            </p>
            <h1 className="mt-6 text-[52px] leading-[0.98] font-medium sm:text-[76px]">
              Wood-fired, <em className="italic" style={{ color: c.gold }}>the Neapolitan</em> way.
            </h1>
            <p className="mt-6 max-w-md font-sans text-lg leading-relaxed" style={{ color: c.muted }}>
              Hand-stretched dough, rested for 48 hours and fired at 900°F. Fresh pasta, Italian wines and a table that always feels like home.
            </p>
            <div className="mt-9 flex flex-wrap gap-3 font-sans">
              <a href="#reserve" className="rounded-full px-7 py-3.5 text-[15px] font-semibold text-white transition hover:brightness-110" style={{ background: c.red }}>Reserve a Table</a>
              <a href="#menu" className="rounded-full border px-7 py-3.5 text-[15px] font-semibold transition hover:bg-white/5" style={{ borderColor: `${c.cream}40` }}>View the Menu</a>
            </div>
            <dl className="mt-12 grid max-w-md grid-cols-3 gap-6 border-t pt-6 font-sans" style={{ borderColor: `${c.cream}1a` }}>
              {[["900°F", "Wood oven"], ["48h", "Dough rest"], ["Daily", "Fresh pasta"]].map(([a, b]) => (
                <div key={b}>
                  <dt className="text-[11px] tracking-[0.2em] uppercase" style={{ color: c.muted }}>{b}</dt>
                  <dd className="mt-1 font-[family-name:var(--font-playfair)] text-2xl" style={{ color: c.cream }}>{a}</dd>
                </div>
              ))}
            </dl>
          </div>
          <div className="relative mx-auto w-full max-w-[480px]">
            <div className="absolute inset-6 rounded-full border border-dashed" style={{ borderColor: `${c.gold}55` }} />
            <PizzaArt className="relative w-full drop-shadow-2xl" />
            <div className="absolute -bottom-2 left-0 flex items-center gap-3 rounded-2xl px-4 py-3 font-sans shadow-xl" style={{ background: c.cream, color: c.bg }}>
              <Flame className="h-5 w-5" style={{ color: c.red }} />
              <div className="text-sm leading-tight"><b>Margherita D.O.P.</b><br /><span className="opacity-70">Our signature since day one</span></div>
            </div>
          </div>
        </div>
      </section>

      {/* STORY STRIP */}
      <section style={{ background: c.cream, color: c.bg }}>
        <div className="mx-auto grid max-w-[1200px] gap-8 px-5 py-14 sm:px-8 md:grid-cols-3">
          {[
            { i: Wheat, t: "Imported Italian flour", d: "Caputo 00 flour and San Marzano tomatoes for an authentic taste." },
            { i: Flame, t: "Fired in 90 seconds", d: "Our hand-built oven gives every pizza its leopard-spotted crust." },
            { i: Wine, t: "A thoughtful wine list", d: "Regional Italian wines, chosen to pair with every course." },
          ].map(({ i: Icon, t, d }) => (
            <div key={t} className="flex gap-4">
              <Icon className="mt-1 h-6 w-6 shrink-0" style={{ color: c.red }} />
              <div>
                <h2 className="text-xl font-semibold">{t}</h2>
                <p className="mt-1 font-sans text-[15px] opacity-75">{d}</p>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* MENU */}
      <section id="menu" className="mx-auto max-w-[1200px] px-5 py-20 sm:px-8 sm:py-28">
        <div className="text-center">
          <p className="font-sans text-[12px] font-semibold tracking-[0.3em] uppercase" style={{ color: c.gold }}>Il Menù</p>
          <h2 className="mt-4 text-5xl font-medium sm:text-6xl">Our Menu</h2>
          <p className="mx-auto mt-4 max-w-lg font-sans" style={{ color: c.muted }}>
            Seasonal ingredients, classic recipes. <span className="whitespace-nowrap">V = vegetarian · GF = gluten-free</span>
          </p>
        </div>
        <div className="mt-16 grid gap-x-16 gap-y-14 md:grid-cols-2">
          {menu.map((group) => (
            <div key={group.cat}>
              <h3 className="flex items-center gap-4 text-2xl italic" style={{ color: c.gold }}>
                {group.cat}
                <span className="h-px flex-1" style={{ background: `${c.gold}40` }} />
              </h3>
              <ul className="mt-6 space-y-6">
                {group.items.map((it) => (
                  <li key={it.n}>
                    <div className="flex items-baseline gap-3">
                      <span className="text-xl">{it.n}</span>
                      {it.t.map((t) => (
                        <span key={t} className="rounded border px-1.5 font-sans text-[10px] font-bold tracking-wider" style={{ borderColor: `${c.muted}66`, color: c.muted }}>{t}</span>
                      ))}
                      <span className="mb-1 flex-1 border-b border-dotted" style={{ borderColor: `${c.cream}33` }} />
                      <span className="font-sans text-lg font-semibold" style={{ color: c.gold }}>${it.p}</span>
                    </div>
                    <p className="mt-1 font-sans text-[14.5px]" style={{ color: c.muted }}>{it.d}</p>
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>
      </section>

      {/* GALLERY */}
      <section id="gallery" style={{ background: c.bg2 }}>
        <div className="mx-auto max-w-[1200px] px-5 py-20 sm:px-8 sm:py-28">
          <div className="flex flex-col justify-between gap-4 md:flex-row md:items-end">
            <h2 className="text-5xl font-medium">From our kitchen</h2>
            <p className="max-w-sm font-sans" style={{ color: c.muted }}>A taste of what&apos;s waiting for you — straight from the oven to your table.</p>
          </div>
          <div className="mt-12 grid auto-rows-[180px] grid-cols-2 gap-4 md:grid-cols-4 md:auto-rows-[220px]">
            {gallery.map(({ icon: Icon, label, bg, span }) => (
              <figure key={label} className={`group relative overflow-hidden rounded-2xl ${span}`} style={{ background: bg }}>
                <Icon className="absolute top-1/2 left-1/2 h-1/3 w-1/3 -translate-x-1/2 -translate-y-1/2 text-white/25 transition duration-500 group-hover:scale-110" strokeWidth={1} />
                <figcaption className="absolute inset-x-0 bottom-0 bg-gradient-to-t from-black/60 to-transparent p-4 font-sans text-sm font-medium">{label}</figcaption>
              </figure>
            ))}
          </div>
        </div>
      </section>

      {/* RESERVATION */}
      <section id="reserve" className="mx-auto grid max-w-[1200px] gap-12 px-5 py-20 sm:px-8 sm:py-28 md:grid-cols-[1fr_1.2fr]">
        <div>
          <p className="font-sans text-[12px] font-semibold tracking-[0.3em] uppercase" style={{ color: c.gold }}>Prenota</p>
          <h2 className="mt-4 text-5xl font-medium">Reserve your table</h2>
          <p className="mt-5 font-sans text-lg" style={{ color: c.muted }}>
            Request a reservation and we&apos;ll confirm by phone or email. For parties of 8 or more, please call us directly.
          </p>
          <a href="tel:+15550100123" className="mt-8 inline-flex items-center gap-3 font-sans text-lg" style={{ color: c.cream }}>
            <Phone className="h-5 w-5" style={{ color: c.red }} /> (555) 010-0123
          </a>
        </div>
        <DemoForm
          demoName={NAME}
          submitLabel="Request Reservation"
          className="grid gap-4 rounded-3xl p-6 font-sans sm:grid-cols-2 sm:p-8"
          buttonClass="sm:col-span-2 mt-2 rounded-full py-4 font-semibold text-white bg-[#d1492e] hover:bg-[#b83b23] transition"
          noticeClass="sm:col-span-2 border-[#e9b872]/40 bg-[#2c2019] text-[#f6ecdc]"
        >
          {[
            { l: "Name", t: "text", n: "name", ac: "name" },
            { l: "Phone", t: "tel", n: "phone", ac: "tel" },
            { l: "Date", t: "date", n: "date" },
            { l: "Time", t: "time", n: "time" },
          ].map((f) => (
            <label key={f.n} className="block text-sm" style={{ color: c.muted }}>
              {f.l}
              <input required type={f.t} name={f.n} autoComplete={f.ac} className="mt-1.5 w-full rounded-xl border bg-transparent px-4 py-3 text-[#f6ecdc] outline-none [color-scheme:dark] focus:border-[#e9b872]" style={{ borderColor: `${c.cream}26` }} />
            </label>
          ))}
          <label className="block text-sm sm:col-span-2" style={{ color: c.muted }}>
            Party size
            <select required name="party" defaultValue="" className="mt-1.5 w-full rounded-xl border bg-[#1c1410] px-4 py-3 text-[#f6ecdc] outline-none focus:border-[#e9b872]" style={{ borderColor: `${c.cream}26` }}>
              <option value="" disabled>Select…</option>
              {["1 guest", "2 guests", "3 guests", "4 guests", "5 guests", "6 guests", "7 guests"].map((o) => <option key={o}>{o}</option>)}
            </select>
          </label>
          <label className="block text-sm sm:col-span-2" style={{ color: c.muted }}>
            Special requests (optional)
            <textarea name="notes" rows={3} className="mt-1.5 w-full rounded-xl border bg-transparent px-4 py-3 text-[#f6ecdc] outline-none focus:border-[#e9b872]" style={{ borderColor: `${c.cream}26` }} />
          </label>
        </DemoForm>
      </section>

      {/* VISIT */}
      <section id="visit" style={{ background: c.cream, color: c.bg }}>
        <div className="mx-auto grid max-w-[1200px] gap-10 px-5 py-20 sm:px-8 md:grid-cols-2">
          <div>
            <h2 className="text-5xl font-medium">Visit us</h2>
            <ul className="mt-8 space-y-6 font-sans text-[16px]">
              <li className="flex gap-4"><MapPin className="h-5 w-5 shrink-0" style={{ color: c.red }} /> <span>123 Mulberry Lane<br />Anytown, USA 00000</span></li>
              <li className="flex gap-4"><Phone className="h-5 w-5 shrink-0" style={{ color: c.red }} /> <span>(555) 010-0123<br />hello@bellanapoli.example</span></li>
              <li className="flex gap-4">
                <Clock className="h-5 w-5 shrink-0" style={{ color: c.red }} />
                <table className="text-left"><tbody>
                  {[["Mon", "Closed"], ["Tue – Thu", "5:00 – 10:00 pm"], ["Fri – Sat", "5:00 – 11:00 pm"], ["Sunday", "12:00 – 9:00 pm"]].map(([d, h]) => (
                    <tr key={d}><td className="pr-8 pb-1 opacity-70">{d}</td><td className="pb-1 font-medium">{h}</td></tr>
                  ))}
                </tbody></table>
              </li>
            </ul>
          </div>
          <div className="overflow-hidden rounded-3xl shadow-xl">
            <MapArt className="h-full min-h-[300px] w-full" land="#efe4d0" water="#d7e3df" park="#d9e0bf" pin={c.red} />
          </div>
        </div>
      </section>

      <footer className="border-t font-sans text-sm" style={{ borderColor: `${c.cream}1a`, color: c.muted }}>
        <div className="mx-auto flex max-w-[1200px] flex-col justify-between gap-4 px-5 py-8 sm:flex-row sm:px-8">
          <p><span className="font-[family-name:var(--font-playfair)] text-lg italic" style={{ color: c.cream }}>Bella Napoli</span> · Fictional restaurant concept</p>
          <p>© Bella Napoli (demo). All rights reserved.</p>
        </div>
      </footer>
    </div>
  );
}
