"use client";

import { useMemo, useState } from "react";
import { ArrowUpRight, Clock, Mail, MapPin, Phone, Store } from "lucide-react";
import { GoodsArt, MapArt } from "@/components/art/Art";
import { DemoNav } from "./shared";

type Kind = "mug" | "candle" | "tote" | "plant" | "bottle" | "throw" | "bowl" | "notebook";

function ProductArt({ kind, color }: { kind: Kind; color: string }) {
  const s = "#1f1d1a";
  return (
    <svg viewBox="0 0 200 200" className="h-full w-full" aria-hidden="true">
      <ellipse cx="100" cy="172" rx="58" ry="8" fill="#000" opacity=".08" />
      {kind === "mug" && (<><rect x="58" y="70" width="70" height="98" rx="10" fill={color} /><path d="M128 92 c 28 0, 28 44, 0 44" stroke={color} strokeWidth="12" fill="none" /></>)}
      {kind === "candle" && (<><rect x="62" y="82" width="76" height="86" rx="8" fill={color} /><rect x="62" y="110" width="76" height="30" fill="#f5ead9" /><path d="M100 82 v -14" stroke={s} strokeWidth="3" /><path d="M100 50 c 8 10, 6 18, 0 18 c -6 0, -8 -8, 0 -18z" fill="#e8a33d" /></>)}
      {kind === "tote" && (<><path d="M48 80 h 104 l -8 90 h -88 z" fill={color} /><path d="M74 80 c 0 -40, 52 -40, 52 0" stroke={color} strokeWidth="8" fill="none" /></>)}
      {kind === "plant" && (<><path d="M70 120 h 60 l -8 50 h -44 z" fill={color} /><path d="M100 120 C 80 90, 82 60, 100 40 C 118 60, 120 90, 100 120 Z" fill="#5f7d54" /><path d="M100 120 C 66 108, 56 86, 60 70 C 82 78, 96 100, 100 120 Z" fill="#7a9a6c" /><path d="M100 120 C 134 108, 144 86, 140 70 C 118 78, 104 100, 100 120 Z" fill="#7a9a6c" /></>)}
      {kind === "bottle" && (<><rect x="76" y="76" width="48" height="94" rx="12" fill={color} /><rect x="88" y="48" width="24" height="32" rx="4" fill={color} /><rect x="82" y="108" width="36" height="30" rx="3" fill="#f5ead9" /></>)}
      {kind === "throw" && (<><rect x="44" y="96" width="112" height="72" rx="8" fill={color} />{[0, 1, 2, 3].map((i) => <rect key={i} x="44" y={104 + i * 16} width="112" height="4" fill="#f5ead9" opacity=".5" />)}<rect x="52" y="78" width="96" height="22" rx="6" fill={color} opacity=".7" /></>)}
      {kind === "bowl" && (<><path d="M40 110 h 120 c 0 40, -26 60, -60 60 c -34 0, -60 -20, -60 -60 z" fill={color} /><ellipse cx="100" cy="110" rx="60" ry="10" fill="#000" opacity=".12" /></>)}
      {kind === "notebook" && (<><rect x="60" y="54" width="84" height="114" rx="4" fill={color} /><rect x="60" y="54" width="12" height="114" fill="#000" opacity=".15" /><rect x="86" y="80" width="40" height="6" rx="3" fill="#f5ead9" /></>)}
    </svg>
  );
}

const products: { n: string; c: string; p: number; k: Kind; col: string; bg: string; tag?: string }[] = [
  { n: "Stoneware Mug", c: "Kitchen", p: 28, k: "mug", col: "#a95a30", bg: "#f2e3d3", tag: "Bestseller" },
  { n: "Cedar & Smoke Candle", c: "Home", p: 34, k: "candle", col: "#2d3b36", bg: "#e4e8e2" },
  { n: "Canvas Market Tote", c: "Accessories", p: 42, k: "tote", col: "#b8a48a", bg: "#efe9df" },
  { n: "Terracotta Planter", c: "Home", p: 38, k: "plant", col: "#a95a30", bg: "#efe4d6", tag: "New" },
  { n: "Olive Oil Hand Soap", c: "Bath", p: 18, k: "bottle", col: "#5f7d54", bg: "#e7ece0" },
  { n: "Wool Throw Blanket", c: "Home", p: 96, k: "throw", col: "#7a5a3c", bg: "#efe6da" },
  { n: "Hand-thrown Bowl", c: "Kitchen", p: 32, k: "bowl", col: "#2d3b36", bg: "#e3e6e1" },
  { n: "Linen Journal", c: "Accessories", p: 22, k: "notebook", col: "#1f1d1a", bg: "#ece6dc", tag: "Local maker" },
];

const cats = ["All", "Home", "Kitchen", "Bath", "Accessories"];

export default function UrbanGoods() {
  const [cat, setCat] = useState("All");
  const list = useMemo(() => products.filter((p) => cat === "All" || p.c === cat), [cat]);
  const g = "font-[family-name:var(--font-grotesk)]";

  return (
    <div id="top" className={`bg-[#efe9df] ${g} text-[#1f1d1a]`}>
      <DemoNav
        brand={<span className="text-2xl font-bold tracking-tight">urban<span className="text-[#a95a30]">/</span>goods</span>}
        links={[
          { label: "Shop", href: "#shop" },
          { label: "Categories", href: "#categories" },
          { label: "Visit", href: "#visit" },
          { label: "Contact", href: "#contact" },
        ]}
        cta={{ label: "Visit the Store", href: "#visit" }}
        className="bg-[#efe9df]/90 backdrop-blur border-b border-[#1f1d1a]/10 text-[#1f1d1a]"
        linkClass="text-[15px] text-[#1f1d1a]/70 hover:text-[#1f1d1a]"
        ctaClass="bg-[#1f1d1a] px-5 py-2.5 text-sm font-semibold text-[#efe9df] hover:bg-[#a95a30] transition"
        menuClass="bg-[#efe9df] border-t border-[#1f1d1a]/10"
      />

      {/* HERO */}
      <section className="mx-auto max-w-[1200px] px-5 pt-12 sm:px-8 md:pt-16">
        <div className="grid gap-6 md:grid-cols-[1.4fr_1fr]">
          <div className="flex flex-col justify-between bg-[#1f1d1a] p-8 text-[#efe9df] sm:p-12">
            <p className="text-sm tracking-[0.2em] text-[#efe9df]/60 uppercase">Independent home goods shop</p>
            <h1 className="mt-10 text-[48px] leading-[0.95] font-bold tracking-tight sm:text-[80px]">
              Good things for everyday living.
            </h1>
            <div className="mt-10 flex flex-wrap gap-3">
              <a href="#shop" className="bg-[#a95a30] px-6 py-3.5 font-semibold text-white transition hover:bg-[#b8633a]">Browse the Shop</a>
              <a href="#visit" className="border border-[#efe9df]/30 px-6 py-3.5 font-semibold transition hover:border-[#efe9df]">Store hours</a>
            </div>
          </div>
          <div className="grid gap-6">
            <div className="bg-[#e3d8c6]"><GoodsArt className="h-full w-full" /></div>
            <div className="flex items-center justify-between bg-[#a95a30] p-6 text-white">
              <p className="text-xl leading-tight font-semibold">Over 40 local makers<br />on our shelves</p>
              <Store className="h-10 w-10 opacity-70" />
            </div>
          </div>
        </div>
      </section>

      {/* CATEGORIES */}
      <section id="categories" className="mx-auto max-w-[1200px] px-5 py-16 sm:px-8">
        <div className="grid grid-cols-2 gap-px bg-[#1f1d1a]/10 md:grid-cols-4">
          {cats.slice(1).map((c) => (
            <button key={c} type="button" onClick={() => { setCat(c); document.getElementById("shop")?.scrollIntoView({ behavior: "smooth" }); }} className="group flex items-center justify-between bg-[#efe9df] p-6 text-left text-xl font-semibold transition hover:bg-[#1f1d1a] hover:text-[#efe9df]">
              {c}
              <ArrowUpRight className="h-5 w-5 transition group-hover:rotate-45" />
            </button>
          ))}
        </div>
      </section>

      {/* SHOP */}
      <section id="shop" className="mx-auto max-w-[1200px] px-5 pb-20 sm:px-8 sm:pb-28">
        <div className="flex flex-col justify-between gap-6 border-t border-[#1f1d1a] pt-8 md:flex-row md:items-end">
          <div>
            <h2 className="text-4xl font-bold tracking-tight sm:text-5xl">The catalog</h2>
            <p className="mt-2 text-[#675f55]">Available in store. Call ahead to hold any item.</p>
          </div>
          <div role="group" aria-label="Filter by category" className="flex flex-wrap gap-2">
            {cats.map((c) => (
              <button key={c} type="button" aria-pressed={cat === c} onClick={() => setCat(c)} className={`border px-4 py-2 text-sm font-medium transition ${cat === c ? "border-[#1f1d1a] bg-[#1f1d1a] text-[#efe9df]" : "border-[#1f1d1a]/20 hover:border-[#1f1d1a]"}`}>
                {c}
              </button>
            ))}
          </div>
        </div>
        <p className="mt-6 text-sm text-[#675f55]" aria-live="polite">{list.length} item{list.length !== 1 && "s"}</p>
        <div className="mt-4 grid grid-cols-2 gap-x-4 gap-y-10 md:grid-cols-3 lg:grid-cols-4">
          {list.map((p) => (
            <article key={p.n} className="group">
              <div className="relative aspect-square overflow-hidden" style={{ background: p.bg }}>
                <div className="h-full w-full p-6 transition duration-500 group-hover:scale-105"><ProductArt kind={p.k} color={p.col} /></div>
                {p.tag && <span className="absolute top-3 left-3 bg-[#1f1d1a] px-2 py-1 text-[11px] font-semibold tracking-wide text-[#efe9df] uppercase">{p.tag}</span>}
                <a href="#contact" className="absolute inset-x-3 bottom-3 translate-y-2 bg-white py-2.5 text-center text-sm font-semibold opacity-0 transition group-hover:translate-y-0 group-hover:opacity-100 focus:translate-y-0 focus:opacity-100">Ask about this item</a>
              </div>
              <div className="mt-3 flex items-start justify-between gap-2">
                <div>
                  <h3 className="font-semibold">{p.n}</h3>
                  <p className="text-sm text-[#675f55]">{p.c}</p>
                </div>
                <p className="font-semibold">${p.p}</p>
              </div>
            </article>
          ))}
        </div>
      </section>

      {/* VISIT */}
      <section id="visit" className="bg-[#1f1d1a] text-[#efe9df]">
        <div className="mx-auto grid max-w-[1200px] gap-10 px-5 py-20 sm:px-8 md:grid-cols-2">
          <div>
            <h2 className="text-4xl font-bold tracking-tight sm:text-5xl">Come say hello.</h2>
            <ul className="mt-10 space-y-6 text-[16px]">
              <li className="flex gap-4"><MapPin className="h-5 w-5 shrink-0 text-[#a95a30]" />321 Market Street<br />Anytown, USA 00000</li>
              <li className="flex gap-4"><Clock className="h-5 w-5 shrink-0 text-[#a95a30]" />Mon–Sat · 10am – 7pm<br />Sunday · 11am – 5pm</li>
            </ul>
          </div>
          <div className="overflow-hidden">
            <MapArt className="aspect-[4/3] w-full" land="#2a2724" road="#3b3732" water="#2d3b36" park="#33402f" pin="#a95a30" />
          </div>
        </div>
      </section>

      <footer id="contact" className="mx-auto max-w-[1200px] px-5 py-14 sm:px-8">
        <div className="grid gap-8 md:grid-cols-3">
          <p className="text-2xl font-bold">urban<span className="text-[#a95a30]">/</span>goods</p>
          <div className="space-y-2 text-[#1f1d1a]/75">
            <a href="tel:+15550100134" className="flex items-center gap-2 hover:text-[#1f1d1a]"><Phone className="h-4 w-4" /> (555) 010-0134</a>
            <a href="mailto:shop@urbangoods.example" className="flex items-center gap-2 hover:text-[#1f1d1a]"><Mail className="h-4 w-4" /> shop@urbangoods.example</a>
          </div>
          <p className="text-sm text-[#675f55]">© Urban Goods — fictional retail concept created for demonstration.</p>
        </div>
      </footer>
    </div>
  );
}
