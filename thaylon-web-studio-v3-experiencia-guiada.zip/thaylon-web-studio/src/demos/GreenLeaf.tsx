import { Droplets, Flower2, Leaf, Mail, MapPin, Phone, Shovel, Sprout, Trees, Sun } from "lucide-react";
import { LandscapeArt, MapArt } from "@/components/art/Art";
import { BeforeAfter, DemoForm, DemoNav } from "./shared";

const NAME = "GreenLeaf Landscaping";

function BeforeYard() {
  return (
    <svg viewBox="0 0 400 340" className="h-full w-full" preserveAspectRatio="xMidYMid slice" role="img" aria-label="Overgrown yard before landscaping">
      <rect width="400" height="340" fill="#dcd8cc" />
      <path d="M0 200 C 80 170, 160 190, 230 175 S 360 160, 400 180 V340 H0Z" fill="#b9b08f" />
      <path d="M0 250 C 100 230, 200 250, 280 238 S 380 232, 400 240 V340 H0Z" fill="#a39468" />
      {Array.from({ length: 26 }).map((_, i) => (
        <ellipse key={i} cx={(i * 53) % 400} cy={250 + ((i * 37) % 80)} rx={18 + (i % 4) * 6} ry="7" fill={i % 2 ? "#8b7b4f" : "#c2b48a"} />
      ))}
      {[[80, 210], [320, 205], [210, 230]].map(([x, y], i) => (
        <g key={i} transform={`translate(${x} ${y})`} stroke="#6d5b3d" strokeWidth="3" fill="none">
          <path d="M0 40 L0 0 M0 15 L-14 -6 M0 22 L16 2 M0 8 L8 -12" />
        </g>
      ))}
      {Array.from({ length: 40 }).map((_, i) => (
        <path key={i} d={`M${(i * 29) % 400} ${330 - (i % 5) * 12} l3 -16 l3 16`} stroke="#7b8a4b" strokeWidth="2" fill="none" />
      ))}
    </svg>
  );
}

const services = [
  { i: Trees, t: "Landscape Design", d: "Custom plans that fit your home, your style and your budget." },
  { i: Sprout, t: "Planting & Gardens", d: "Native plants, flower beds and vegetable gardens that thrive." },
  { i: Shovel, t: "Hardscaping", d: "Patios, walkways, retaining walls and stone borders." },
  { i: Droplets, t: "Irrigation", d: "Efficient drip and sprinkler systems that save water." },
  { i: Leaf, t: "Lawn Care", d: "Mowing, aeration, seeding and seasonal cleanups." },
  { i: Sun, t: "Outdoor Lighting", d: "Warm, low-voltage lighting for beauty and safety." },
];

const projects = [
  { t: "Cottage Garden Refresh", l: "Maple Grove", tag: "Planting", bg: "linear-gradient(160deg,#a9cf8c,#3f8248)" },
  { t: "Flagstone Patio & Firepit", l: "Oak Hill", tag: "Hardscape", bg: "linear-gradient(160deg,#e3d2b4,#9c7e58)" },
  { t: "Drought-Smart Front Yard", l: "Riverside", tag: "Design", bg: "linear-gradient(160deg,#f2d98a,#7a9a5c)" },
];

export default function GreenLeaf() {
  return (
    <div id="top" className="bg-[#f4f1e8] font-sans text-[#1f3a24]">
      <DemoNav
        brand={
          <span className="flex items-center gap-2 font-[family-name:var(--font-fraunces)] text-2xl font-semibold">
            <Leaf className="h-6 w-6 text-[#5d9a52]" /> GreenLeaf
          </span>
        }
        links={[
          { label: "Services", href: "#services" },
          { label: "Before & After", href: "#transform" },
          { label: "Projects", href: "#projects" },
          { label: "Areas", href: "#areas" },
        ]}
        cta={{ label: "Request a Quote", href: "#quote" }}
        className="bg-[#f4f1e8]/90 backdrop-blur border-b border-[#1f3a24]/10 text-[#1f3a24]"
        linkClass="text-[15px] text-[#1f3a24]/75 hover:text-[#1f3a24]"
        ctaClass="rounded-full bg-[#1f3a24] px-5 py-2.5 text-sm font-semibold text-[#f4f1e8] hover:bg-[#2c5233]"
        menuClass="bg-[#f4f1e8] border-t border-[#1f3a24]/10"
      />

      {/* HERO */}
      <section className="mx-auto max-w-[1200px] px-5 pt-14 sm:px-8 md:pt-20">
        <div className="grid items-end gap-10 md:grid-cols-[1.2fr_1fr]">
          <h1 className="font-[family-name:var(--font-fraunces)] text-[52px] leading-[0.98] font-medium tracking-tight sm:text-[84px]">
            Outdoor spaces, <em className="font-normal text-[#5d9a52]">beautifully</em> grown.
          </h1>
          <div className="pb-2">
            <p className="text-lg leading-relaxed text-[#1f3a24]/70">
              Landscape design, planting and hardscaping for homeowners who want a yard they&apos;re proud of — and actually enjoy.
            </p>
            <div className="mt-7 flex flex-wrap gap-3">
              <a href="#quote" className="rounded-full bg-[#5d9a52] px-7 py-3.5 font-semibold text-white transition hover:bg-[#4d8544]">Request a Quote</a>
              <a href="#projects" className="rounded-full border border-[#1f3a24]/20 px-7 py-3.5 font-semibold transition hover:bg-white">Our Projects</a>
            </div>
          </div>
        </div>
        <div className="mt-12 overflow-hidden rounded-t-[48px] sm:rounded-t-[80px]">
          <LandscapeArt className="aspect-[16/7] w-full" />
        </div>
      </section>

      {/* SERVICES */}
      <section id="services" className="bg-[#1f3a24] text-[#f4f1e8]">
        <div className="mx-auto max-w-[1200px] px-5 py-20 sm:px-8 sm:py-28">
          <div className="grid gap-6 md:grid-cols-2">
            <h2 className="font-[family-name:var(--font-fraunces)] text-4xl font-medium sm:text-5xl">Everything your yard needs, from roots to lights.</h2>
            <p className="self-end text-[#f4f1e8]/65 md:text-right">Design, install and care — one team, start to finish.</p>
          </div>
          <div className="mt-14 grid gap-px overflow-hidden rounded-3xl bg-white/10 sm:grid-cols-2 lg:grid-cols-3">
            {services.map(({ i: I, t, d }) => (
              <div key={t} className="bg-[#1f3a24] p-8 transition hover:bg-[#25452b]">
                <I className="h-8 w-8 text-[#a9cf8c]" strokeWidth={1.5} />
                <h3 className="mt-5 font-[family-name:var(--font-fraunces)] text-2xl">{t}</h3>
                <p className="mt-2 text-[15px] text-[#f4f1e8]/65">{d}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* BEFORE AFTER */}
      <section id="transform" className="mx-auto grid max-w-[1200px] items-center gap-12 px-5 py-20 sm:px-8 sm:py-28 md:grid-cols-[1fr_1.3fr]">
        <div>
          <p className="text-sm font-semibold tracking-[0.2em] text-[#5d9a52] uppercase">Before &amp; after</p>
          <h2 className="mt-3 font-[family-name:var(--font-fraunces)] text-4xl font-medium sm:text-5xl">See the transformation.</h2>
          <p className="mt-4 text-[#1f3a24]/70">Drag the slider to compare. This tired backyard became a lush, low-maintenance retreat in under three weeks.</p>
          <dl className="mt-8 grid grid-cols-3 gap-4">
            {[["3 wks", "Install"], ["40+", "Plants"], ["-30%", "Water use"]].map(([a, b]) => (
              <div key={b} className="rounded-2xl bg-white p-4">
                <dd className="font-[family-name:var(--font-fraunces)] text-2xl">{a}</dd>
                <dt className="text-xs tracking-wide text-[#1f3a24]/60 uppercase">{b}</dt>
              </div>
            ))}
          </dl>
        </div>
        <BeforeAfter label="Backyard renovation" before={<BeforeYard />} after={<LandscapeArt className="h-full w-full" title="Backyard after landscaping" />} />
      </section>

      {/* PROJECTS */}
      <section id="projects" className="bg-white">
        <div className="mx-auto max-w-[1200px] px-5 py-20 sm:px-8 sm:py-28">
          <h2 className="font-[family-name:var(--font-fraunces)] text-4xl font-medium sm:text-5xl">Recent projects</h2>
          <div className="mt-12 grid gap-6 md:grid-cols-3">
            {projects.map((p, i) => (
              <article key={p.t} className="group">
                <div className="relative aspect-[4/5] overflow-hidden rounded-[32px]" style={{ background: p.bg }}>
                  <Flower2 className="absolute right-6 bottom-6 h-24 w-24 text-white/25 transition duration-700 group-hover:rotate-45" strokeWidth={1} />
                  <span className="absolute top-5 left-5 rounded-full bg-white/90 px-3 py-1 text-xs font-semibold">{p.tag}</span>
                  <span className="absolute bottom-5 left-6 font-[family-name:var(--font-fraunces)] text-7xl text-white/80">0{i + 1}</span>
                </div>
                <h3 className="mt-5 font-[family-name:var(--font-fraunces)] text-2xl">{p.t}</h3>
                <p className="mt-1 flex items-center gap-1.5 text-sm text-[#1f3a24]/60"><MapPin className="h-4 w-4" />{p.l}</p>
              </article>
            ))}
          </div>
        </div>
      </section>

      {/* AREAS + QUOTE */}
      <section id="areas" className="mx-auto max-w-[1200px] px-5 py-20 sm:px-8 sm:py-28">
        <div className="grid gap-12 md:grid-cols-2">
          <div>
            <h2 className="font-[family-name:var(--font-fraunces)] text-4xl font-medium sm:text-5xl">Where we grow</h2>
            <p className="mt-4 text-[#1f3a24]/70">Serving homeowners within 25 miles of Anytown.</p>
            <div className="mt-8 overflow-hidden rounded-3xl">
              <MapArt className="aspect-[4/3] w-full" land="#ece7d7" water="#cfe0d8" park="#c5dcb1" pin="#5d9a52" />
            </div>
            <ul className="mt-6 flex flex-wrap gap-2">
              {["Maple Grove", "Oak Hill", "Riverside", "Cedar Falls", "Brookfield", "Pine Ridge"].map((a) => (
                <li key={a} className="rounded-full border border-[#1f3a24]/15 px-4 py-2 text-sm">{a}</li>
              ))}
            </ul>
          </div>
          <div id="quote" className="rounded-[32px] bg-[#1f3a24] p-7 text-[#f4f1e8] sm:p-10">
            <h2 className="font-[family-name:var(--font-fraunces)] text-4xl font-medium">Request a quote</h2>
            <p className="mt-3 text-[#f4f1e8]/65">Tell us about your project and we&apos;ll schedule a free on-site consultation.</p>
            <DemoForm
              demoName={NAME}
              submitLabel="Send Request"
              className="mt-8 grid gap-4"
              buttonClass="mt-2 rounded-full bg-[#a9cf8c] py-4 font-semibold text-[#1f3a24] hover:bg-[#bfe0a5] transition"
              noticeClass="border-white/20 bg-[#25452b] text-[#f4f1e8]"
            >
              {[
                { l: "Name", n: "name", t: "text", ac: "name" },
                { l: "Email", n: "email", t: "email", ac: "email" },
                { l: "Street address", n: "address", t: "text", ac: "street-address" },
              ].map((x) => (
                <label key={x.n} className="block text-sm text-[#f4f1e8]/75">
                  {x.l}
                  <input required name={x.n} type={x.t} autoComplete={x.ac} className="mt-1.5 w-full rounded-2xl border border-white/15 bg-white/5 px-4 py-3 text-[#f4f1e8] outline-none focus:border-[#a9cf8c]" />
                </label>
              ))}
              <fieldset>
                <legend className="text-sm text-[#f4f1e8]/75">Project type</legend>
                <div className="mt-2 flex flex-wrap gap-2">
                  {["Design", "Planting", "Hardscape", "Irrigation", "Lawn care"].map((t) => (
                    <label key={t} className="cursor-pointer rounded-full border border-white/20 px-4 py-2 text-sm has-[:checked]:border-[#a9cf8c] has-[:checked]:bg-[#a9cf8c] has-[:checked]:text-[#1f3a24]">
                      <input type="checkbox" name="type" value={t} className="sr-only" />{t}
                    </label>
                  ))}
                </div>
              </fieldset>
              <label className="block text-sm text-[#f4f1e8]/75">
                Tell us about your yard
                <textarea name="message" rows={3} className="mt-1.5 w-full rounded-2xl border border-white/15 bg-white/5 px-4 py-3 text-[#f4f1e8] outline-none focus:border-[#a9cf8c]" />
              </label>
            </DemoForm>
          </div>
        </div>
      </section>

      <footer className="border-t border-[#1f3a24]/10">
        <div className="mx-auto flex max-w-[1200px] flex-col justify-between gap-4 px-5 py-8 text-sm text-[#1f3a24]/65 sm:flex-row sm:px-8">
          <p className="flex items-center gap-2 font-[family-name:var(--font-fraunces)] text-lg text-[#1f3a24]"><Leaf className="h-5 w-5 text-[#5d9a52]" /> GreenLeaf Landscaping</p>
          <p className="flex flex-wrap gap-x-5 gap-y-1">
            <a href="tel:+15550100162" className="flex items-center gap-1.5 hover:text-[#1f3a24]"><Phone className="h-4 w-4" />(555) 010-0162</a>
            <a href="mailto:grow@greenleaf.example" className="flex items-center gap-1.5 hover:text-[#1f3a24]"><Mail className="h-4 w-4" />grow@greenleaf.example</a>
          </p>
          <p>© GreenLeaf (fictional demo)</p>
        </div>
      </footer>
    </div>
  );
}
