import { ArrowRight, BadgeCheck, CloudLightning, Droplets, Hammer, HardHat, Home, Mail, MapPin, Phone, Search, Warehouse } from "lucide-react";
import { MapArt, RoofArt } from "@/components/art/Art";
import { DemoForm, DemoNav } from "./shared";

const NAME = "Summit Roofing";
const o = "#f28c28";

const services = [
  { i: Home, t: "Roof Replacement", d: "Architectural shingles, metal and tile — installed to manufacturer spec." },
  { i: Hammer, t: "Roof Repair", d: "Leaks, missing shingles, flashing and vent repairs, done right the first time." },
  { i: CloudLightning, t: "Storm Damage", d: "Fast response after hail and wind, with help documenting insurance claims." },
  { i: Search, t: "Inspections", d: "Detailed photo reports for buyers, sellers and annual maintenance." },
  { i: Droplets, t: "Gutters", d: "Seamless gutters, guards and downspouts to protect your foundation." },
  { i: Warehouse, t: "Light Commercial", d: "Flat and low-slope roofing for small commercial buildings." },
];

const gallery = [
  { t: "Full replacement", s: "Architectural shingle · Charcoal", p: "#2b3240" },
  { t: "Standing-seam metal", s: "Galvalume · Matte black", p: "#3d4a5c" },
  { t: "Storm repair", s: "Hail damage · 2 days", p: "#5a6474" },
  { t: "Cedar shake restoration", s: "Treated cedar", p: "#7a5a3c" },
];

export default function SummitRoofing() {
  return (
    <div id="top" className="bg-white font-[family-name:var(--font-archivo)] text-[#1b2130]">
      <div className="bg-[#f28c28] text-[#1b2130]">
        <div className="mx-auto flex max-w-[1200px] items-center justify-between gap-3 px-5 py-2 text-[13px] font-semibold sm:px-8">
          <span>Storm damage? Free emergency inspections this week.</span>
          <a href="tel:+15550100175" className="hidden items-center gap-1.5 sm:flex"><Phone className="h-3.5 w-3.5" /> (555) 010-0175</a>
        </div>
      </div>
      <DemoNav
        brand={
          <span className="flex items-center gap-2.5">
            <svg viewBox="0 0 40 28" className="h-7 w-10" aria-hidden="true"><path d="M2 26 L20 4 L38 26" fill="none" stroke={o} strokeWidth="5" strokeLinejoin="round" /><path d="M12 26 L20 16 L28 26" fill="none" stroke="#fff" strokeWidth="4" /></svg>
            <span className="text-xl font-extrabold tracking-tight uppercase">Summit<span className="font-medium text-[#a9b2c3]"> Roofing</span></span>
          </span>
        }
        links={[
          { label: "Services", href: "#services" },
          { label: "Projects", href: "#projects" },
          { label: "Service Area", href: "#area" },
          { label: "Contact", href: "#contact" },
        ]}
        cta={{ label: "Free Estimate", href: "#estimate" }}
        className="bg-[#1b2130] text-white"
        linkClass="text-sm font-semibold uppercase tracking-wider text-white/70 hover:text-[#f28c28]"
        ctaClass="bg-[#f28c28] px-5 py-3 text-sm font-bold uppercase tracking-wider text-[#1b2130] hover:bg-[#ff9d3e]"
        menuClass="bg-[#1b2130] border-t border-white/10 text-white"
      />

      {/* HERO */}
      <section className="relative overflow-hidden bg-[#1b2130] text-white">
        <div className="absolute inset-y-0 right-0 hidden w-1/2 lg:block" style={{ clipPath: "polygon(18% 0, 100% 0, 100% 100%, 0 100%)" }}>
          <RoofArt className="h-full w-full" />
        </div>
        <div className="relative mx-auto max-w-[1200px] px-5 py-16 sm:px-8 md:py-28">
          <div className="max-w-xl lg:max-w-[46%]">
            <p className="inline-flex items-center gap-2 border border-white/15 px-3 py-1.5 text-xs font-bold tracking-[0.2em] uppercase"><HardHat className="h-4 w-4" style={{ color: o }} /> Residential roofing contractor</p>
            <h1 className="mt-6 text-[48px] leading-[0.98] font-extrabold tracking-tight uppercase sm:text-[72px]">
              Roofs built to <span style={{ color: o }}>weather anything.</span>
            </h1>
            <p className="mt-6 text-lg text-[#a9b2c3]">Replacements, repairs and storm restoration from a crew that shows up on time, protects your property and cleans up every nail.</p>
            <div className="mt-9 flex flex-wrap gap-3">
              <a href="#estimate" className="inline-flex items-center gap-2 px-7 py-4 font-bold tracking-wider text-[#1b2130] uppercase transition hover:brightness-110" style={{ background: o }}>Get a Free Estimate <ArrowRight className="h-4 w-4" /></a>
              <a href="tel:+15550100175" className="inline-flex items-center gap-2 border border-white/25 px-7 py-4 font-bold tracking-wider uppercase transition hover:border-white"><Phone className="h-4 w-4" /> Call now</a>
            </div>
          </div>
          <div className="mt-10 lg:hidden"><RoofArt className="aspect-[4/3] w-full" /></div>
        </div>
      </section>

      {/* TRUST BAR */}
      <section className="border-b border-[#1b2130]/10 bg-[#f3f5f8]">
        <ul className="mx-auto grid max-w-[1200px] grid-cols-2 gap-px px-5 sm:px-8 md:grid-cols-4">
          {["Licensed & insured", "Free written estimates", "Workmanship warranty", "Insurance claim help"].map((t) => (
            <li key={t} className="flex items-center gap-2 py-5 text-sm font-bold uppercase tracking-wide"><BadgeCheck className="h-5 w-5 shrink-0" style={{ color: o }} />{t}</li>
          ))}
        </ul>
      </section>

      {/* SERVICES */}
      <section id="services" className="mx-auto max-w-[1200px] px-5 py-20 sm:px-8 sm:py-28">
        <p className="text-sm font-bold tracking-[0.2em] uppercase" style={{ color: o }}>What we do</p>
        <h2 className="mt-3 max-w-2xl text-4xl font-extrabold tracking-tight uppercase sm:text-5xl">Complete roofing services</h2>
        <div className="mt-12 grid gap-0 border-t border-l border-[#1b2130]/10 sm:grid-cols-2 lg:grid-cols-3">
          {services.map(({ i: I, t, d }) => (
            <div key={t} className="group relative border-r border-b border-[#1b2130]/10 p-8 transition hover:bg-[#1b2130] hover:text-white">
              <I className="h-9 w-9" style={{ color: o }} strokeWidth={1.75} />
              <h3 className="mt-6 text-xl font-extrabold uppercase">{t}</h3>
              <p className="mt-2 text-[15px] text-[#5a6474] group-hover:text-[#a9b2c3]">{d}</p>
              <span className="absolute top-0 left-0 h-1 w-0 transition-all duration-300 group-hover:w-full" style={{ background: o }} />
            </div>
          ))}
        </div>
      </section>

      {/* PROJECTS */}
      <section id="projects" className="bg-[#1b2130] text-white">
        <div className="mx-auto max-w-[1200px] px-5 py-20 sm:px-8 sm:py-28">
          <div className="flex flex-col justify-between gap-4 md:flex-row md:items-end">
            <h2 className="text-4xl font-extrabold tracking-tight uppercase sm:text-5xl">Recent projects</h2>
            <p className="text-[#a9b2c3]">Every job documented with before, during and after photos.</p>
          </div>
          <div className="mt-12 grid gap-5 sm:grid-cols-2">
            {gallery.map((g) => (
              <figure key={g.t} className="group relative overflow-hidden">
                <div className="aspect-[16/10] w-full transition duration-500 group-hover:scale-105" style={{ backgroundColor: g.p, backgroundImage: "repeating-linear-gradient(0deg, rgba(0,0,0,.25) 0 2px, transparent 2px 22px), repeating-linear-gradient(90deg, rgba(0,0,0,.18) 0 2px, transparent 2px 44px)" }} />
                <figcaption className="absolute inset-x-0 bottom-0 bg-gradient-to-t from-black/80 to-transparent p-6">
                  <p className="text-xl font-extrabold uppercase">{g.t}</p>
                  <p className="text-sm text-white/70">{g.s}</p>
                </figcaption>
              </figure>
            ))}
          </div>
        </div>
      </section>

      {/* AREA + ESTIMATE */}
      <section id="area" className="mx-auto grid max-w-[1200px] gap-12 px-5 py-20 sm:px-8 sm:py-28 lg:grid-cols-2">
        <div>
          <p className="text-sm font-bold tracking-[0.2em] uppercase" style={{ color: o }}>Service area</p>
          <h2 className="mt-3 text-4xl font-extrabold tracking-tight uppercase">Serving Anytown County</h2>
          <div className="relative mt-8 overflow-hidden border border-[#1b2130]/10">
            <MapArt className="aspect-[4/3] w-full" land="#eef1f5" water="#cfdbe8" park="#dde7d6" pin={o} />
          </div>
          <ul className="mt-6 grid grid-cols-2 gap-2 sm:grid-cols-3">
            {["Anytown", "Summit Heights", "Lakeview", "Westbrook", "Pine Ridge", "Granite Falls"].map((a) => (
              <li key={a} className="flex items-center gap-2 text-sm font-semibold"><MapPin className="h-4 w-4" style={{ color: o }} />{a}</li>
            ))}
          </ul>
        </div>
        <div id="estimate" className="bg-[#f3f5f8] p-7 sm:p-10">
          <h2 className="text-3xl font-extrabold uppercase">Request a free estimate</h2>
          <p className="mt-2 text-[#5a6474]">No pressure. We&apos;ll inspect your roof and give you a written, itemized quote.</p>
          <DemoForm
            demoName={NAME}
            submitLabel="GET MY FREE ESTIMATE"
            className="mt-8 grid gap-4 sm:grid-cols-2"
            buttonClass="sm:col-span-2 bg-[#f28c28] py-4 font-extrabold tracking-wider text-[#1b2130] hover:bg-[#ff9d3e] transition"
            noticeClass="sm:col-span-2 border-[#1b2130]/15 bg-white text-[#1b2130]"
          >
            {[
              { l: "Full name", n: "name", t: "text", ac: "name" },
              { l: "Phone", n: "phone", t: "tel", ac: "tel" },
              { l: "Email", n: "email", t: "email", ac: "email" },
              { l: "ZIP code", n: "zip", t: "text", ac: "postal-code" },
            ].map((x) => (
              <label key={x.n} className="block text-xs font-bold tracking-wider uppercase">
                {x.l}
                <input required name={x.n} type={x.t} autoComplete={x.ac} className="mt-2 w-full border border-[#1b2130]/15 bg-white px-4 py-3 text-base font-normal tracking-normal normal-case outline-none focus:border-[#f28c28]" />
              </label>
            ))}
            <label className="block text-xs font-bold tracking-wider uppercase sm:col-span-2">
              What do you need?
              <select required name="need" defaultValue="" className="mt-2 w-full border border-[#1b2130]/15 bg-white px-4 py-3 text-base font-normal tracking-normal normal-case outline-none focus:border-[#f28c28]">
                <option value="" disabled>Select a service…</option>
                {services.map((s) => <option key={s.t}>{s.t}</option>)}
              </select>
            </label>
          </DemoForm>
        </div>
      </section>

      <footer id="contact" className="bg-[#11151f] text-white/70">
        <div className="mx-auto grid max-w-[1200px] gap-8 px-5 py-12 text-sm sm:px-8 md:grid-cols-3">
          <p className="text-lg font-extrabold text-white uppercase">Summit Roofing</p>
          <div className="space-y-2">
            <a href="tel:+15550100175" className="flex items-center gap-2 hover:text-white"><Phone className="h-4 w-4" style={{ color: o }} /> (555) 010-0175</a>
            <a href="mailto:estimates@summitroofing.example" className="flex items-center gap-2 hover:text-white"><Mail className="h-4 w-4" style={{ color: o }} /> estimates@summitroofing.example</a>
          </div>
          <p>Mon–Sat · 7:00 AM – 6:00 PM<br />© Summit Roofing (fictional demo)</p>
        </div>
      </footer>
    </div>
  );
}
