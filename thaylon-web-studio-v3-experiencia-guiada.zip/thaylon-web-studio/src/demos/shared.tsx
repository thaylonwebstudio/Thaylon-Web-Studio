"use client";

import Link from "next/link";
import { useEffect, useState } from "react";
import { ArrowLeft, ArrowRight, Info, Menu, X } from "lucide-react";
import { AGENCY_NAME, PORTFOLIO_URL, QUOTE_PATH } from "@/config/site";

export const quoteHref = (demoName: string) =>
  `${QUOTE_PATH}?demo=${encodeURIComponent(demoName)}`;

/** Fixed agency bar shown on top of every demo. */
export function DemoBanner({ name }: { name: string }) {
  return (
    <div className="sticky top-0 z-[60] border-b border-white/10 bg-[#111318] font-sans text-white">
      <div className="mx-auto flex h-11 max-w-[1400px] items-center justify-between gap-3 px-3 sm:px-5">
        <Link href={PORTFOLIO_URL} aria-label="Back to the portfolio" className="inline-flex min-h-9 shrink-0 items-center gap-1.5 text-[12.5px] font-medium text-white/75 hover:text-white">
          <ArrowLeft className="h-3.5 w-3.5" aria-hidden="true" />
          <span className="hidden sm:inline">Portfolio</span>
        </Link>
        <p className="truncate text-center text-[10.5px] font-bold tracking-[0.14em] uppercase sm:text-[11.5px]">
          <span className="mr-1.5 inline-block h-1.5 w-1.5 -translate-y-px rounded-full bg-[#E44848]" aria-hidden="true" />
          <span className="sm:hidden">Demo — Fictional Business</span>
          <span className="hidden sm:inline">Demo Project — Fictional Business</span>
        </p>
        <Link href={quoteHref(name)} className="inline-flex shrink-0 items-center gap-1 rounded-md bg-[#c93030] px-2.5 py-1.5 text-[12px] font-semibold hover:bg-[#b02a2a]">
          <span className="hidden md:inline">Want a Website Like This?</span>
          <span className="md:hidden">Get one</span>
          <ArrowRight className="h-3.5 w-3.5" />
        </Link>
      </div>
    </div>
  );
}

/** End-of-page agency CTA appended to every demo. */
export function DemoCTA({ name, category }: { name: string; category: string }) {
  return (
    <section className="bg-[#101827] font-sans text-white">
      <div className="mx-auto grid max-w-[1200px] items-center gap-8 px-5 py-16 sm:px-8 sm:py-20 lg:grid-cols-[1.4fr_1fr]">
        <div>
          <p className="inline-flex items-center gap-2 text-[12px] font-semibold tracking-[0.16em] text-[#E44848] uppercase">
            <span className="inline-block h-px w-6 bg-current" /> Designed by {AGENCY_NAME}
          </p>
          <h2 className="mt-4 font-display text-[32px] leading-[1.08] font-extrabold tracking-tight sm:text-[44px]">
            Want a Website Like This?
          </h2>
          <p className="mt-4 max-w-xl text-lg text-white/65">
            {name} is a fictional {category.toLowerCase()} created to demonstrate our work. We can design a site like this — tailored to your real business, brand and customers.
          </p>
        </div>
        <div className="flex flex-col gap-3 sm:flex-row lg:justify-end">
          <Link href={quoteHref(name)} className="btn-primary !px-6 !py-4">
            Get a Free Quote <ArrowRight className="h-4 w-4" />
          </Link>
          <Link href={PORTFOLIO_URL} className="btn-ghost-dark !px-6 !py-4">
            More demos
          </Link>
        </div>
      </div>
    </section>
  );
}

/** Responsive nav for demos. Styling is passed in so each brand looks distinct. */
export function DemoNav({
  brand,
  links,
  cta,
  className,
  linkClass,
  ctaClass,
  menuClass,
}: {
  brand: React.ReactNode;
  links: { label: string; href: string }[];
  cta?: { label: string; href: string };
  className: string;
  linkClass: string;
  ctaClass: string;
  menuClass: string;
}) {
  const [open, setOpen] = useState(false);
  useEffect(() => {
    const close = () => setOpen(false);
    window.addEventListener("hashchange", close);
    return () => window.removeEventListener("hashchange", close);
  }, []);
  return (
    <header className={`sticky top-11 z-50 ${className}`}>
      <div className="mx-auto flex h-16 max-w-[1200px] items-center justify-between gap-4 px-5 sm:h-20 sm:px-8">
        <a href="#top" className="shrink-0" aria-label="Back to top of page">{brand}</a>
        <nav aria-label="Demo site" className="hidden lg:block">
          <ul className="flex items-center gap-7">
            {links.map((l) => (
              <li key={l.href}><a href={l.href} className={linkClass}>{l.label}</a></li>
            ))}
          </ul>
        </nav>
        <div className="flex items-center gap-2">
          {cta && <a href={cta.href} className={`hidden sm:inline-flex ${ctaClass}`}>{cta.label}</a>}
          <button
            type="button"
            className="inline-flex h-10 w-10 items-center justify-center lg:hidden"
            aria-label={open ? "Close menu" : "Open menu"}
            aria-expanded={open}
            onClick={() => setOpen((v) => !v)}
          >
            {open ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
          </button>
        </div>
      </div>
      {open && (
        <div className={`lg:hidden ${menuClass}`}>
          <ul className="mx-auto max-w-[1200px] px-5 py-4">
            {links.map((l) => (
              <li key={l.href}>
                <a href={l.href} onClick={() => setOpen(false)} className="block py-3 text-lg">{l.label}</a>
              </li>
            ))}
            {cta && (
              <li className="pt-3"><a href={cta.href} onClick={() => setOpen(false)} className={`flex w-full justify-center ${ctaClass}`}>{cta.label}</a></li>
            )}
          </ul>
        </div>
      )}
    </header>
  );
}

/**
 * Demo form: fully interactive UI with validation, but it NEVER sends data.
 * On submit it clearly explains that this is a demonstration.
 */
export function DemoForm({
  demoName,
  children,
  submitLabel,
  className = "",
  buttonClass,
  noticeClass = "",
}: {
  demoName: string;
  children: React.ReactNode;
  submitLabel: string;
  className?: string;
  buttonClass: string;
  noticeClass?: string;
}) {
  const [submitted, setSubmitted] = useState(false);
  return (
    <form
      className={className}
      onSubmit={(e) => {
        e.preventDefault();
        if (!e.currentTarget.reportValidity()) return;
        setSubmitted(true);
      }}
    >
      {children}
      <button type="submit" className={buttonClass}>{submitLabel}</button>
      {submitted && (
        <div role="status" className={`mt-4 flex gap-3 rounded-lg border p-4 font-sans text-[14px] leading-relaxed ${noticeClass || "border-black/10 bg-white text-[#111318]"}`}>
          <Info className="mt-0.5 h-4 w-4 shrink-0" />
          <p>
            <strong>This is a demo form — nothing was sent.</strong> On a real website, this request would go straight to the business owner&apos;s inbox.{" "}
            <Link href={quoteHref(demoName)} className="font-semibold underline">Get a working form like this →</Link>
          </p>
        </div>
      )}
    </form>
  );
}

/** Interactive before/after comparison slider (keyboard accessible). */
export function BeforeAfter({ before, after, label }: { before: React.ReactNode; after: React.ReactNode; label: string }) {
  const [pos, setPos] = useState(50);
  return (
    <div className="relative aspect-[4/3] w-full touch-pan-y overflow-hidden rounded-2xl select-none">
      <div className="absolute inset-0">{after}</div>
      <div className="absolute inset-0" style={{ clipPath: `inset(0 ${100 - pos}% 0 0)` }}>{before}</div>
      <div className="pointer-events-none absolute inset-y-0 w-0.5 bg-white shadow" style={{ left: `${pos}%` }}>
        <span className="absolute top-1/2 left-1/2 flex h-10 w-10 -translate-x-1/2 -translate-y-1/2 items-center justify-center rounded-full bg-white text-[#1f3a24] shadow-lg">
          ⇆
        </span>
      </div>
      <span className="absolute top-3 left-3 rounded-full bg-black/55 px-3 py-1 text-xs font-semibold text-white">Before</span>
      <span className="absolute top-3 right-3 rounded-full bg-black/55 px-3 py-1 text-xs font-semibold text-white">After</span>
      <input
        type="range"
        min={0}
        max={100}
        value={pos}
        onChange={(e) => setPos(Number(e.target.value))}
        aria-label={`${label}: drag to compare before and after`}
        className="absolute inset-0 h-full w-full cursor-ew-resize opacity-0"
      />
    </div>
  );
}
