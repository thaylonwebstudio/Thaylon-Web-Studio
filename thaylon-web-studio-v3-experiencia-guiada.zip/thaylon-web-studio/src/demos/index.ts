import type { ComponentType } from "react";
import BellaNapoli from "./BellaNapoli";
import FreshHome from "./FreshHome";
import GentlemansCut from "./GentlemansCut";
import GreenLeaf from "./GreenLeaf";
import SummitRoofing from "./SummitRoofing";
import EliteAuto from "./EliteAuto";
import LuxeBeauty from "./LuxeBeauty";
import ProFlow from "./ProFlow";
import UrbanGoods from "./UrbanGoods";

/** slug → demo page component */
export const demoComponents: Record<string, ComponentType> = {
  "bella-napoli": BellaNapoli,
  "freshhome-cleaning": FreshHome,
  "gentlemans-cut": GentlemansCut,
  "greenleaf-landscaping": GreenLeaf,
  "summit-roofing": SummitRoofing,
  "elite-auto-detailing": EliteAuto,
  "luxe-beauty": LuxeBeauty,
  "proflow-plumbing": ProFlow,
  "urban-goods": UrbanGoods,
};
