"use client";

import { useState } from "react";
import { Car, Check, Droplet, Mail, MapPin, Phone, ShieldCheck, Sparkles, Truck, Wind } from "lucide-react";
import { CarArt } from "@/components/art/Art";
import { DemoForm, DemoNav } from "./shared";

const NAME = "Elite Auto Detailing";
const blue = "#3da9fc";

const sizes = [
  { k: "sedan", l: "Sedan / Coupe", m: 1 },
  { k: "suv", l: "SUV / Crossover", m: 1.2 },
  { k: "truck", l: "Truck / Van", m: 1.35 },
] as const;

const packages = [
  { n: "Express", p: 89, time: "1.5 hrs", f: ["Foam hand wash", "Wheels & tires", "Interior vacuum", "Windows inside & out"] },
  { n: "Signature", p: 199, time: "3–4 hrs", f: ["Everything in Express", "Clay bar decontamination", "Hand wax (3-month protection)", "Interior deep clean & steam", "Leather conditioning"], pop: true },
  { n: "Ceramic Pro", p: 649, time: "1–2 days", f: ["Everything in Signature", "One-step paint correction", "Ceramic coating (2-year)", "Glass & wheel coating"] },
];

const addons = [
  { n: "Engine bay detail", p: 45 },
  { n: "Pet hair removal", p: 35 },
  { n: "Headlight restoration", p: 60 },
  { n: "Odor elimination", p: 50 },
];

export default function EliteAuto() {
  const [size, setSize] = useState<(typeof sizes)[number]["k"]>("sedan");
  const [pkg, setPkg] = useState("Signature");
  const [extras, setExtras] = useState<string[]>([]);
  const m = sizes.find((s) => s.k === size)!.m;
  const base = packages.find((p) => p.n === pkg)!.p;
  const total = Math.round(base * m) + addons.filter((a) => extras.includes(a.n)).reduce((s, a) => s + a.p, 0);

  return (
    <div id="top" className="bg-[#07080a] font-sans text-[#f5f7fa]">
      <DemoNav
        brand={<span className="font-[family-name:var(--font-bebas)] text-3xl tracking-[0.08em]">ELITE<span style={{ color: blue }}>/</span>AUTO</span>}
        links={[
          { label: "Packages", href: "#packages" },
          { label: "Gallery", href: "#gallery" },
          { label: "Book", href: "#book" },
          { label: "Contact", href: "#contact" },
        ]}
        cta={{ label: "Book a Detail", href: "#book" }}
        className="bg-[#07080a]/80 backdrop-blur-xl border-b border-white/10 text-white"
        linkClass="text-sm font-medium tracking-wide text-white/60 hover:text-white"
        ctaClass="rounded-md border border-[#3da9fc] px-5 py-2.5 text-sm font-semibold text-[#3da9fc] hover:bg-[#3da9fc] hover:text-[#07080a] transition"
        menuClass="bg-[#07080a] border-t border-white/10"
      />

      {/* HERO */}
      <section className="relative overflow-hidden">
        <div className="pointer-events-none absolute top-1/2 left-1/2 h-[500px] w-[900px] -translate-x-1/2 -translate-y-1/3 rounded-full opacity-25 blur-[120px]" style={{ background: blue }} />
        <div className="relative mx-auto max-w-[1200px] px-5 pt-16 pb-10 text-center sm:px-8 md:pt-24">
          <p className="text-xs font-semibold tracking-[0.4em] uppercase" style={{ color: blue }}>Mobile detailing · We come to you</p>
          <h1 className="mx-auto mt-5 max-w-4xl font-[family-name:var(--font-bebas)] text-[72px] leading-[0.88] tracking-wide sm:text-[136px]">
            Showroom shine.<br /><span className="bg-gradient-to-r from-white via-[#9fd5ff] to-[#3da9fc] bg-clip-text text-transparent">Every time.</span>
          </h1>
          <p className="mx-auto mt-6 max-w-xl text-lg text-[#8a93a3]">Professional hand detailing, paint correction and ceramic coatings — at your home or office.</p>
          <div className="mt-9 flex flex-wrap justify-center gap-3">
            <a href="#book" className="rounded-md px-8 py-4 font-semibold text-[#07080a] transition hover:brightness-110" style={{ background: blue }}>Book a Detail</a>
            <a href="#packages" className="rounded-md border border-white/20 px-8 py-4 font-semibold transition hover:border-white/50">View Packages</a>
          </div>
          <CarArt className="mx-auto mt-10 w-full max-w-3xl" />
        </div>
        <ul className="relative mx-auto grid max-w-[1200px] grid-cols-2 border-t border-white/10 md:grid-cols-4">
          {[{ i: Droplet, t: "pH-neutral products" }, { i: ShieldCheck, t: "Fully insured" }, { i: Wind, t: "Water-saving wash" }, { i: Sparkles, t: "Satisfaction guarantee" }].map(({ i: I, t }) => (
            <li key={t} className="flex items-center justify-center gap-2 border-r border-white/10 py-5 text-sm text-white/70 last:border-r-0"><I className="h-4 w-4" style={{ color: blue }} />{t}</li>
          ))}
        </ul>
      </section>

      {/* PACKAGES */}
      <section id="packages" className="mx-auto max-w-[1200px] px-5 py-20 sm:px-8 sm:py-28">
        <div className="flex flex-col items-start justify-between gap-6 md:flex-row md:items-end">
          <div>
            <h2 className="font-[family-name:var(--font-bebas)] text-6xl tracking-wide sm:text-7xl">Detail packages</h2>
            <p className="mt-2 text-[#8a93a3]">Choose your vehicle size to see pricing.</p>
          </div>
          <div role="group" aria-label="Vehicle size" className="flex flex-wrap gap-2">
            {sizes.map((s) => (
              <button key={s.k} type="button" aria-pressed={size === s.k} onClick={() => setSize(s.k)} className={`inline-flex items-center gap-2 rounded-md border px-4 py-2.5 text-sm font-semibold transition ${size === s.k ? "border-[#3da9fc] bg-[#3da9fc]/10 text-[#3da9fc]" : "border-white/15 text-white/70 hover:border-white/40"}`}>
                {s.k === "truck" ? <Truck className="h-4 w-4" /> : <Car className="h-4 w-4" />}{s.l}
              </button>
            ))}
          </div>
        </div>
        <div className="mt-12 grid gap-5 md:grid-cols-3">
          {packages.map((p) => (
            <button
              type="button"
              key={p.n}
              onClick={() => setPkg(p.n)}
              aria-pressed={pkg === p.n}
              className={`relative flex flex-col rounded-xl border p-8 text-left transition ${pkg === p.n ? "border-[#3da9fc] bg-gradient-to-b from-[#3da9fc]/15 to-transparent shadow-[0_0_60px_-20px_#3da9fc]" : "border-white/10 bg-white/[0.02] hover:border-white/30"}`}
            >
              {p.pop && <span className="absolute -top-3 left-8 rounded bg-[#3da9fc] px-2 py-0.5 text-[11px] font-bold tracking-wider text-[#07080a] uppercase">Most popular</span>}
              <span className="font-[family-name:var(--font-bebas)] text-4xl tracking-wide">{p.n}</span>
              <span className="text-sm text-[#8a93a3]">Approx. {p.time}</span>
              <span className="mt-6 font-[family-name:var(--font-bebas)] text-6xl">${Math.round(p.p * m)}</span>
              <ul className="mt-6 space-y-3">
                {p.f.map((f) => <li key={f} className="flex gap-3 text-[15px] text-white/80"><Check className="h-5 w-5 shrink-0" style={{ color: blue }} />{f}</li>)}
              </ul>
            </button>
          ))}
        </div>

        <div className="mt-8 grid gap-6 rounded-xl border border-white/10 bg-white/[0.02] p-6 md:grid-cols-[1.5fr_1fr] md:p-8">
          <fieldset>
            <legend className="font-[family-name:var(--font-bebas)] text-3xl tracking-wide">Add-ons</legend>
            <div className="mt-4 grid gap-3 sm:grid-cols-2">
              {addons.map((a) => (
                <label key={a.n} className="flex cursor-pointer items-center justify-between gap-3 rounded-lg border border-white/10 px-4 py-3 transition has-[:checked]:border-[#3da9fc] has-[:checked]:bg-[#3da9fc]/10">
                  <span className="flex items-center gap-3 text-[15px]">
                    <input type="checkbox" className="h-4 w-4 accent-[#3da9fc]" checked={extras.includes(a.n)} onChange={(e) => setExtras((x) => (e.target.checked ? [...x, a.n] : x.filter((y) => y !== a.n)))} />
                    {a.n}
                  </span>
                  <span className="text-sm text-[#8a93a3]">+${a.p}</span>
                </label>
              ))}
            </div>
          </fieldset>
          <div className="flex flex-col justify-between rounded-lg bg-[#3da9fc]/10 p-6" aria-live="polite">
            <div>
              <p className="text-sm tracking-wider text-[#8a93a3] uppercase">Estimated total</p>
              <p className="font-[family-name:var(--font-bebas)] text-7xl" style={{ color: blue }}>${total}</p>
              <p className="text-sm text-white/60">{pkg} · {sizes.find((s) => s.k === size)!.l}{extras.length ? ` · ${extras.length} add-on${extras.length > 1 ? "s" : ""}` : ""}</p>
            </div>
            <a href="#book" className="mt-6 rounded-md py-3.5 text-center font-semibold text-[#07080a]" style={{ background: blue }}>Book this detail</a>
          </div>
        </div>
      </section>

      {/* GALLERY */}
      <section id="gallery" className="border-y border-white/10 bg-[#0d0f13]">
        <div className="mx-auto max-w-[1200px] px-5 py-20 sm:px-8 sm:py-28">
          <h2 className="font-[family-name:var(--font-bebas)] text-6xl tracking-wide sm:text-7xl">The gallery</h2>
          <div className="mt-12 grid grid-cols-2 gap-3 md:grid-cols-4">
            {[
              { t: "Paint correction", g: "linear-gradient(135deg,#0b1d33,#1c4f80)" },
              { t: "Ceramic coating", g: "linear-gradient(135deg,#151515,#3a3f4a)" },
              { t: "Interior steam", g: "linear-gradient(135deg,#2a1d14,#6b4a33)" },
              { t: "Wheel detail", g: "linear-gradient(135deg,#1a1a1a,#5c636d)" },
              { t: "Headlight restore", g: "linear-gradient(135deg,#1f2a1b,#55724a)" },
              { t: "Signature detail", g: "linear-gradient(135deg,#2c0f12,#7a1f28)" },
              { t: "Engine bay", g: "linear-gradient(135deg,#1c1c22,#43434f)" },
              { t: "Glass coating", g: "linear-gradient(135deg,#0b2433,#2a7aa8)" },
            ].map((g, i) => (
              <figure key={g.t} className={`group relative overflow-hidden rounded-lg ${i === 0 || i === 5 ? "md:col-span-2" : ""}`}>
                <div className="aspect-[4/3] h-full w-full transition duration-500 group-hover:scale-105" style={{ background: g.g }}>
                  <Car className="absolute top-1/2 left-1/2 h-1/3 w-1/3 -translate-x-1/2 -translate-y-1/2 text-white/10" strokeWidth={1} />
                  <div className="absolute inset-0 bg-[linear-gradient(115deg,transparent_40%,rgba(255,255,255,.18)_50%,transparent_60%)] opacity-0 transition duration-700 group-hover:translate-x-1/3 group-hover:opacity-100" />
                </div>
                <figcaption className="absolute bottom-3 left-3 font-[family-name:var(--font-bebas)] text-2xl tracking-wide">{g.t}</figcaption>
              </figure>
            ))}
          </div>
        </div>
      </section>

      {/* BOOK */}
      <section id="book" className="mx-auto grid max-w-[1200px] gap-12 px-5 py-20 sm:px-8 sm:py-28 md:grid-cols-[1fr_1.4fr]">
        <div>
          <h2 className="font-[family-name:var(--font-bebas)] text-6xl tracking-wide sm:text-7xl">Book your detail</h2>
          <p className="mt-3 text-[#8a93a3]">Request a time and we&apos;ll confirm by text. We bring water, power and all equipment.</p>
          <div className="mt-8 rounded-lg border border-white/10 p-5">
            <p className="text-sm text-[#8a93a3]">Your selection</p>
            <p className="mt-1 text-lg font-semibold">{pkg} · {sizes.find((s) => s.k === size)!.l}</p>
            <p className="font-[family-name:var(--font-bebas)] text-4xl" style={{ color: blue }}>${total}</p>
          </div>
        </div>
        <DemoForm
          demoName={NAME}
          submitLabel="Request Booking"
          className="grid gap-4 sm:grid-cols-2"
          buttonClass="sm:col-span-2 mt-2 rounded-md bg-[#3da9fc] py-4 font-semibold text-[#07080a] hover:brightness-110 transition"
          noticeClass="sm:col-span-2 border-[#3da9fc]/40 bg-[#0d0f13] text-white"
        >
          {[
            { l: "Name", n: "name", t: "text", ac: "name" },
            { l: "Phone", n: "phone", t: "tel", ac: "tel" },
            { l: "Vehicle (year, make, model)", n: "vehicle", t: "text" },
            { l: "Service address", n: "address", t: "text", ac: "street-address" },
            { l: "Preferred date", n: "date", t: "date" },
            { l: "Preferred time", n: "time", t: "time" },
          ].map((x) => (
            <label key={x.n} className="block text-sm text-[#8a93a3]">
              {x.l}
              <input required name={x.n} type={x.t} autoComplete={x.ac} className="mt-1.5 w-full rounded-md border border-white/15 bg-white/[0.03] px-4 py-3 text-white outline-none [color-scheme:dark] focus:border-[#3da9fc]" />
            </label>
          ))}
        </DemoForm>
      </section>

      <footer id="contact" className="border-t border-white/10">
        <div className="mx-auto grid max-w-[1200px] gap-6 px-5 py-12 text-sm text-[#8a93a3] sm:px-8 md:grid-cols-3">
          <p className="font-[family-name:var(--font-bebas)] text-3xl tracking-[0.08em] text-white">ELITE<span style={{ color: blue }}>/</span>AUTO</p>
          <div className="space-y-2">
            <a href="tel:+15550100193" className="flex items-center gap-2 hover:text-white"><Phone className="h-4 w-4" style={{ color: blue }} />(555) 010-0193</a>
            <a href="mailto:book@eliteauto.example" className="flex items-center gap-2 hover:text-white"><Mail className="h-4 w-4" style={{ color: blue }} />book@eliteauto.example</a>
            <p className="flex items-center gap-2"><MapPin className="h-4 w-4" style={{ color: blue }} />Mobile service across Anytown</p>
          </div>
          <p>Mon–Sat · 8am – 6pm<br />© Elite Auto Detailing (fictional demo)</p>
        </div>
      </footer>
    </div>
  );
}
