"use client";

import { useState } from "react";
import { AlertTriangle, BadgeDollarSign, Clock, Droplets, Flame, Info, MapPin, Phone, ShieldCheck, ShowerHead, Star, Toilet, Wrench, Zap } from "lucide-react";
import { PlumbingArt } from "@/components/art/Art";
import { DemoForm, DemoNav } from "./shared";

const NAME = "ProFlow Plumbing";

const services = [
  { i: Droplets, t: "Leak Detection & Repair", d: "Find and fix hidden leaks before they cause damage." },
  { i: Wrench, t: "Drain Cleaning", d: "Clogged sinks, tubs and main lines cleared fast." },
  { i: Flame, t: "Water Heaters", d: "Repair and installation of tank and tankless units." },
  { i: Toilet, t: "Toilet Repair", d: "Running, leaking or clogged toilets fixed same day." },
  { i: ShowerHead, t: "Fixture Installation", d: "Faucets, showers, disposals and more." },
  { i: Zap, t: "Emergency Service", d: "Burst pipes and floods handled around the clock." },
];

const reviews = [
  { n: "Sample Customer A", t: "Fixed our water heater the same afternoon. Clear pricing and very respectful of our home.", s: 5 },
  { n: "Sample Customer B", t: "Called at 11pm with a burst pipe. They arrived within the hour and explained everything.", s: 5 },
  { n: "Sample Customer C", t: "Upfront quote, no surprises on the bill, and they cleaned up after the job.", s: 5 },
];

const zips = ["00001", "00002", "00003", "00004", "00005", "00010", "00011", "00012"];
const areas = ["Anytown", "Riverside", "Lakeview", "Westbrook", "Cedar Falls", "Oak Hill"];

export default function ProFlow() {
  const [zip, setZip] = useState("");
  const [checked, setChecked] = useState<null | boolean>(null);

  return (
    <div id="top" className="bg-white font-[family-name:var(--font-archivo)] text-[#0b1f44]">
      <a href="tel:+15550100110" className="block bg-[#f97316] text-white">
        <div className="mx-auto flex max-w-[1200px] items-center justify-center gap-2 px-5 py-2.5 text-sm font-semibold sm:px-8">
          <AlertTriangle className="h-4 w-4" />
          <span>24/7 Emergency Plumbing — Call <span className="underline">(555) 010-0110</span></span>
        </div>
      </a>
      <DemoNav
        brand={
          <span className="flex items-center gap-2 text-xl font-extrabold tracking-tight">
            <span className="flex h-9 w-9 items-center justify-center rounded-full bg-[#1d4ed8] text-white"><Droplets className="h-5 w-5" /></span>
            ProFlow<span className="font-medium text-[#1d4ed8]">Plumbing</span>
          </span>
        }
        links={[
          { label: "Services", href: "#services" },
          { label: "Reviews", href: "#reviews" },
          { label: "Service Areas", href: "#areas" },
          { label: "Estimate", href: "#estimate" },
        ]}
        cta={{ label: "Request Service", href: "#estimate" }}
        className="bg-white/95 backdrop-blur border-b border-[#0b1f44]/10 text-[#0b1f44]"
        linkClass="text-[15px] font-medium text-[#0b1f44]/70 hover:text-[#1d4ed8]"
        ctaClass="rounded-lg bg-[#1d4ed8] px-5 py-2.5 text-sm font-semibold text-white hover:bg-[#1e40af]"
        menuClass="bg-white border-t border-[#0b1f44]/10"
      />

      {/* HERO */}
      <section className="relative overflow-hidden bg-gradient-to-b from-[#e6f0ff] to-white">
        <div className="mx-auto grid max-w-[1200px] items-center gap-12 px-5 py-14 sm:px-8 md:grid-cols-[1.15fr_1fr] md:py-20">
          <div>
            <p className="inline-flex items-center gap-2 rounded-full bg-white px-3 py-1.5 text-sm font-semibold text-[#1d4ed8] shadow-sm">
              <Clock className="h-4 w-4" /> Same-day appointments available
            </p>
            <h1 className="mt-6 text-[44px] leading-[1.03] font-extrabold tracking-tight sm:text-[62px]">
              Fast, honest plumbing — <span className="text-[#1d4ed8]">day or night.</span>
            </h1>
            <p className="mt-5 max-w-lg text-lg text-[#5a6a85]">Licensed plumbers, upfront pricing and a clean, respectful crew. From dripping faucets to burst pipes, we&apos;ve got it handled.</p>
            <div className="mt-8 flex flex-wrap gap-3">
              <a href="tel:+15550100110" className="inline-flex items-center gap-2 rounded-lg bg-[#f97316] px-6 py-4 font-bold text-white shadow-lg shadow-[#f97316]/30 transition hover:bg-[#ea580c]"><Phone className="h-5 w-5" /> Call (555) 010-0110</a>
              <a href="#estimate" className="rounded-lg border-2 border-[#1d4ed8] px-6 py-4 font-bold text-[#1d4ed8] transition hover:bg-[#1d4ed8] hover:text-white">Request an Estimate</a>
            </div>
            <ul className="mt-10 grid max-w-lg grid-cols-3 gap-4">
              {[{ i: ShieldCheck, t: "Licensed & insured" }, { i: BadgeDollarSign, t: "Upfront pricing" }, { i: Clock, t: "24/7 emergencies" }].map(({ i: I, t }) => (
                <li key={t} className="flex flex-col items-start gap-2 text-sm font-semibold"><I className="h-6 w-6 text-[#1d4ed8]" />{t}</li>
              ))}
            </ul>
          </div>
          <div className="relative">
            <PlumbingArt className="w-full" />
          </div>
        </div>
      </section>

      {/* SERVICES */}
      <section id="services" className="mx-auto max-w-[1200px] px-5 py-20 sm:px-8 sm:py-24">
        <div className="text-center">
          <p className="font-semibold text-[#1d4ed8]">Our services</p>
          <h2 className="mt-2 text-4xl font-extrabold tracking-tight sm:text-5xl">Residential plumbing, done right.</h2>
        </div>
        <div className="mt-12 grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
          {services.map(({ i: I, t, d }) => (
            <a key={t} href="#estimate" className="group flex gap-5 rounded-2xl border border-[#0b1f44]/10 p-6 transition hover:border-[#1d4ed8]/40 hover:shadow-xl hover:shadow-[#1d4ed8]/10">
              <span className="flex h-12 w-12 shrink-0 items-center justify-center rounded-xl bg-[#e6f0ff] text-[#1d4ed8] transition group-hover:bg-[#1d4ed8] group-hover:text-white"><I className="h-6 w-6" /></span>
              <span>
                <span className="block text-lg font-bold">{t}</span>
                <span className="mt-1 block text-[15px] text-[#5a6a85]">{d}</span>
              </span>
            </a>
          ))}
        </div>
      </section>

      {/* EMERGENCY BAND */}
      <section className="bg-[#0b1f44] text-white">
        <div className="mx-auto flex max-w-[1200px] flex-col items-start justify-between gap-6 px-5 py-12 sm:px-8 md:flex-row md:items-center">
          <div>
            <p className="flex items-center gap-2 text-sm font-bold tracking-wider text-[#f97316] uppercase"><AlertTriangle className="h-4 w-4" /> Plumbing emergency?</p>
            <p className="mt-2 text-3xl font-extrabold tracking-tight">Shut off your main valve, then call us. We&apos;re on the way.</p>
          </div>
          <a href="tel:+15550100110" className="inline-flex shrink-0 items-center gap-2 rounded-lg bg-[#f97316] px-7 py-4 text-lg font-bold transition hover:bg-[#ea580c]"><Phone className="h-5 w-5" /> (555) 010-0110</a>
        </div>
      </section>

      {/* REVIEWS (sample) */}
      <section id="reviews" className="bg-[#f5f8ff]">
        <div className="mx-auto max-w-[1200px] px-5 py-20 sm:px-8 sm:py-24">
          <div className="flex flex-col items-start justify-between gap-4 md:flex-row md:items-end">
            <div>
              <p className="font-semibold text-[#1d4ed8]">Reviews</p>
              <h2 className="mt-2 text-4xl font-extrabold tracking-tight sm:text-5xl">What customers say</h2>
            </div>
            <p className="flex max-w-sm items-start gap-2 rounded-lg border border-[#f97316]/30 bg-white p-3 text-sm text-[#5a6a85]">
              <Info className="mt-0.5 h-4 w-4 shrink-0 text-[#f97316]" />
              Sample content: these reviews are fictional placeholders that show how real customer reviews would be displayed.
            </p>
          </div>
          <div className="mt-12 grid gap-5 md:grid-cols-3">
            {reviews.map((r) => (
              <figure key={r.n} className="relative rounded-2xl bg-white p-7 shadow-sm">
                <span className="absolute top-4 right-4 rounded bg-[#f5f8ff] px-2 py-0.5 text-[10px] font-bold tracking-wider text-[#5a6a85] uppercase">Sample</span>
                <div className="flex gap-0.5" aria-label={`${r.s} out of 5 stars`}>
                  {Array.from({ length: r.s }).map((_, i) => <Star key={i} className="h-5 w-5 fill-[#f59e0b] text-[#f59e0b]" />)}
                </div>
                <blockquote className="mt-4 text-[16px] leading-relaxed">&ldquo;{r.t}&rdquo;</blockquote>
                <figcaption className="mt-5 text-sm font-semibold text-[#5a6a85]">— {r.n}</figcaption>
              </figure>
            ))}
          </div>
        </div>
      </section>

      {/* AREAS */}
      <section id="areas" className="mx-auto grid max-w-[1200px] items-center gap-12 px-5 py-20 sm:px-8 sm:py-24 md:grid-cols-2">
        <div>
          <p className="font-semibold text-[#1d4ed8]">Service areas</p>
          <h2 className="mt-2 text-4xl font-extrabold tracking-tight">Do we serve your area?</h2>
          <p className="mt-3 text-[#5a6a85]">Enter your ZIP code to check. (Demo ZIPs: 00001–00005.)</p>
          <form
            className="mt-6 flex gap-2"
            onSubmit={(e) => {
              e.preventDefault();
              setChecked(zips.includes(zip.trim()));
            }}
          >
            <label htmlFor="zip-check" className="sr-only">ZIP code</label>
            <input id="zip-check" inputMode="numeric" maxLength={5} value={zip} onChange={(e) => { setZip(e.target.value.replace(/\D/g, "")); setChecked(null); }} placeholder="ZIP code" className="w-40 rounded-lg border border-[#0b1f44]/15 px-4 py-3 outline-none focus:border-[#1d4ed8] focus:ring-4 focus:ring-[#1d4ed8]/10" />
            <button className="rounded-lg bg-[#0b1f44] px-5 py-3 font-semibold text-white hover:bg-[#13306a]">Check</button>
          </form>
          <p aria-live="polite" className="mt-3 min-h-6 text-sm font-semibold">
            {checked === true && <span className="text-emerald-600">Great news — we serve your area!</span>}
            {checked === false && <span className="text-[#f97316]">We may not cover that ZIP yet — call us to confirm.</span>}
          </p>
        </div>
        <ul className="grid grid-cols-2 gap-3">
          {areas.map((a) => (
            <li key={a} className="flex items-center gap-3 rounded-xl border border-[#0b1f44]/10 p-4 font-semibold"><MapPin className="h-5 w-5 text-[#1d4ed8]" />{a}</li>
          ))}
        </ul>
      </section>

      {/* ESTIMATE */}
      <section id="estimate" className="bg-gradient-to-b from-white to-[#e6f0ff]">
        <div className="mx-auto max-w-[860px] px-5 py-20 sm:px-8 sm:py-24">
          <div className="text-center">
            <h2 className="text-4xl font-extrabold tracking-tight sm:text-5xl">Request a free estimate</h2>
            <p className="mt-3 text-[#5a6a85]">Not an emergency? Send us the details and we&apos;ll reply with a quote and available times.</p>
          </div>
          <DemoForm
            demoName={NAME}
            submitLabel="Request Estimate"
            className="mt-10 grid gap-4 rounded-2xl bg-white p-6 shadow-xl shadow-[#1d4ed8]/10 sm:grid-cols-2 sm:p-10"
            buttonClass="sm:col-span-2 rounded-lg bg-[#1d4ed8] py-4 font-bold text-white hover:bg-[#1e40af] transition"
            noticeClass="sm:col-span-2 border-[#1d4ed8]/25 bg-[#f5f8ff] text-[#0b1f44]"
          >
            {[
              { l: "Name", n: "name", t: "text", ac: "name" },
              { l: "Phone", n: "phone", t: "tel", ac: "tel" },
              { l: "Email", n: "email", t: "email", ac: "email" },
              { l: "ZIP code", n: "zip", t: "text", ac: "postal-code" },
            ].map((x) => (
              <label key={x.n} className="block text-sm font-semibold">
                {x.l}
                <input required name={x.n} type={x.t} autoComplete={x.ac} className="mt-1.5 w-full rounded-lg border border-[#0b1f44]/15 px-4 py-3 font-normal outline-none focus:border-[#1d4ed8] focus:ring-4 focus:ring-[#1d4ed8]/10" />
              </label>
            ))}
            <label className="block text-sm font-semibold sm:col-span-2">
              Service needed
              <select required name="service" defaultValue="" className="mt-1.5 w-full rounded-lg border border-[#0b1f44]/15 bg-white px-4 py-3 font-normal outline-none focus:border-[#1d4ed8]">
                <option value="" disabled>Select…</option>
                {services.map((s) => <option key={s.t}>{s.t}</option>)}
              </select>
            </label>
            <label className="block text-sm font-semibold sm:col-span-2">
              Describe the problem
              <textarea required name="details" rows={4} className="mt-1.5 w-full rounded-lg border border-[#0b1f44]/15 px-4 py-3 font-normal outline-none focus:border-[#1d4ed8]" />
            </label>
          </DemoForm>
        </div>
      </section>

      <footer className="bg-[#0b1f44] text-white/70">
        <div className="mx-auto flex max-w-[1200px] flex-col justify-between gap-4 px-5 py-10 text-sm sm:flex-row sm:px-8">
          <p className="font-bold text-white">ProFlow Plumbing</p>
          <p>(555) 010-0110 · service@proflow.example</p>
          <p>© ProFlow Plumbing (fictional demo)</p>
        </div>
      </footer>

      {/* Mobile sticky call */}
      <a href="tel:+15550100110" className="fixed right-4 bottom-4 z-40 flex h-14 w-14 items-center justify-center rounded-full bg-[#f97316] text-white shadow-xl md:hidden" aria-label="Call ProFlow Plumbing">
        <Phone className="h-6 w-6" />
      </a>
    </div>
  );
}
