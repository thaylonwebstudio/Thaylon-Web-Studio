import { Clock, MapPin, Phone, Scissors } from "lucide-react";
import { BarberArt } from "@/components/art/Art";
import { DemoForm, DemoNav } from "./shared";

const NAME = "The Gentleman's Cut";
const gold = "#c9a24a";

const prices = [
  { s: "Classic Haircut", d: "Consultation, cut, hot-towel finish, style", p: 35, t: "45 min" },
  { s: "Skin Fade", d: "Precision fade with foil-shaver finish", p: 40, t: "45 min" },
  { s: "Beard Sculpt", d: "Shape, line-up, hot towel & beard oil", p: 25, t: "30 min" },
  { s: "Royal Shave", d: "Straight-razor shave, hot towels, aftershave balm", p: 45, t: "45 min" },
  { s: "Cut & Beard", d: "Our most popular combination", p: 55, t: "60 min" },
  { s: "Kids' Cut (12 & under)", d: "Patient, friendly, sharp", p: 25, t: "30 min" },
];

const barbers = [
  { n: "Marcus R.", r: "Master Barber", s: "Fades · Tapers · Designs", i: "MR" },
  { n: "Diego A.", r: "Senior Barber", s: "Classic cuts · Scissor work", i: "DA" },
  { n: "Sam K.", r: "Barber & Shave Specialist", s: "Straight-razor shaves · Beards", i: "SK" },
];

const gallery = ["Low Fade", "Textured Crop", "Side Part", "Beard Line-Up", "Pompadour", "Buzz & Beard"];

export default function GentlemansCut() {
  return (
    <div id="top" className="bg-[#151515] font-sans text-[#f3efe7]">
      <DemoNav
        brand={
          <span className="flex items-center gap-3 font-[family-name:var(--font-oswald)] uppercase">
            <span className="flex h-10 w-10 items-center justify-center border-2" style={{ borderColor: gold, color: gold }}><Scissors className="h-5 w-5" /></span>
            <span className="leading-none"><span className="block text-[11px] tracking-[0.35em] text-[#9b958a]">The</span><span className="text-xl font-semibold tracking-wider">Gentleman&apos;s Cut</span></span>
          </span>
        }
        links={[
          { label: "Services", href: "#services" },
          { label: "Barbers", href: "#barbers" },
          { label: "Gallery", href: "#gallery" },
          { label: "Visit", href: "#visit" },
        ]}
        cta={{ label: "Book a Chair", href: "#book" }}
        className="bg-[#151515]/95 border-b border-white/10 text-[#f3efe7] backdrop-blur"
        linkClass="font-[family-name:var(--font-oswald)] text-[15px] uppercase tracking-[0.15em] text-[#f3efe7]/70 hover:text-[#c9a24a]"
        ctaClass="font-[family-name:var(--font-oswald)] uppercase tracking-[0.15em] text-sm bg-[#c9a24a] px-5 py-2.5 text-[#151515] font-semibold hover:bg-[#d8b25c]"
        menuClass="bg-[#151515] border-t border-white/10 font-[family-name:var(--font-oswald)] uppercase tracking-wider"
      />

      {/* HERO */}
      <section className="relative overflow-hidden border-b border-white/10">
        <div className="absolute inset-0 opacity-[0.07]" style={{ backgroundImage: "repeating-linear-gradient(45deg,#fff 0 1px,transparent 1px 14px)" }} />
        <div className="relative mx-auto grid max-w-[1200px] items-center gap-10 px-5 py-16 sm:px-8 md:grid-cols-[1.3fr_1fr] md:py-28">
          <div>
            <p className="font-[family-name:var(--font-oswald)] text-sm tracking-[0.4em] uppercase" style={{ color: gold }}>Est. Barbershop · Anytown</p>
            <h1 className="mt-5 font-[family-name:var(--font-oswald)] text-[64px] leading-[0.92] font-bold uppercase sm:text-[104px]">
              Sharp cuts.<br /><span style={{ color: gold }}>Classic</span> shaves.
            </h1>
            <p className="mt-6 max-w-md text-lg text-[#9b958a]">
              Old-school craft, modern style. Precision haircuts, hot-towel shaves and beard work in a relaxed, no-rush chair.
            </p>
            <div className="mt-9 flex flex-wrap gap-3 font-[family-name:var(--font-oswald)] tracking-[0.15em] uppercase">
              <a href="#book" className="px-8 py-4 font-semibold text-[#151515] transition hover:brightness-110" style={{ background: gold }}>Book a Chair</a>
              <a href="#services" className="border border-white/25 px-8 py-4 transition hover:border-white/60">Prices</a>
            </div>
          </div>
          <div className="relative border p-6" style={{ borderColor: `${gold}55` }}>
            <span className="absolute -top-3 left-6 bg-[#151515] px-2 font-[family-name:var(--font-oswald)] text-xs tracking-[0.3em] uppercase" style={{ color: gold }}>Since day one</span>
            <BarberArt className="w-full" />
          </div>
        </div>
      </section>

      {/* SERVICES */}
      <section id="services" className="mx-auto max-w-[1200px] px-5 py-20 sm:px-8 sm:py-28">
        <div className="grid gap-12 md:grid-cols-[1fr_2fr]">
          <div>
            <p className="font-[family-name:var(--font-oswald)] text-sm tracking-[0.4em] uppercase" style={{ color: gold }}>Services</p>
            <h2 className="mt-4 font-[family-name:var(--font-oswald)] text-5xl font-bold uppercase sm:text-6xl">Price list</h2>
            <p className="mt-4 text-[#9b958a]">Every service includes a consultation, hot towel and styling. Walk-ins welcome when chairs are open.</p>
          </div>
          <ul className="divide-y divide-white/10 border-y border-white/10">
            {prices.map((p, i) => (
              <li key={p.s} className="group grid grid-cols-[auto_1fr_auto] items-baseline gap-5 py-6">
                <span className="font-[family-name:var(--font-oswald)] text-sm text-[#9b958a]">{String(i + 1).padStart(2, "0")}</span>
                <div>
                  <h3 className="font-[family-name:var(--font-oswald)] text-2xl tracking-wide uppercase transition group-hover:text-[#c9a24a]">{p.s}</h3>
                  <p className="mt-1 text-[15px] text-[#9b958a]">{p.d} · {p.t}</p>
                </div>
                <span className="font-[family-name:var(--font-oswald)] text-3xl font-semibold" style={{ color: gold }}>${p.p}</span>
              </li>
            ))}
          </ul>
        </div>
      </section>

      {/* BARBERS */}
      <section id="barbers" className="bg-[#f3efe7] text-[#151515]">
        <div className="mx-auto max-w-[1200px] px-5 py-20 sm:px-8 sm:py-28">
          <h2 className="font-[family-name:var(--font-oswald)] text-5xl font-bold uppercase sm:text-6xl">Meet the barbers</h2>
          <div className="mt-12 grid gap-6 md:grid-cols-3">
            {barbers.map((b) => (
              <article key={b.n} className="group border border-[#151515]/15 bg-white">
                <div className="relative flex aspect-[4/3] items-center justify-center overflow-hidden bg-[#1f1f1f]">
                  <div className="absolute inset-0 opacity-20" style={{ backgroundImage: "repeating-linear-gradient(-45deg,#a7262b 0 12px,#f3efe7 12px 24px,#1f3b6e 24px 36px,#f3efe7 36px 48px)" }} />
                  <span className="relative flex h-28 w-28 items-center justify-center rounded-full border-2 bg-[#151515] font-[family-name:var(--font-oswald)] text-4xl font-semibold text-[#f3efe7] transition group-hover:scale-105" style={{ borderColor: gold }}>{b.i}</span>
                </div>
                <div className="p-6">
                  <h3 className="font-[family-name:var(--font-oswald)] text-2xl uppercase">{b.n}</h3>
                  <p className="text-sm font-semibold tracking-wider uppercase" style={{ color: "#8a6d2a" }}>{b.r}</p>
                  <p className="mt-3 text-[15px] text-[#151515]/65">{b.s}</p>
                  <a href="#book" className="mt-5 inline-block border-b-2 pb-0.5 font-[family-name:var(--font-oswald)] text-sm tracking-[0.15em] uppercase" style={{ borderColor: gold }}>Book with {b.n.split(" ")[0]}</a>
                </div>
              </article>
            ))}
          </div>
        </div>
      </section>

      {/* GALLERY */}
      <section id="gallery" className="mx-auto max-w-[1200px] px-5 py-20 sm:px-8 sm:py-28">
        <div className="flex items-end justify-between gap-6">
          <h2 className="font-[family-name:var(--font-oswald)] text-5xl font-bold uppercase sm:text-6xl">Fresh work</h2>
          <p className="hidden max-w-xs text-right text-[#9b958a] sm:block">Styles from our chairs. Bring a photo — or let us recommend.</p>
        </div>
        <div className="mt-12 grid grid-cols-2 gap-3 md:grid-cols-3">
          {gallery.map((g, i) => (
            <figure key={g} className="group relative aspect-square overflow-hidden bg-[#1f1f1f]">
              <div className="absolute inset-0 transition duration-500 group-hover:scale-110" style={{ background: `radial-gradient(circle at ${30 + i * 10}% ${40 + (i % 3) * 10}%, #3a3a3a, #121212 70%)` }} />
              <Scissors className="absolute top-1/2 left-1/2 h-16 w-16 -translate-x-1/2 -translate-y-1/2 text-white/10" strokeWidth={1} />
              <figcaption className="absolute inset-x-0 bottom-0 flex items-center justify-between p-4 font-[family-name:var(--font-oswald)] text-lg tracking-wider uppercase">
                {g}<span className="h-px w-8" style={{ background: gold }} />
              </figcaption>
            </figure>
          ))}
        </div>
      </section>

      {/* BOOK */}
      <section id="book" className="border-y border-white/10 bg-[#1b1b1b]">
        <div className="mx-auto grid max-w-[1200px] gap-12 px-5 py-20 sm:px-8 sm:py-28 md:grid-cols-[1fr_1.4fr]">
          <div>
            <p className="font-[family-name:var(--font-oswald)] text-sm tracking-[0.4em] uppercase" style={{ color: gold }}>Appointments</p>
            <h2 className="mt-4 font-[family-name:var(--font-oswald)] text-5xl font-bold uppercase sm:text-6xl">Request your chair</h2>
            <p className="mt-4 text-[#9b958a]">Pick your barber and preferred time. We&apos;ll text you to confirm within the hour during business hours.</p>
          </div>
          <DemoForm
            demoName={NAME}
            submitLabel="REQUEST APPOINTMENT"
            className="grid gap-4 sm:grid-cols-2"
            buttonClass="sm:col-span-2 mt-2 bg-[#c9a24a] py-4 font-[family-name:var(--font-oswald)] font-semibold tracking-[0.2em] text-[#151515] hover:bg-[#d8b25c] transition"
            noticeClass="sm:col-span-2 border-[#c9a24a]/40 bg-[#151515] text-[#f3efe7]"
          >
            {[
              { l: "Name", n: "name", t: "text", ac: "name" },
              { l: "Mobile", n: "phone", t: "tel", ac: "tel" },
              { l: "Date", n: "date", t: "date" },
              { l: "Preferred time", n: "time", t: "time" },
            ].map((x) => (
              <label key={x.n} className="block text-xs font-semibold tracking-[0.2em] text-[#9b958a] uppercase">
                {x.l}
                <input required name={x.n} type={x.t} autoComplete={x.ac} className="mt-2 w-full border border-white/15 bg-[#151515] px-4 py-3 text-base tracking-normal text-[#f3efe7] normal-case outline-none [color-scheme:dark] focus:border-[#c9a24a]" />
              </label>
            ))}
            {[
              { l: "Barber", n: "barber", o: ["No preference", ...barbers.map((b) => b.n)] },
              { l: "Service", n: "service", o: prices.map((p) => `${p.s} — $${p.p}`) },
            ].map((x) => (
              <label key={x.n} className="block text-xs font-semibold tracking-[0.2em] text-[#9b958a] uppercase">
                {x.l}
                <select required name={x.n} defaultValue="" className="mt-2 w-full border border-white/15 bg-[#151515] px-4 py-3 text-base tracking-normal text-[#f3efe7] normal-case outline-none focus:border-[#c9a24a]">
                  <option value="" disabled>Select…</option>
                  {x.o.map((o) => <option key={o}>{o}</option>)}
                </select>
              </label>
            ))}
          </DemoForm>
        </div>
      </section>

      {/* VISIT */}
      <section id="visit" className="mx-auto grid max-w-[1200px] gap-10 px-5 py-16 sm:px-8 md:grid-cols-3">
        {[
          { i: MapPin, h: "Location", b: <>456 Barber Row<br />Anytown, USA 00000</> },
          { i: Clock, h: "Hours", b: <>Tue–Fri · 10am – 8pm<br />Sat · 9am – 5pm · Sun–Mon closed</> },
          { i: Phone, h: "Call or text", b: <a href="tel:+15550100188" className="hover:text-[#c9a24a]">(555) 010-0188</a> },
        ].map(({ i: I, h, b }) => (
          <div key={h} className="border-l-2 pl-5" style={{ borderColor: gold }}>
            <p className="flex items-center gap-2 font-[family-name:var(--font-oswald)] text-lg tracking-[0.2em] uppercase"><I className="h-4 w-4" style={{ color: gold }} />{h}</p>
            <p className="mt-2 text-[#9b958a]">{b}</p>
          </div>
        ))}
      </section>
      <footer className="border-t border-white/10 py-6 text-center text-sm text-[#9b958a]">© The Gentleman&apos;s Cut (fictional demo). All rights reserved.</footer>
    </div>
  );
}
