"use client";

import { useState } from "react";
import { Clock, Mail, MapPin, Phone } from "lucide-react";
import { BeautyArt, MapArt } from "@/components/art/Art";
import { DemoForm, DemoNav } from "./shared";

const NAME = "Luxe Beauty Studio";

const menu: Record<string, { n: string; d: string; p: string }[]> = {
  Hair: [
    { n: "Signature Cut & Style", d: "Consultation, wash, precision cut, blowout", p: "$75+" },
    { n: "Blowout", d: "Wash and smooth or voluminous blow-dry", p: "$50" },
    { n: "Bridal & Event Styling", d: "Updos and polished event looks", p: "$120+" },
    { n: "Restorative Treatment", d: "Bond-building mask and scalp massage", p: "$45" },
  ],
  Color: [
    { n: "Single Process Color", d: "All-over, root-to-tip color", p: "$95+" },
    { n: "Balayage", d: "Hand-painted, sun-kissed dimension", p: "$185+" },
    { n: "Full Highlights", d: "Foil highlights for bright dimension", p: "$160+" },
    { n: "Gloss & Tone", d: "Shine, tone correction and refresh", p: "$55" },
  ],
  Nails: [
    { n: "Luxe Manicure", d: "Shape, cuticle care, massage, polish", p: "$40" },
    { n: "Gel Manicure", d: "Long-lasting, chip-resistant shine", p: "$55" },
    { n: "Spa Pedicure", d: "Soak, exfoliation, mask and massage", p: "$65" },
  ],
  Skin: [
    { n: "Signature Facial", d: "Customized 60-minute facial", p: "$110" },
    { n: "Brow Shaping & Tint", d: "Wax, shape and tint", p: "$40" },
    { n: "Lash Lift", d: "Natural lift and curl, lasts 6–8 weeks", p: "$85" },
  ],
};

export default function LuxeBeauty() {
  const tabs = Object.keys(menu);
  const [tab, setTab] = useState(tabs[0]);
  const serif = "font-[family-name:var(--font-cormorant)]";

  return (
    <div id="top" className="bg-[#faf5f1] font-sans text-[#3b2a26]">
      <DemoNav
        brand={<span className={`${serif} text-[28px] font-medium tracking-[0.12em] uppercase`}>Luxe<span className="text-[#b07466]">.</span></span>}
        links={[
          { label: "Services", href: "#services" },
          { label: "Gallery", href: "#gallery" },
          { label: "Visit", href: "#visit" },
        ]}
        cta={{ label: "Book Appointment", href: "#book" }}
        className="bg-[#faf5f1]/90 backdrop-blur border-b border-[#3b2a26]/10 text-[#3b2a26]"
        linkClass="text-[13px] tracking-[0.2em] uppercase text-[#3b2a26]/70 hover:text-[#b07466]"
        ctaClass="rounded-full border border-[#3b2a26] px-5 py-2.5 text-[13px] tracking-[0.15em] uppercase hover:bg-[#3b2a26] hover:text-[#faf5f1] transition"
        menuClass="bg-[#faf5f1] border-t border-[#3b2a26]/10"
      />

      {/* HERO */}
      <section className="mx-auto grid max-w-[1200px] items-center gap-12 px-5 py-16 sm:px-8 md:grid-cols-2 md:py-24">
        <div className="order-2 md:order-1">
          <p className="text-[12px] tracking-[0.35em] text-[#b07466] uppercase">Hair · Color · Nails · Skin</p>
          <h1 className={`${serif} mt-6 text-[60px] leading-[0.95] font-light sm:text-[92px]`}>
            Beauty, <em className="font-normal text-[#b07466]">thoughtfully</em> crafted.
          </h1>
          <p className="mt-6 max-w-md text-lg leading-relaxed text-[#8b7670]">
            A calm, light-filled studio where every appointment begins with listening. Leave feeling like the most polished version of yourself.
          </p>
          <div className="mt-9 flex flex-wrap items-center gap-6">
            <a href="#book" className="rounded-full bg-[#3b2a26] px-8 py-4 text-[13px] tracking-[0.2em] text-[#faf5f1] uppercase transition hover:bg-[#b07466]">Book Appointment</a>
            <a href="#services" className="border-b border-[#3b2a26] pb-1 text-[13px] tracking-[0.2em] uppercase">View Services</a>
          </div>
        </div>
        <div className="relative order-1 mx-auto w-full max-w-[440px] md:order-2">
          <BeautyArt className="w-full" />
          <div className="absolute top-10 -left-4 rotate-[-6deg] rounded-full bg-white px-5 py-3 shadow-lg sm:-left-10">
            <p className={`${serif} text-xl italic`}>New guest? <span className="text-[#b07466]">Welcome.</span></p>
          </div>
        </div>
      </section>

      {/* PHILOSOPHY */}
      <section className="border-y border-[#3b2a26]/10 bg-white">
        <div className="mx-auto max-w-3xl px-5 py-20 text-center sm:px-8">
          <p className={`${serif} text-3xl leading-snug font-light sm:text-[40px]`}>
            &ldquo;We believe beauty is personal. That&apos;s why every service is tailored — never rushed, never one-size-fits-all.&rdquo;
          </p>
          <p className="mt-6 text-[12px] tracking-[0.3em] text-[#8b7670] uppercase">— The Luxe Philosophy</p>
        </div>
      </section>

      {/* SERVICES */}
      <section id="services" className="mx-auto max-w-[1000px] px-5 py-20 sm:px-8 sm:py-28">
        <div className="text-center">
          <h2 className={`${serif} text-5xl font-light sm:text-6xl`}>Services &amp; Prices</h2>
          <p className="mt-3 text-[#8b7670]">Prices marked + vary by length and consultation.</p>
        </div>
        <div role="tablist" aria-label="Service categories" className="mt-10 flex justify-center gap-1 overflow-x-auto border-b border-[#3b2a26]/10 no-scrollbar">
          {tabs.map((t) => (
            <button
              key={t}
              role="tab"
              id={`tab-${t}`}
              aria-selected={tab === t}
              aria-controls={`panel-${t}`}
              type="button"
              onClick={() => setTab(t)}
              className={`relative px-5 py-4 text-[13px] tracking-[0.25em] uppercase transition ${tab === t ? "text-[#3b2a26]" : "text-[#8b7670] hover:text-[#3b2a26]"}`}
            >
              {t}
              {tab === t && <span className="absolute inset-x-3 -bottom-px h-0.5 bg-[#b07466]" />}
            </button>
          ))}
        </div>
        <ul id={`panel-${tab}`} role="tabpanel" aria-labelledby={`tab-${tab}`} className="mt-6 divide-y divide-[#3b2a26]/10">
          {menu[tab].map((s) => (
            <li key={s.n} className="flex items-baseline justify-between gap-6 py-6">
              <div>
                <h3 className={`${serif} text-2xl font-medium sm:text-[28px]`}>{s.n}</h3>
                <p className="mt-1 text-[15px] text-[#8b7670]">{s.d}</p>
              </div>
              <span className={`${serif} shrink-0 text-2xl text-[#b07466]`}>{s.p}</span>
            </li>
          ))}
        </ul>
      </section>

      {/* GALLERY */}
      <section id="gallery" className="bg-[#f3e9e2]">
        <div className="mx-auto max-w-[1200px] px-5 py-20 sm:px-8 sm:py-28">
          <h2 className={`${serif} text-center text-5xl font-light sm:text-6xl`}>The Gallery</h2>
          <div className="mt-12 grid grid-cols-2 gap-4 md:grid-cols-4">
            {[
              { t: "Soft balayage", g: "linear-gradient(180deg,#e7cdb8,#b98a6a)" },
              { t: "Glossy blowout", g: "linear-gradient(180deg,#5a3d33,#2e1f1a)" },
              { t: "Nude gel set", g: "linear-gradient(180deg,#f1dcd3,#d4a99a)" },
              { t: "Bridal updo", g: "linear-gradient(180deg,#efe3d6,#c8ab92)" },
            ].map((g, i) => (
              <figure key={g.t} className={`group ${i % 2 ? "md:mt-12" : ""}`}>
                <div className="relative aspect-[3/4] overflow-hidden rounded-t-full" style={{ background: g.g }}>
                  <div className="absolute inset-0 bg-white/0 transition group-hover:bg-white/10" />
                </div>
                <figcaption className={`${serif} mt-3 text-center text-xl italic`}>{g.t}</figcaption>
              </figure>
            ))}
          </div>
        </div>
      </section>

      {/* VISIT + BOOK */}
      <section id="visit" className="mx-auto grid max-w-[1200px] gap-12 px-5 py-20 sm:px-8 sm:py-28 md:grid-cols-2">
        <div>
          <h2 className={`${serif} text-5xl font-light`}>Visit the studio</h2>
          <ul className="mt-8 space-y-5 text-[15px]">
            <li className="flex gap-4"><MapPin className="h-5 w-5 shrink-0 text-[#b07466]" />789 Rosewood Avenue, Suite 2<br />Anytown, USA 00000</li>
            <li className="flex gap-4"><Clock className="h-5 w-5 shrink-0 text-[#b07466]" />Tue–Fri 9am–7pm · Sat 9am–5pm<br />Sun–Mon closed</li>
            <li className="flex gap-4"><Phone className="h-5 w-5 shrink-0 text-[#b07466]" /><a href="tel:+15550100156">(555) 010-0156</a></li>
            <li className="flex gap-4"><Mail className="h-5 w-5 shrink-0 text-[#b07466]" /><a href="mailto:hello@luxebeauty.example">hello@luxebeauty.example</a></li>
          </ul>
          <div className="mt-8 overflow-hidden rounded-t-[160px] rounded-b-2xl">
            <MapArt className="aspect-[4/3] w-full" land="#f3e9e2" water="#e0dfe6" park="#e3e3cf" road="#fffaf6" pin="#b07466" />
          </div>
        </div>
        <div id="book" className="rounded-2xl bg-white p-7 shadow-[0_30px_60px_-40px_rgba(59,42,38,.4)] sm:p-10">
          <h2 className={`${serif} text-4xl font-light`}>Request an appointment</h2>
          <p className="mt-2 text-[#8b7670]">We&apos;ll confirm your time by phone or email within one business day.</p>
          <DemoForm
            demoName={NAME}
            submitLabel="REQUEST APPOINTMENT"
            className="mt-8 grid gap-5"
            buttonClass="mt-2 rounded-full bg-[#3b2a26] py-4 text-[13px] tracking-[0.2em] text-[#faf5f1] hover:bg-[#b07466] transition"
            noticeClass="border-[#b07466]/30 bg-[#faf5f1] text-[#3b2a26]"
          >
            {[
              { l: "Name", n: "name", t: "text", ac: "name" },
              { l: "Email", n: "email", t: "email", ac: "email" },
              { l: "Phone", n: "phone", t: "tel", ac: "tel" },
            ].map((x) => (
              <label key={x.n} className="block text-[12px] tracking-[0.2em] text-[#8b7670] uppercase">
                {x.l}
                <input required name={x.n} type={x.t} autoComplete={x.ac} className="mt-2 w-full border-0 border-b border-[#3b2a26]/20 bg-transparent px-0 py-2.5 text-base tracking-normal text-[#3b2a26] normal-case outline-none focus:border-[#b07466]" />
              </label>
            ))}
            <label className="block text-[12px] tracking-[0.2em] text-[#8b7670] uppercase">
              Service
              <select required name="service" defaultValue="" className="mt-2 w-full border-0 border-b border-[#3b2a26]/20 bg-transparent px-0 py-2.5 text-base tracking-normal text-[#3b2a26] normal-case outline-none focus:border-[#b07466]">
                <option value="" disabled>Choose a service…</option>
                {tabs.map((t) => (
                  <optgroup key={t} label={t}>{menu[t].map((s) => <option key={s.n}>{s.n}</option>)}</optgroup>
                ))}
              </select>
            </label>
            <label className="block text-[12px] tracking-[0.2em] text-[#8b7670] uppercase">
              Preferred date
              <input required name="date" type="date" className="mt-2 w-full border-0 border-b border-[#3b2a26]/20 bg-transparent px-0 py-2.5 text-base tracking-normal text-[#3b2a26] outline-none focus:border-[#b07466]" />
            </label>
          </DemoForm>
        </div>
      </section>

      <footer className="border-t border-[#3b2a26]/10 py-8 text-center text-[12px] tracking-[0.2em] text-[#8b7670] uppercase">
        © Luxe Beauty Studio · Fictional demo
      </footer>
    </div>
  );
}
