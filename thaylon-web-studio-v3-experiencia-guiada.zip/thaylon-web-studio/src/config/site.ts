/**
 * ─────────────────────────────────────────────────────────────
 * CENTRAL SITE CONFIGURATION
 * Every piece of contact/brand info on the website comes from here.
 * Values are read from environment variables (see .env.example).
 * Empty values are hidden on the site — nothing is ever invented.
 * ─────────────────────────────────────────────────────────────
 */

const env = (value: string | undefined, fallback = "") =>
  (value ?? "").trim() || fallback;

export const AGENCY_NAME = env(process.env.NEXT_PUBLIC_AGENCY_NAME, "Thaylon Web Studio");
export const AGENCY_EMAIL = env(process.env.NEXT_PUBLIC_AGENCY_EMAIL);
export const AGENCY_DOMAIN = env(process.env.NEXT_PUBLIC_AGENCY_DOMAIN)
  .replace(/^https?:\/\//, "")
  .replace(/\/+$/, "");
export const PORTFOLIO_URL = env(process.env.NEXT_PUBLIC_PORTFOLIO_URL, "/portfolio");
export const INSTAGRAM_URL = env(process.env.NEXT_PUBLIC_INSTAGRAM_URL);
export const FACEBOOK_URL = env(process.env.NEXT_PUBLIC_FACEBOOK_URL);
export const LINKEDIN_URL = env(process.env.NEXT_PUBLIC_LINKEDIN_URL);

export const FOUNDER_NAME = env(process.env.NEXT_PUBLIC_FOUNDER_NAME, "Thaylon");
export const FOUNDER_ROLE = env(
  process.env.NEXT_PUBLIC_FOUNDER_ROLE,
  "Founder, Designer & Developer",
);

/**
 * Absolute site URL used for canonical links, sitemap and Open Graph.
 * Order: your custom domain → Netlify's primary site URL (the `URL` variable
 * Netlify sets automatically during builds) → Vercel → local development.
 */
export const SITE_URL = (
  AGENCY_DOMAIN
    ? `https://${AGENCY_DOMAIN}`
    : env(process.env.URL) ||
      (process.env.VERCEL_PROJECT_PRODUCTION_URL ? `https://${process.env.VERCEL_PROJECT_PRODUCTION_URL}` : "http://localhost:3000")
).replace(/\/+$/, "");

/** Host name shown in legal pages (custom domain, else the live Netlify address). Empty in local dev. */
export const SITE_HOST = SITE_URL.startsWith("http://localhost") ? "" : SITE_URL.replace(/^https?:\/\//, "");

/**
 * Netlify Forms. The form is registered at deploy time from the static file
 * public/__forms.html and submissions are POSTed to that same file.
 * Keep the name and field names in sync with that file.
 */
export const QUOTE_FORM_NAME = "thaylon-quote-request";
export const NETLIFY_FORMS_PATH = "/__forms.html";

export const TAGLINE = "Professional Websites. Fair Pricing. Built for Your Business.";

export const SITE_DESCRIPTION =
  "Thaylon Web Studio designs and builds modern, professional websites for small and local businesses across the United States — restaurants, contractors, salons, cleaning companies and more. Fair, transparent pricing.";

export const socialLinks = [
  { label: "Instagram", href: INSTAGRAM_URL, icon: "instagram" as const },
  { label: "Facebook", href: FACEBOOK_URL, icon: "facebook" as const },
  { label: "LinkedIn", href: LINKEDIN_URL, icon: "linkedin" as const },
].filter((s) => s.href);

export const mainNav = [
  { label: "Services", href: "/services" },
  { label: "Portfolio", href: PORTFOLIO_URL },
  { label: "Pricing", href: "/pricing" },
  { label: "Maintenance", href: "/maintenance" },
  { label: "About", href: "/about" },
];

export const QUOTE_PATH = "/contact";
