import { AlertTriangle } from "lucide-react";

/** Highlighted, editable placeholder for legal/business details. */
export function Ph({ children }: { children: React.ReactNode }) {
  return (
    <mark className="rounded bg-amber-100 px-1 py-0.5 font-medium text-amber-900" title="Placeholder — edit before launch">
      [{children}]
    </mark>
  );
}

export function LegalLayout({
  title,
  updated,
  children,
}: {
  title: string;
  updated: React.ReactNode;
  children: React.ReactNode;
}) {
  return (
    <>
      <section className="border-b border-line bg-paper">
        <div className="container-x py-14 sm:py-20">
          <p className="eyebrow">Legal</p>
          <h1 className="mt-4 text-[40px] leading-tight font-extrabold text-ink sm:text-5xl">{title}</h1>
          <p className="mt-4 text-muted">Last updated: {updated}</p>
        </div>
      </section>
      <div className="container-x py-14 sm:py-20">
        <div className="mx-auto max-w-3xl">
          <div className="mb-10 flex gap-3 rounded-xl border border-amber-200 bg-amber-50 p-5 text-[14.5px] leading-relaxed text-amber-900">
            <AlertTriangle className="mt-0.5 h-5 w-5 shrink-0" />
            <p>
              <strong>Template notice:</strong> this document is a general template provided for convenience. Highlighted items in brackets must be completed by the website owner. It is not legal advice and does not by itself guarantee compliance with any law — please have it reviewed by a qualified attorney for your situation.
            </p>
          </div>
          <article className="legal space-y-5 text-[16px] leading-relaxed text-ink/85 [&_h2]:mt-12 [&_h2]:font-display [&_h2]:text-2xl [&_h2]:font-extrabold [&_h2]:text-ink [&_h3]:mt-6 [&_h3]:font-bold [&_h3]:text-ink [&_li]:mt-2 [&_ul]:list-disc [&_ul]:space-y-1 [&_ul]:pl-6 [&_a]:font-semibold [&_a]:text-ink [&_a]:underline">
            {children}
          </article>
        </div>
      </div>
    </>
  );
}
