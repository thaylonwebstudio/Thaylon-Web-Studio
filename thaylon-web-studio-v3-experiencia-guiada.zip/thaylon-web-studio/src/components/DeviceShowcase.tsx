import { projects } from "@/data/portfolio";
import { MiniSite } from "./MiniSite";

const pick = (slug: string) => projects.find((p) => p.slug === slug)!;

/** Desktop + tablet + phone composition showing demo-project previews. */
export function DeviceShowcase() {
  return (
    <div className="relative mx-auto w-full max-w-[640px] pb-10 lg:max-w-none" aria-hidden="true">
      {/* Desktop */}
      <div className="relative overflow-hidden rounded-xl border border-black/10 bg-white shadow-[0_40px_80px_-40px_rgba(16,24,39,.55)]">
        <div className="flex items-center gap-1.5 border-b border-black/5 bg-[#f6f7f9] px-3 py-2">
          <span className="h-2 w-2 rounded-full bg-[#ff5f57]" />
          <span className="h-2 w-2 rounded-full bg-[#febc2e]" />
          <span className="h-2 w-2 rounded-full bg-[#28c840]" />
          <span className="ml-3 h-4 w-40 rounded bg-white" />
        </div>
        <div className="aspect-[16/10]">
          <MiniSite project={pick("bella-napoli")} />
        </div>
      </div>

      {/* Tablet */}
      <div className="absolute -bottom-2 -left-3 w-[42%] rounded-[18px] border-[6px] border-ink bg-ink shadow-[0_30px_60px_-30px_rgba(16,24,39,.7)] sm:-left-8">
        <div className="aspect-[4/3] overflow-hidden rounded-[10px]">
          <MiniSite project={pick("freshhome-cleaning")} />
        </div>
      </div>

      {/* Phone */}
      <div className="absolute right-2 -bottom-6 w-[23%] rounded-[22px] border-[5px] border-ink bg-ink shadow-[0_30px_60px_-30px_rgba(16,24,39,.7)] sm:-right-6">
        <div className="relative aspect-[9/19] overflow-hidden rounded-[16px]">
          <MiniSite project={pick("gentlemans-cut")} variant="mobile" />
          <span className="absolute top-1.5 left-1/2 h-1.5 w-8 -translate-x-1/2 rounded-full bg-ink" />
        </div>
      </div>
    </div>
  );
}
