"use client";

import Link from "next/link";
import { useRouter } from "next/navigation";
import { useEffect, useMemo, useRef, useState } from "react";
import { AlertCircle, ArrowRight, Check, CheckCircle2, Loader2 } from "lucide-react";
import { AGENCY_EMAIL, AGENCY_NAME, NETLIFY_FORMS_PATH, QUOTE_FORM_NAME } from "@/config/site";

const categories = [
  "Restaurant / Pizzeria / Café",
  "Cleaning Company",
  "Landscaping / Gardening",
  "Barbershop / Hair Salon / Beauty",
  "Roofing / Construction",
  "Plumbing / Electrical / HVAC",
  "Auto Detailing / Car Repair",
  "Retail Store",
  "Professional Services",
  "Other",
];

const projectTypes = [
  "New website",
  "Website redesign",
  "Landing page",
  "Business website",
  "E-commerce",
  "Website maintenance",
  "Other",
];

/** One-time project budget. Ranges do not overlap; hints match the packages on /pricing. */
const budgets: { value: string; hint?: string }[] = [
  { value: "Under $400", hint: "Starter · $299" },
  { value: "$400–$599", hint: "Professional · $499" },
  { value: "$600–$999", hint: "Business · $699" },
  { value: "$1,000 or more", hint: "Custom project" },
  { value: "Not sure yet", hint: "We'll help you decide" },
];

/** Maps ?package= / ?project= URL params to sensible defaults. */
const packagePresets: Record<string, { project?: string; budget?: string; note?: string }> = {
  starter: { project: "New website", budget: "Under $400", note: "Interested in the Starter Website package ($299)." },
  professional: { project: "Business website", budget: "$400–$599", note: "Interested in the Professional Website package ($499)." },
  business: { project: "Business website", budget: "$600–$999", note: "Interested in the Business Website package ($699)." },
  custom: { budget: "$1,000 or more", note: "I'd like a custom quote." },
  "basic-care": { project: "Website maintenance", note: "Interested in the Basic Care maintenance plan ($29/month)." },
  "standard-care": { project: "Website maintenance", note: "Interested in the Standard Care maintenance plan ($59/month)." },
  "premium-care": { project: "Website maintenance", note: "Interested in the Premium Care maintenance plan ($99/month)." },
  maintenance: { project: "Website maintenance" },
};

type Values = {
  name: string;
  email: string;
  business: string;
  website: string;
  category: string;
  project: string;
  budget: string;
  description: string;
  consent: boolean;
  "bot-field": string; // Netlify honeypot
};

/** Field order here = order errors are focused in. Matches the visual order. */
const empty: Values = {
  name: "", email: "", business: "", website: "", category: "", project: "", budget: "", description: "", consent: false, "bot-field": "",
};

type Key = keyof Values;
type Errors = Partial<Record<Key, string>>;

function validate(v: Values): Errors {
  const e: Errors = {};
  if (v.name.trim().length < 2) e.name = "Please enter your full name.";
  if (!/^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(v.email.trim())) e.email = "Please enter a valid email address, like you@example.com.";
  if (v.business.trim().length < 2) e.business = "Please enter your business name.";
  if (v.website.trim() && !/^(https?:\/\/)?([\w-]+\.)+[\w-]{2,}(\/\S*)?$/i.test(v.website.trim()))
    e.website = "Please enter a valid web address (e.g. yourbusiness.com), or leave it empty.";
  if (!v.category) e.category = "Please choose the option closest to your business.";
  if (!v.project) e.project = "Please choose a project type.";
  if (!v.budget) e.budget = "Please choose a budget range. “Not sure yet” is fine.";
  if (v.description.trim().length < 20) e.description = "Please share a few details (at least 20 characters).";
  if (!v.consent) e.consent = "Please check this box so we can reply to your request.";
  return e;
}

type Status = "idle" | "submitting" | "success" | "error";

const selectArrow =
  "appearance-none bg-[url('data:image/svg+xml;utf8,<svg xmlns=%22http://www.w3.org/2000/svg%22 width=%2212%22 height=%2212%22 viewBox=%220 0 24 24%22 fill=%22none%22 stroke=%22%235F6673%22 stroke-width=%222.5%22><path d=%22m6 9 6 6 6-6%22/></svg>')] bg-[position:right_14px_center] bg-no-repeat pr-10";

export function QuoteForm() {
  const router = useRouter();
  const [values, setValues] = useState<Values>(empty);
  const [touched, setTouched] = useState<Partial<Record<Key, boolean>>>({});
  const [submitted, setSubmitted] = useState(false);
  const [status, setStatus] = useState<Status>("idle");
  const inFlight = useRef(false);
  const statusRef = useRef<HTMLDivElement>(null);
  const formRef = useRef<HTMLFormElement>(null);

  /*
   * Errors are always derived from the CURRENT values (never stored).
   * This fixes the old bug where a budget option or the privacy checkbox was
   * selected but a stale "please choose…" error stayed visible until the
   * visitor clicked a second time.
   */
  const errors = useMemo(() => validate(values), [values]);
  const showError = (k: Key) => (touched[k] || submitted ? errors[k] : undefined);

  // Prefill from ?package= / ?project= / ?demo= (pricing and demo CTAs)
  useEffect(() => {
    const params = new URLSearchParams(window.location.search);
    const key = params.get("package") || params.get("project") || "";
    const demo = params.get("demo");
    const preset = packagePresets[key];
    setValues((v) => ({
      ...v,
      project: preset?.project ?? v.project,
      budget: preset?.budget ?? v.budget,
      description:
        v.description ||
        [preset?.note, demo ? `I'd like a website similar to the "${demo}" demo.` : ""].filter(Boolean).join(" "),
    }));
  }, []);

  /** Update a value. `markTouched` is used for choices (radio/checkbox/select) that are complete on change. */
  const update = <K extends Key>(key: K, val: Values[K], markTouched = false) => {
    setValues((v) => ({ ...v, [key]: val }));
    if (markTouched) setTouched((t) => (t[key] ? t : { ...t, [key]: true }));
  };
  const blur = (key: Key) => setTouched((t) => (t[key] ? t : { ...t, [key]: true }));

  async function onSubmit(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault();
    if (inFlight.current) return; // no duplicate submissions
    setSubmitted(true);
    const errs = validate(values);
    const first = (Object.keys(empty) as Key[]).find((k) => errs[k]);
    if (first) {
      formRef.current?.querySelector<HTMLElement>(`[name="${first}"]`)?.focus();
      return;
    }
    if (values["bot-field"]) {
      setStatus("success"); // honeypot filled: silently drop bots
      return;
    }

    inFlight.current = true;
    setStatus("submitting");
    try {
      // Netlify Forms: URL-encoded POST to the static form definition file (public/__forms.html).
      const body = new URLSearchParams({
        "form-name": QUOTE_FORM_NAME,
        subject: `New quote request — ${values.business.trim()}`,
        "bot-field": "",
        name: values.name.trim(),
        business: values.business.trim(),
        email: values.email.trim(),
        website: values.website.trim(),
        category: values.category,
        project: values.project,
        budget: values.budget,
        description: values.description.trim(),
        consent: "yes",
      });
      const res = await fetch(NETLIFY_FORMS_PATH, {
        method: "POST",
        headers: { "Content-Type": "application/x-www-form-urlencoded" },
        body: body.toString(),
      });
      if (!res.ok) throw new Error(`HTTP ${res.status}`);
      // Only now — after Netlify confirmed — show the confirmation.
      setStatus("success");
      setValues(empty);
      setTouched({});
      setSubmitted(false);
      router.push("/thank-you");
    } catch {
      setStatus("error");
      requestAnimationFrame(() => statusRef.current?.focus());
    } finally {
      inFlight.current = false;
    }
  }

  // Inline confirmation: fallback in case the redirect to /thank-you doesn't happen.
  if (status === "success") {
    return (
      <div ref={statusRef} tabIndex={-1} role="status" className="rounded-2xl border border-line bg-white p-8 text-center outline-none sm:p-12">
        <CheckCircle2 className="mx-auto h-12 w-12 text-emerald-600" />
        <h2 className="mt-5 text-2xl font-extrabold text-ink">Thank you — your request was sent.</h2>
        <p className="mx-auto mt-3 max-w-md text-muted">
          We&apos;ve received your project details and will reply by email, usually within 1–2 business days.
        </p>
        <div className="mt-8 flex flex-col justify-center gap-3 sm:flex-row">
          <Link href="/portfolio" className="btn-dark">Explore our work</Link>
          <button type="button" onClick={() => setStatus("idle")} className="btn-ghost">Send another request</button>
        </div>
      </div>
    );
  }

  const label = "mb-1.5 block text-[14.5px] font-semibold text-ink";
  const req = <span className="text-accent" aria-hidden="true"> *</span>;
  const err = (k: Key) =>
    showError(k) ? (
      <p id={`${k}-error`} className="mt-1.5 flex items-start gap-1.5 text-[13.5px] font-medium text-accent-dark">
        <AlertCircle className="mt-0.5 h-3.5 w-3.5 shrink-0" aria-hidden="true" /> {showError(k)}
      </p>
    ) : null;
  const aria = (k: Key, hint?: string) => {
    const ids = [hint, showError(k) ? `${k}-error` : ""].filter(Boolean).join(" ");
    return { "aria-invalid": showError(k) ? true : undefined, "aria-describedby": ids || undefined };
  };
  const group = "rounded-xl border border-line bg-paper/50 p-4 sm:p-6";
  const legend = "flex items-center gap-3 font-display text-[16px] font-bold text-ink";
  const stepDot = "flex h-7 w-7 shrink-0 items-center justify-center rounded-full bg-ink text-[13px] font-bold text-white";
  const why = "mt-1 mb-5 pl-10 text-[13.5px] leading-relaxed text-muted";
  const submitting = status === "submitting";

  return (
    <form
      ref={formRef}
      name={QUOTE_FORM_NAME}
      method="POST"
      action={NETLIFY_FORMS_PATH}
      onSubmit={onSubmit}
      noValidate
      aria-busy={submitting}
      className="rounded-2xl border border-line bg-white p-4 shadow-[0_30px_60px_-40px_rgba(16,24,39,.35)] sm:p-8"
      aria-label="Quote request form"
    >
      <input type="hidden" name="form-name" value={QUOTE_FORM_NAME} />

      <div className="mb-6 flex flex-wrap items-center justify-between gap-2 px-1">
        <p className="font-display text-lg font-extrabold text-ink">Tell us about your project</p>
        <p className="text-[13px] text-muted">About 3 minutes · <span className="text-accent">*</span> required</p>
      </div>

      {status === "error" && (
        <div ref={statusRef} tabIndex={-1} role="alert" className="mb-6 rounded-xl border border-accent/30 bg-accent/[0.05] p-4 text-[14.5px] leading-relaxed text-ink outline-none">
          <p className="flex items-center gap-2 font-semibold">
            <AlertCircle className="h-4 w-4 shrink-0 text-accent" aria-hidden="true" />
            Your request could not be sent.
          </p>
          <p className="mt-1 text-ink/75">
            Don&apos;t worry, everything you typed is still here. Please check your connection and try again in a moment
            {AGENCY_EMAIL ? (
              <>
                {" "}or email us at{" "}
                <a className="font-semibold underline" href={`mailto:${AGENCY_EMAIL}?subject=${encodeURIComponent("Quote request — " + (values.business || "my business"))}&body=${encodeURIComponent(values.description)}`}>
                  {AGENCY_EMAIL}
                </a>
              </>
            ) : null}
            .
          </p>
        </div>
      )}

      <div className="space-y-4">
        {/* 1 — About you */}
        <fieldset className={group}>
          <legend className="sr-only">About you</legend>
          <p className={legend} aria-hidden="true"><span className={stepDot}>1</span>About you</p>
          <p className={why}>So we know who we&apos;re talking to and where to send your estimate.</p>
          <div className="grid gap-4 sm:grid-cols-2">
            <div>
              <label htmlFor="name" className={label}>Full name{req}</label>
              <input id="name" name="name" autoComplete="name" required className="field" value={values.name} onChange={(e) => update("name", e.target.value)} onBlur={() => blur("name")} {...aria("name")} />
              {err("name")}
            </div>
            <div>
              <label htmlFor="email" className={label}>Email address{req}</label>
              <input id="email" name="email" type="email" autoComplete="email" inputMode="email" required className="field" value={values.email} onChange={(e) => update("email", e.target.value)} onBlur={() => blur("email")} {...aria("email")} />
              {err("email")}
            </div>
          </div>
        </fieldset>

        {/* 2 — Your business */}
        <fieldset className={group}>
          <legend className="sr-only">Your business</legend>
          <p className={legend} aria-hidden="true"><span className={stepDot}>2</span>Your business</p>
          <p className={why}>Helps us understand your customers and suggest what works for your industry.</p>
          <div className="grid gap-4 sm:grid-cols-2">
            <div>
              <label htmlFor="business" className={label}>Business name{req}</label>
              <input id="business" name="business" autoComplete="organization" required className="field" value={values.business} onChange={(e) => update("business", e.target.value)} onBlur={() => blur("business")} {...aria("business")} />
              {err("business")}
            </div>
            <div>
              <label htmlFor="category" className={label}>Type of business{req}</label>
              <select id="category" name="category" required className={`field ${selectArrow}`} value={values.category} onChange={(e) => update("category", e.target.value, true)} onBlur={() => blur("category")} {...aria("category")}>
                <option value="">Select a category…</option>
                {categories.map((c) => <option key={c}>{c}</option>)}
              </select>
              {err("category")}
            </div>
            <div className="sm:col-span-2">
              <label htmlFor="website" className={label}>Current website <span className="font-normal text-muted">(optional)</span></label>
              <input id="website" name="website" type="url" inputMode="url" autoComplete="url" placeholder="yourbusiness.com" className="field" value={values.website} onChange={(e) => update("website", e.target.value)} onBlur={() => blur("website")} {...aria("website", "website-hint")} />
              <p id="website-hint" className="mt-1.5 text-[13px] text-muted">No website yet? No problem, just leave this empty.</p>
              {err("website")}
            </div>
          </div>
        </fieldset>

        {/* 3 — Your project */}
        <fieldset className={group}>
          <legend className="sr-only">Your project</legend>
          <p className={legend} aria-hidden="true"><span className={stepDot}>3</span>Your project</p>
          <p className={why}>A rough idea is enough. We&apos;ll refine the details together before any work starts.</p>
          <div className="space-y-5">
            <div>
              <label htmlFor="project" className={label}>What do you need?{req}</label>
              <select id="project" name="project" required className={`field ${selectArrow}`} value={values.project} onChange={(e) => update("project", e.target.value, true)} onBlur={() => blur("project")} {...aria("project")}>
                <option value="">Select a project type…</option>
                {projectTypes.map((c) => <option key={c}>{c}</option>)}
              </select>
              {err("project")}
            </div>

            <div
              role="radiogroup"
              aria-labelledby="budget-label"
              aria-required="true"
              aria-invalid={showError("budget") ? true : undefined}
              aria-describedby={["budget-hint", showError("budget") ? "budget-error" : ""].filter(Boolean).join(" ")}
            >
              <p id="budget-label" className={label}>Estimated budget{req}</p>
              <div className="grid grid-cols-1 gap-2 min-[420px]:grid-cols-2 lg:grid-cols-3">
                {budgets.map(({ value: b, hint }) => {
                  const selected = values.budget === b;
                  const id = `budget-${b.replace(/[^a-z0-9]+/gi, "-").toLowerCase()}`;
                  return (
                    <label
                      key={b}
                      htmlFor={id}
                      className={`relative flex min-h-[56px] cursor-pointer touch-manipulation flex-col justify-center rounded-lg border py-2.5 pr-9 pl-4 transition-colors has-[:focus-visible]:ring-2 has-[:focus-visible]:ring-accent has-[:focus-visible]:ring-offset-2 ${selected ? "border-ink bg-ink text-white" : "border-line bg-white text-ink hover:border-ink/30"}`}
                    >
                      <input
                        id={id}
                        type="radio"
                        name="budget"
                        value={b}
                        checked={selected}
                        onChange={() => update("budget", b, true)}
                        className="sr-only"
                      />
                      <span className="text-[14.5px] font-semibold">{b}</span>
                      {hint && <span className={`text-[12.5px] ${selected ? "text-white/70" : "text-muted"}`}>{hint}</span>}
                      <span className={`absolute top-1/2 right-3 flex h-5 w-5 -translate-y-1/2 items-center justify-center rounded-full border ${selected ? "border-white bg-white text-ink" : "border-line"}`} aria-hidden="true">
                        {selected && <Check className="h-3 w-3" strokeWidth={3} />}
                      </span>
                    </label>
                  );
                })}
              </div>
              <p id="budget-hint" className="mt-2 text-[13px] text-muted">One-time project cost. Monthly maintenance is optional and separate.</p>
              {err("budget")}
            </div>

            <div>
              <label htmlFor="description" className={label}>Tell us a little about it{req}</label>
              <textarea id="description" name="description" rows={5} required className="field resize-y" placeholder="What does your business do? What would you like your website to do? Pages you need, sites you like, any deadline…" value={values.description} onChange={(e) => update("description", e.target.value)} onBlur={() => blur("description")} {...aria("description")} />
              {err("description")}
            </div>
          </div>
        </fieldset>
      </div>

      {/* Netlify honeypot: hidden from people (display: none), left for bots to fill. */}
      <p className="hidden" aria-hidden="true">
        <label>
          Don&apos;t fill this out if you&apos;re human:
          <input name="bot-field" tabIndex={-1} autoComplete="off" value={values["bot-field"]} onChange={(e) => update("bot-field", e.target.value)} />
        </label>
      </p>

      <div className="mt-6 px-1">
        <div className="flex items-start gap-3">
          <input
            id="consent"
            type="checkbox"
            name="consent"
            value="yes"
            required
            checked={values.consent}
            onChange={(e) => update("consent", e.target.checked, true)}
            className="mt-0.5 h-5 w-5 shrink-0 cursor-pointer touch-manipulation accent-[#D63A3A]"
            {...aria("consent")}
          />
          <div className="text-[14.5px] leading-relaxed text-ink/80">
            <label htmlFor="consent" className="cursor-pointer">
              I agree that {AGENCY_NAME} may use the information I provide to respond to my request.{req}
            </label>{" "}
            See our{" "}
            <Link href="/privacy" className="font-semibold text-ink underline underline-offset-2" target="_blank" rel="noopener">
              Privacy Policy<span className="sr-only"> (opens in a new tab)</span>
            </Link>
            .
          </div>
        </div>
        {err("consent")}
      </div>

      <div className="mt-6 flex flex-col-reverse items-stretch gap-4 border-t border-line px-1 pt-6 sm:flex-row sm:items-center sm:justify-between">
        <p className="text-center text-[13px] text-muted sm:text-left">Free and no obligation. We never sell your details.</p>
        <button type="submit" disabled={submitting} className="btn-primary w-full !px-7 !py-4 disabled:cursor-wait disabled:opacity-80 sm:w-auto">
          {submitting ? (<><Loader2 className="h-4 w-4 animate-spin" aria-hidden="true" /> Sending…</>) : (<>Get Your Free Estimate <ArrowRight className="h-4 w-4" aria-hidden="true" /></>)}
        </button>
      </div>
      <p className="sr-only" aria-live="polite">{submitting ? "Sending your request…" : ""}</p>
    </form>
  );
}
