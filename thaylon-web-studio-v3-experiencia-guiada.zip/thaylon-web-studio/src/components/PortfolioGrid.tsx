"use client";

import { useMemo, useState } from "react";
import { projects } from "@/data/portfolio";
import { PortfolioCard } from "./ui";

const filters = [
  { label: "All", match: () => true },
  { label: "Food & Retail", match: (c: string) => ["Restaurant", "Retail Store"].includes(c) },
  { label: "Home Services", match: (c: string) => ["Cleaning Company", "Landscaping", "Roofing Company", "Plumbing Company"].includes(c) },
  { label: "Beauty & Grooming", match: (c: string) => ["Barbershop", "Beauty Salon"].includes(c) },
  { label: "Automotive", match: (c: string) => c === "Auto Detailing" },
];

export function PortfolioGrid() {
  const [active, setActive] = useState(0);
  const list = useMemo(() => projects.filter((p) => filters[active].match(p.category)), [active]);

  return (
    <>
      <div role="group" aria-label="Filter projects by industry" className="-mx-5 flex gap-2 overflow-x-auto px-5 pb-1 no-scrollbar sm:mx-0 sm:flex-wrap sm:px-0">
        {filters.map((f, i) => (
          <button
            key={f.label}
            type="button"
            aria-pressed={active === i}
            onClick={() => setActive(i)}
            className={`min-h-11 shrink-0 rounded-full border px-4 py-2 text-sm font-medium transition ${
              active === i ? "border-ink bg-ink text-white" : "border-line bg-white text-ink/75 hover:border-ink/30"
            }`}
          >
            {f.label}
            <span className={`ml-2 text-xs ${active === i ? "text-white/75" : "text-muted"}`}>
              {projects.filter((p) => f.match(p.category)).length}
            </span>
          </button>
        ))}
      </div>
      <p className="mt-6 text-[14px] text-muted" aria-live="polite">Showing {list.length} of {projects.length} demo projects</p>
      <div className="mt-4 grid gap-6 md:grid-cols-2 lg:grid-cols-3">
        {list.map((p) => (
          <PortfolioCard key={p.slug} project={p} detailed />
        ))}
      </div>
    </>
  );
}
