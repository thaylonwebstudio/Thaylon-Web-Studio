import type { Project } from "@/data/portfolio";
import { artBySlug } from "./art/Art";

/**
 * A scaled-down, live-rendered preview of a demo site's hero.
 * Uses container-query units so it scales to any card / device size.
 */
export function MiniSite({ project, variant = "desktop" }: { project: Project; variant?: "desktop" | "mobile" }) {
  const t = project.theme;
  const Art = artBySlug[project.slug as keyof typeof artBySlug];
  const mobile = variant === "mobile";

  return (
    <div className="@container relative h-full w-full overflow-hidden" style={{ background: t.bg, color: t.fg }} aria-hidden="true">
      {/* nav */}
      <div className="flex items-center justify-between" style={{ padding: mobile ? "5cqw 6cqw" : "2.6cqw 4cqw" }}>
        <span style={{ fontFamily: t.fontVar, fontWeight: 700, fontSize: mobile ? "6cqw" : "2.4cqw", letterSpacing: "-0.01em" }}>
          {project.name}
        </span>
        {mobile ? (
          <span className="flex flex-col" style={{ gap: "1.2cqw" }}>
            {[0, 1, 2].map((i) => (
              <span key={i} style={{ width: "6cqw", height: "0.9cqw", background: t.fg, borderRadius: 9 }} />
            ))}
          </span>
        ) : (
          <span className="flex items-center" style={{ gap: "2.4cqw", fontSize: "1.35cqw", color: t.muted }}>
            {t.nav.map((n) => <span key={n}>{n}</span>)}
            <span style={{ background: t.accent, color: "#fff", padding: "0.8cqw 1.6cqw", borderRadius: "0.6cqw", fontWeight: 600 }}>
              {t.cta}
            </span>
          </span>
        )}
      </div>

      {/* hero */}
      <div
        className={mobile ? "flex flex-col" : "grid items-center"}
        style={mobile ? { padding: "4cqw 6cqw", gap: "6cqw" } : { gridTemplateColumns: "1.1fr 1fr", padding: "3cqw 4cqw", gap: "3cqw" }}
      >
        <div>
          <span style={{ display: "inline-block", fontSize: mobile ? "3cqw" : "1.1cqw", letterSpacing: "0.2em", textTransform: "uppercase", color: t.accent, fontWeight: 700 }}>
            {project.category}
          </span>
          <div
            style={{
              fontFamily: t.fontVar,
              fontSize: mobile ? "11cqw" : "5cqw",
              lineHeight: 1.02,
              fontWeight: 700,
              marginTop: mobile ? "3cqw" : "1.2cqw",
              letterSpacing: "-0.01em",
            }}
          >
            {t.headline}
          </div>
          <div style={{ marginTop: mobile ? "4cqw" : "1.8cqw", display: "flex", flexDirection: "column", gap: mobile ? "1.8cqw" : "0.8cqw" }}>
            <span style={{ height: mobile ? "1.6cqw" : "0.7cqw", width: "88%", background: t.muted, opacity: 0.35, borderRadius: 9 }} />
            <span style={{ height: mobile ? "1.6cqw" : "0.7cqw", width: "64%", background: t.muted, opacity: 0.35, borderRadius: 9 }} />
          </div>
          <div className="flex" style={{ gap: mobile ? "2.5cqw" : "1cqw", marginTop: mobile ? "5cqw" : "2.4cqw" }}>
            <span style={{ background: t.accent, color: "#fff", fontSize: mobile ? "3.4cqw" : "1.3cqw", fontWeight: 600, padding: mobile ? "2.4cqw 4cqw" : "1cqw 2cqw", borderRadius: mobile ? "1.6cqw" : "0.6cqw" }}>
              {t.cta}
            </span>
            {!mobile && (
              <span style={{ border: `1px solid ${t.muted}55`, fontSize: "1.3cqw", padding: "1cqw 2cqw", borderRadius: "0.6cqw", color: t.fg }}>
                Learn more
              </span>
            )}
          </div>
        </div>
        <div className="relative flex items-center justify-center">
          <Art className="h-auto w-full max-w-full" title="" />
        </div>
      </div>

      {/* hint of next section */}
      {!mobile && (
        <div className="grid grid-cols-3" style={{ gap: "1.6cqw", padding: "2cqw 4cqw" }}>
          {[0, 1, 2].map((i) => (
            <div key={i} style={{ height: "9cqw", borderRadius: "0.8cqw", background: t.fg, opacity: 0.06 }} />
          ))}
        </div>
      )}
    </div>
  );
}
