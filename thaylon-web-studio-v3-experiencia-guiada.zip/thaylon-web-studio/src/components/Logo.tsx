import Link from "next/link";
import { AGENCY_NAME } from "@/config/site";

export function LogoMark({ className = "h-8 w-8", dark = false }: { className?: string; dark?: boolean }) {
  return (
    <svg viewBox="0 0 32 32" className={className} aria-hidden="true">
      <rect width="32" height="32" rx="8" fill={dark ? "#1d2230" : "#111318"} stroke={dark ? "rgba(255,255,255,.12)" : "none"} />
      <path d="M8 10.5h11" stroke="#fff" strokeWidth="2.6" strokeLinecap="round" />
      <path d="M13.5 10.5V23" stroke="#fff" strokeWidth="2.6" strokeLinecap="round" />
      <circle cx="22.5" cy="21.5" r="2.6" fill="#E44848" />
    </svg>
  );
}

export function Logo({ dark = false }: { dark?: boolean }) {
  const [first, ...rest] = AGENCY_NAME.split(" ");
  return (
    <Link
      href="/"
      className="group inline-flex items-center gap-2.5"
      aria-label={`${AGENCY_NAME} — home`}
    >
      <LogoMark dark={dark} className="h-8 w-8 transition-transform duration-300 group-hover:-rotate-6" />
      <span className={`font-display text-[17px] font-extrabold tracking-tight ${dark ? "text-white" : "text-ink"}`}>
        {first}
        <span className={dark ? "font-semibold text-white/70" : "font-semibold text-muted"}>
          {rest.length ? ` ${rest.join(" ")}` : ""}
        </span>
      </span>
    </Link>
  );
}
