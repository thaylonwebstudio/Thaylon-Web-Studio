"use client";

import Link from "next/link";
import { useCallback, useEffect, useRef, useState } from "react";
import { ArrowLeft, ArrowRight, Check, Compass, MessageCircle, RotateCcw, X } from "lucide-react";
import { LogoMark } from "./Logo";
import { projects } from "@/data/portfolio";
import { processSteps } from "@/data/content";
import { PORTFOLIO_URL, QUOTE_PATH } from "@/config/site";

/**
 * Welcome tour — an inline, 4-step introduction on the home page.
 * Not a modal: it never blocks the page, can be skipped, and remembers
 * (per browser) that the visitor skipped or finished it, so it shows as a
 * small "Take the tour" bar on later visits. Reopens from #welcome links.
 */

const STORAGE_KEY = "tws-welcome-tour";

const steps = [
  { id: "meet", label: "Meet the studio" },
  { id: "create", label: "What we create" },
  { id: "how", label: "How it works" },
  { id: "talk", label: "Let's talk" },
] as const;

function readDone() {
  try {
    return window.localStorage.getItem(STORAGE_KEY) === "done";
  } catch {
    return false;
  }
}
function writeDone(done: boolean) {
  try {
    if (done) window.localStorage.setItem(STORAGE_KEY, "done");
    else window.localStorage.removeItem(STORAGE_KEY);
  } catch {
    /* storage unavailable: the tour simply shows again next time */
  }
}

export function WelcomeTour() {
  const [step, setStep] = useState(0);
  const [collapsed, setCollapsed] = useState(false);
  const panelRef = useRef<HTMLDivElement>(null);
  const tabsRef = useRef<(HTMLButtonElement | null)[]>([]);
  const sectionRef = useRef<HTMLElement>(null);

  // Returning visitors who skipped or finished see the compact bar.
  useEffect(() => {
    if (readDone() && window.location.hash !== "#welcome") setCollapsed(true);
  }, []);

  // "Explore What We Do" (href="#welcome") always opens the tour at step 1.
  useEffect(() => {
    const onHash = () => {
      if (window.location.hash === "#welcome") {
        setCollapsed(false);
        setStep(0);
      }
    };
    // Clicks on any #welcome link (works even if the hash is already #welcome).
    const onClick = (e: MouseEvent) => {
      const a = (e.target as Element | null)?.closest?.('a[href$="#welcome"]');
      if (a) {
        setCollapsed(false);
        setStep(0);
      }
    };
    window.addEventListener("hashchange", onHash);
    document.addEventListener("click", onClick);
    return () => {
      window.removeEventListener("hashchange", onHash);
      document.removeEventListener("click", onClick);
    };
  }, []);

  const go = useCallback((i: number, focusPanel = true) => {
    const next = Math.max(0, Math.min(steps.length - 1, i));
    setStep(next);
    if (focusPanel) requestAnimationFrame(() => panelRef.current?.focus({ preventScroll: true }));
  }, []);

  const skip = () => {
    writeDone(true);
    setCollapsed(true);
    requestAnimationFrame(() => document.getElementById("after-welcome")?.scrollIntoView({ behavior: "smooth", block: "start" }));
  };
  const finish = () => writeDone(true);
  const restart = () => {
    writeDone(false);
    setCollapsed(false);
    setStep(0);
    requestAnimationFrame(() => tabsRef.current[0]?.focus());
  };

  const onTabKey = (e: React.KeyboardEvent, i: number) => {
    const map: Record<string, number> = { ArrowRight: i + 1, ArrowDown: i + 1, ArrowLeft: i - 1, ArrowUp: i - 1, Home: 0, End: steps.length - 1 };
    if (!(e.key in map)) return;
    e.preventDefault();
    const n = (map[e.key] + steps.length) % steps.length;
    setStep(n);
    tabsRef.current[n]?.focus();
  };

  if (collapsed) {
    return (
      <section id="welcome" ref={sectionRef} aria-label="Welcome tour" className="border-b border-line bg-white">
        <div className="container-x flex flex-col items-start justify-between gap-3 py-5 sm:flex-row sm:items-center">
          <p className="flex items-center gap-3 text-[15px] text-ink/80">
            <Compass className="h-5 w-5 shrink-0 text-accent" aria-hidden="true" />
            New here? A 1-minute tour shows who we are, what we build and how it works.
          </p>
          <button type="button" onClick={restart} className="btn-ghost !py-2.5 !text-[14px]">
            <RotateCcw className="h-4 w-4" aria-hidden="true" /> Take the tour
          </button>
        </div>
      </section>
    );
  }

  const progress = ((step + 1) / steps.length) * 100;
  const isLast = step === steps.length - 1;

  return (
    <section id="welcome" ref={sectionRef} aria-labelledby="welcome-title" className="relative border-b border-line bg-white py-16 sm:py-24">
      <div className="container-x">
        <div className="flex flex-col justify-between gap-5 sm:flex-row sm:items-end">
          <div className="max-w-2xl">
            <p className="eyebrow">A quick welcome</p>
            <h2 id="welcome-title" className="mt-4 text-[30px] leading-[1.1] font-extrabold text-ink sm:text-[40px]">
              Nice to meet you. Here&apos;s what we do, in four short steps.
            </h2>
          </div>
          <button type="button" onClick={skip} className="inline-flex min-h-11 shrink-0 items-center gap-1.5 self-start rounded-lg px-2 text-[14.5px] font-semibold text-muted transition-colors hover:text-ink sm:self-auto">
            Skip the tour <X className="h-4 w-4" aria-hidden="true" />
          </button>
        </div>

        <div className="mt-10 overflow-hidden rounded-2xl border border-line bg-paper/60 shadow-[0_30px_60px_-45px_rgba(16,24,39,.4)]">
          {/* Progress */}
          <div className="h-1 bg-line" aria-hidden="true">
            <div className="h-full bg-accent transition-[width] duration-500 ease-out" style={{ width: `${progress}%` }} />
          </div>

          <div className="grid lg:grid-cols-[260px_1fr]">
            {/* Step list (tabs) */}
            <div role="tablist" aria-label="Tour steps" aria-orientation="vertical" className="flex gap-1 overflow-x-auto border-b border-line p-2 no-scrollbar lg:flex-col lg:border-r lg:border-b-0 lg:p-4">
              {steps.map((s, i) => {
                const active = i === step;
                const done = i < step;
                return (
                  <button
                    key={s.id}
                    ref={(el) => { tabsRef.current[i] = el; }}
                    id={`tour-tab-${s.id}`}
                    role="tab"
                    type="button"
                    aria-selected={active}
                    aria-controls="tour-panel"
                    tabIndex={active ? 0 : -1}
                    onClick={() => go(i, false)}
                    onKeyDown={(e) => onTabKey(e, i)}
                    className={`flex min-h-11 shrink-0 items-center gap-3 rounded-lg px-3 py-2 text-left text-[14px] font-semibold transition-colors lg:w-full ${active ? "bg-white text-ink shadow-sm" : "text-muted hover:bg-white/60 hover:text-ink"}`}
                  >
                    <span className={`flex h-7 w-7 shrink-0 items-center justify-center rounded-full text-[12.5px] font-bold transition-colors ${active ? "bg-accent text-white" : done ? "bg-ink text-white" : "border border-line bg-white text-muted"}`}>
                      {done ? <Check className="h-3.5 w-3.5" strokeWidth={3} aria-hidden="true" /> : i + 1}
                    </span>
                    <span className="whitespace-nowrap">{s.label}</span>
                  </button>
                );
              })}
            </div>

            {/* Panel */}
            <div className="flex min-h-[420px] flex-col p-5 sm:p-8 lg:p-10">
              <p className="text-[13px] font-semibold text-muted" aria-live="polite">
                Step {step + 1} of {steps.length}
                <span className="sr-only">: {steps[step].label}</span>
              </p>
              <div
                key={step}
                ref={panelRef}
                id="tour-panel"
                role="tabpanel"
                aria-labelledby={`tour-tab-${steps[step].id}`}
                tabIndex={-1}
                className="animate-fade-in mt-3 flex-1 outline-none"
              >
                {step === 0 && <StepMeet />}
                {step === 1 && <StepCreate />}
                {step === 2 && <StepHow />}
                {step === 3 && <StepTalk onFinish={finish} />}
              </div>

              {/* Controls */}
              <div className="mt-8 flex items-center justify-between gap-3 border-t border-line pt-5">
                <button type="button" onClick={() => go(step - 1)} disabled={step === 0} className="btn-ghost !px-4 disabled:pointer-events-none disabled:opacity-40">
                  <ArrowLeft className="h-4 w-4" aria-hidden="true" /> Back
                </button>
                <div className="hidden items-center gap-1.5 sm:flex" aria-hidden="true">
                  {steps.map((s, i) => (
                    <span key={s.id} className={`h-1.5 rounded-full transition-all duration-300 ${i === step ? "w-6 bg-accent" : "w-1.5 bg-ink/20"}`} />
                  ))}
                </div>
                {isLast ? (
                  <button type="button" onClick={() => { finish(); go(0); }} className="btn-ghost !px-4">
                    <RotateCcw className="h-4 w-4" aria-hidden="true" /> Start over
                  </button>
                ) : (
                  <button type="button" onClick={() => go(step + 1)} className="btn-dark !px-5">
                    Next <span className="sr-only">: {steps[step + 1].label}</span> <ArrowRight className="h-4 w-4" aria-hidden="true" />
                  </button>
                )}
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}

const lead = "font-display text-[22px] leading-snug font-bold text-ink sm:text-[26px]";
const body = "mt-4 max-w-2xl text-[16.5px] leading-relaxed text-ink/75";

function StepMeet() {
  return (
    <div className="grid items-center gap-8 md:grid-cols-[1fr_auto]">
      <div>
        <h3 className={lead}>First, let&apos;s get to know each other.</h3>
        <p className={body}>
          We help small businesses build a stronger, more professional presence online. Thaylon Web Studio is an independent studio, so you work directly with the person who designs and builds your website.
        </p>
        <ul className="mt-6 grid gap-3 sm:grid-cols-2">
          {[
            "Websites for small and local U.S. businesses",
            "Clear packages from $299, no hidden fees",
            "Plain-English communication, no jargon",
            "You own your website once it's paid",
          ].map((t) => (
            <li key={t} className="flex items-start gap-2.5 text-[15px] text-ink/80">
              <Check className="mt-0.5 h-[18px] w-[18px] shrink-0 text-accent" aria-hidden="true" /> {t}
            </li>
          ))}
        </ul>
      </div>
      <div className="hidden md:block" aria-hidden="true">
        <div className="relative flex h-44 w-44 items-center justify-center rounded-3xl bg-navy">
          <div className="grid-bg-dark absolute inset-0 rounded-3xl" />
          <LogoMark dark className="relative h-20 w-20" />
        </div>
      </div>
    </div>
  );
}

function StepCreate() {
  return (
    <div>
      <h3 className={lead}>Discover what we can create.</h3>
      <p className={body}>
        Whether you run a restaurant, a barbershop, a cleaning company, or another local business, we&apos;ll shape your website around what makes your business unique. Take a look at our demo projects:
      </p>
      <ul className="mt-6 grid gap-2 min-[480px]:grid-cols-2 xl:grid-cols-3">
        {projects.map((p) => (
          <li key={p.slug}>
            <Link href={`/portfolio/${p.slug}`} className="group flex min-h-12 items-center gap-3 rounded-lg border border-line bg-white px-3 py-2 transition hover:-translate-y-px hover:border-ink/25">
              <span className="h-8 w-8 shrink-0 rounded-md border border-black/10" style={{ background: `linear-gradient(135deg, ${p.theme.swatches[0]} 50%, ${p.theme.accent} 50%)` }} aria-hidden="true" />
              <span className="min-w-0">
                <span className="block truncate text-[14.5px] font-semibold text-ink group-hover:text-accent-dark">{p.name}</span>
                <span className="block truncate text-[12.5px] text-muted">{p.category}</span>
              </span>
            </Link>
          </li>
        ))}
      </ul>
      <p className="mt-4 text-[13px] text-muted">All demos are fictional businesses created to show our work. <Link href={PORTFOLIO_URL} className="font-semibold text-ink underline underline-offset-2">See the full portfolio</Link>.</p>
    </div>
  );
}

function StepHow() {
  return (
    <div>
      <h3 className={lead}>Understand how it works.</h3>
      <p className={body}>You don&apos;t need to understand the technical side. We&apos;ll guide you through every step.</p>
      <ol className="mt-6 space-y-2.5">
        {processSteps.map((s, i) => (
          <li key={s.title} className="flex items-center gap-3 rounded-lg border border-line bg-white px-4 py-3">
            <span className="flex h-7 w-7 shrink-0 items-center justify-center rounded-full bg-ink text-[12.5px] font-bold text-white">{i + 1}</span>
            <span className="text-[15px] font-medium text-ink">{s.short}.</span>
          </li>
        ))}
      </ol>
    </div>
  );
}

function StepTalk({ onFinish }: { onFinish: () => void }) {
  return (
    <div className="flex h-full flex-col justify-center">
      <span className="flex h-12 w-12 items-center justify-center rounded-xl bg-accent/10 text-accent" aria-hidden="true">
        <MessageCircle className="h-6 w-6" />
      </span>
      <h3 className={`${lead} mt-5`}>Have an idea in mind? We&apos;d love to hear about it.</h3>
      <p className={body}>
        Tell us a little about your business, and let&apos;s explore what we can build together. It&apos;s free, there&apos;s no obligation, and you&apos;ll get a clear written estimate.
      </p>
      <div className="mt-8 flex flex-col gap-3 sm:flex-row">
        <Link href={QUOTE_PATH} onClick={onFinish} className="btn-primary !px-6 !py-4">
          Let&apos;s Talk About Your Project <ArrowRight className="h-4 w-4" aria-hidden="true" />
        </Link>
        <Link href="/pricing" onClick={onFinish} className="btn-ghost !px-6 !py-4">See Pricing</Link>
      </div>
    </div>
  );
}
