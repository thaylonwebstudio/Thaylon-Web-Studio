import Link from "next/link";
import { Mail } from "lucide-react";
import { Logo } from "./Logo";
import { SocialIcon } from "./SocialIcon";
import {
  AGENCY_EMAIL,
  AGENCY_NAME,
  PORTFOLIO_URL,
  QUOTE_PATH,
  TAGLINE,
  socialLinks,
} from "@/config/site";

const columns = [
  {
    title: "Studio",
    links: [
      { label: "Services", href: "/services" },
      { label: "Portfolio", href: PORTFOLIO_URL },
      { label: "About", href: "/about" },
      { label: "Get a Quote", href: QUOTE_PATH },
    ],
  },
  {
    title: "Pricing",
    links: [
      { label: "Website Packages", href: "/pricing" },
      { label: "Monthly Maintenance", href: "/maintenance" },
      { label: "Custom Projects", href: "/pricing#custom" },
      { label: "FAQ", href: "/#faq" },
    ],
  },
  {
    title: "Industries",
    links: [
      { label: "Restaurants", href: "/portfolio/bella-napoli" },
      { label: "Cleaning Companies", href: "/portfolio/freshhome-cleaning" },
      { label: "Landscaping", href: "/portfolio/greenleaf-landscaping" },
      { label: "Contractors & Roofing", href: "/portfolio/summit-roofing" },
      { label: "Salons & Barbershops", href: "/portfolio/gentlemans-cut" },
    ],
  },
];

export function Footer() {
  const year = new Date().getFullYear();
  return (
    <footer className="relative overflow-hidden bg-ink text-white">
      <div className="grid-bg-dark pointer-events-none absolute inset-0 opacity-60 [mask-image:linear-gradient(to_bottom,black,transparent_70%)]" />
      <div className="container-x relative pt-20 pb-10">
        <div className="grid gap-12 lg:grid-cols-[1.3fr_2fr]">
          <div className="max-w-sm">
            <Logo dark />
            <p className="mt-5 text-[15px] leading-relaxed text-white/70">{TAGLINE}</p>
            <p className="mt-3 text-[15px] leading-relaxed text-white/70">
              Independent web design &amp; development for small businesses across the United States.
            </p>
            <div className="mt-7 flex flex-wrap items-center gap-3">
              {AGENCY_EMAIL && (
                <a
                  href={`mailto:${AGENCY_EMAIL}`}
                  className="inline-flex items-center gap-2 rounded-lg border border-white/15 px-3.5 py-2 text-sm text-white/80 transition hover:border-white/40 hover:text-white"
                >
                  <Mail className="h-4 w-4" /> {AGENCY_EMAIL}
                </a>
              )}
              {socialLinks.map((s) => (
                <a
                  key={s.label}
                  href={s.href}
                  target="_blank"
                  rel="noopener noreferrer"
                  aria-label={`${AGENCY_NAME} on ${s.label}`}
                  className="inline-flex h-10 w-10 items-center justify-center rounded-lg border border-white/15 text-white/70 transition hover:border-white/40 hover:text-white"
                >
                  <SocialIcon name={s.icon} />
                </a>
              ))}
            </div>
          </div>

          <div className="grid grid-cols-2 gap-10 sm:grid-cols-3">
            {columns.map((col) => (
              <div key={col.title}>
                <h3 className="text-[12px] font-semibold uppercase tracking-[0.16em] text-white/60">{col.title}</h3>
                <ul className="mt-4 space-y-1">
                  {col.links.map((l) => (
                    <li key={l.label}>
                      <Link href={l.href} className="link-underline inline-block py-1.5 text-[15px] text-white/75 hover:text-white">
                        {l.label}
                      </Link>
                    </li>
                  ))}
                </ul>
              </div>
            ))}
          </div>
        </div>

        <div className="mt-16 flex flex-col gap-4 border-t border-white/10 pt-8 text-sm text-white/65 sm:flex-row sm:items-center sm:justify-between">
          <p>
            © {year} {AGENCY_NAME}. All rights reserved.
          </p>
          <ul className="flex flex-wrap gap-x-6 gap-y-2">
            <li><Link href="/privacy" className="inline-block py-2 hover:text-white">Privacy Policy</Link></li>
            <li><Link href="/terms" className="inline-block py-2 hover:text-white">Terms of Service</Link></li>
          </ul>
        </div>
      </div>
    </footer>
  );
}
