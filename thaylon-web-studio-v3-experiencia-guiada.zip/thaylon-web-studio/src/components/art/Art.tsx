/**
 * Hand-built SVG illustrations used by the portfolio demos and thumbnails.
 * No stock photography → no licensing issues, no broken hotlinks, tiny payload.
 */
type ArtProps = { className?: string; title?: string };

const A11y = ({ title }: { title?: string }) => (title ? <title>{title}</title> : null);

export function PizzaArt({ className, title = "Wood-fired Margherita pizza" }: ArtProps) {
  const basil = [
    [150, 120, -20], [235, 105, 30], [205, 190, 70], [130, 190, -60], [180, 150, 10],
  ];
  const tomato = [
    [120, 150], [175, 105], [250, 145], [220, 215], [150, 225], [195, 170], [265, 190],
  ];
  return (
    <svg viewBox="0 0 400 340" className={className} role="img">
      <A11y title={title} />
      <ellipse cx="200" cy="300" rx="150" ry="16" fill="#000" opacity=".25" />
      <rect x="40" y="40" width="320" height="260" rx="130" fill="#8a5a33" />
      <rect x="290" y="150" width="100" height="36" rx="18" fill="#7a4c29" />
      <circle cx="195" cy="168" r="122" fill="#e9b872" />
      <circle cx="195" cy="168" r="122" fill="none" stroke="#c98c46" strokeWidth="14" opacity=".55" />
      <circle cx="195" cy="168" r="104" fill="#c8361f" />
      <circle cx="195" cy="168" r="104" fill="url(#pz-sauce)" />
      {[[160, 140, 26], [228, 130, 22], [205, 205, 28], [140, 200, 20], [250, 188, 18], [190, 160, 16]].map(([x, y, r], i) => (
        <circle key={i} cx={x} cy={y} r={r} fill="#fbf1dc" opacity=".95" />
      ))}
      {tomato.map(([x, y], i) => (
        <g key={i}>
          <circle cx={x} cy={y} r="11" fill="#e2492f" />
          <circle cx={x} cy={y} r="6" fill="#f0735a" />
        </g>
      ))}
      {basil.map(([x, y, r], i) => (
        <path
          key={i}
          d="M0 0 C 8 -12, 24 -12, 30 0 C 24 12, 8 12, 0 0 Z"
          fill="#2f7d3a"
          transform={`translate(${x} ${y}) rotate(${r})`}
        />
      ))}
      {[[110, 110], [280, 120], [270, 240], [120, 250]].map(([x, y], i) => (
        <circle key={i} cx={x} cy={y} r="5" fill="#5a2c13" opacity=".35" />
      ))}
      <defs>
        <radialGradient id="pz-sauce" cx=".45" cy=".4" r=".7">
          <stop offset="0" stopColor="#e5543a" stopOpacity=".6" />
          <stop offset="1" stopColor="#8f2213" stopOpacity=".4" />
        </radialGradient>
      </defs>
    </svg>
  );
}

export function HomeSparkleArt({ className, title = "Spotless home illustration" }: ArtProps) {
  return (
    <svg viewBox="0 0 400 340" className={className} role="img">
      <A11y title={title} />
      <circle cx="200" cy="180" r="140" fill="#dff3ee" />
      <path d="M95 175 L200 90 L305 175 V280 H95 Z" fill="#ffffff" stroke="#0f3d3e" strokeWidth="6" strokeLinejoin="round" />
      <path d="M78 186 L200 86 L322 186" fill="none" stroke="#0f3d3e" strokeWidth="10" strokeLinecap="round" strokeLinejoin="round" />
      <rect x="178" y="210" width="44" height="70" rx="4" fill="#25b39a" />
      <circle cx="213" cy="246" r="3.5" fill="#fff" />
      <rect x="120" y="195" width="40" height="36" rx="4" fill="#bfe9df" stroke="#0f3d3e" strokeWidth="4" />
      <rect x="240" y="195" width="40" height="36" rx="4" fill="#bfe9df" stroke="#0f3d3e" strokeWidth="4" />
      <path d="M140 195 V231 M120 213 H160 M260 195 V231 M240 213 H280" stroke="#0f3d3e" strokeWidth="3" />
      {[[310, 95, 22], [90, 110, 14], [330, 230, 12], [70, 250, 18]].map(([x, y, s], i) => (
        <path
          key={i}
          d={`M${x} ${y - s} C ${x + s * 0.15} ${y - s * 0.15}, ${x + s * 0.15} ${y - s * 0.15}, ${x + s} ${y} C ${x + s * 0.15} ${y + s * 0.15}, ${x + s * 0.15} ${y + s * 0.15}, ${x} ${y + s} C ${x - s * 0.15} ${y + s * 0.15}, ${x - s * 0.15} ${y + s * 0.15}, ${x - s} ${y} C ${x - s * 0.15} ${y - s * 0.15}, ${x - s * 0.15} ${y - s * 0.15}, ${x} ${y - s} Z`}
          fill="#f6b73c"
        />
      ))}
      {[[255, 70, 14], [280, 50, 8], [130, 60, 10]].map(([x, y, r], i) => (
        <circle key={i} cx={x} cy={y} r={r} fill="none" stroke="#25b39a" strokeWidth="3" />
      ))}
    </svg>
  );
}

export function BarberArt({ className, title = "Barber pole and straight razor" }: ArtProps) {
  return (
    <svg viewBox="0 0 400 340" className={className} role="img">
      <A11y title={title} />
      <defs>
        <clipPath id="bb-pole"><rect x="60" y="60" width="60" height="220" rx="30" /></clipPath>
        <linearGradient id="bb-steel" x1="0" x2="1">
          <stop offset="0" stopColor="#d8d4cc" />
          <stop offset=".5" stopColor="#fbfaf7" />
          <stop offset="1" stopColor="#a8a399" />
        </linearGradient>
      </defs>
      <rect x="54" y="40" width="72" height="22" rx="8" fill="#c9a24a" />
      <rect x="54" y="278" width="72" height="22" rx="8" fill="#c9a24a" />
      <g clipPath="url(#bb-pole)">
        <rect x="60" y="60" width="60" height="220" fill="#f3efe7" />
        {Array.from({ length: 9 }).map((_, i) => (
          <path key={i} d={`M40 ${40 + i * 34} L140 ${0 + i * 34} L140 ${16 + i * 34} L40 ${56 + i * 34} Z`} fill={i % 2 ? "#1f3b6e" : "#a7262b"} />
        ))}
      </g>
      <rect x="60" y="60" width="60" height="220" rx="30" fill="none" stroke="#000" strokeOpacity=".2" />
      <g transform="translate(170 110) rotate(-18)">
        <rect x="0" y="40" width="190" height="34" rx="6" fill="#1a1a1a" />
        <rect x="8" y="48" width="170" height="4" rx="2" fill="#c9a24a" opacity=".7" />
        <path d="M150 40 L150 10 C 150 0, 160 -6, 172 -2 L 200 10 L 200 40 Z" fill="url(#bb-steel)" transform="translate(-120 0) scale(1.6 1)" />
        <circle cx="12" cy="57" r="7" fill="#c9a24a" />
      </g>
      <g transform="translate(180 220)">
        <rect x="0" y="0" width="180" height="22" rx="4" fill="#c9a24a" />
        {Array.from({ length: 22 }).map((_, i) => (
          <rect key={i} x={6 + i * 8} y="20" width="4" height={i < 11 ? 30 : 22} rx="2" fill="#c9a24a" />
        ))}
      </g>
    </svg>
  );
}

export function LandscapeArt({ className, title = "Landscaped garden with trees" }: ArtProps) {
  return (
    <svg viewBox="0 0 400 340" className={className} role="img" preserveAspectRatio="xMidYMid slice">
      <A11y title={title} />
      <rect width="400" height="340" fill="#eaf1e4" />
      <circle cx="300" cy="90" r="38" fill="#f2c14e" />
      <path d="M0 200 C 80 150, 160 170, 230 150 S 360 130, 400 160 V340 H0Z" fill="#9cc58a" />
      <path d="M0 240 C 100 200, 200 230, 280 210 S 380 200, 400 215 V340 H0Z" fill="#5d9a52" />
      <path d="M0 290 C 120 260, 240 285, 400 265 V340 H0Z" fill="#2f6b3a" />
      <path d="M170 340 C 190 300, 230 280, 260 262" stroke="#e9dcc0" strokeWidth="18" fill="none" strokeLinecap="round" />
      {[[70, 200, 1.1], [115, 215, 0.8], [330, 190, 1], [360, 205, 0.7]].map(([x, y, s], i) => (
        <g key={i} transform={`translate(${x} ${y}) scale(${s})`}>
          <rect x="-4" y="0" width="8" height="40" fill="#5b4031" />
          <circle cx="0" cy="-10" r="28" fill="#2f6b3a" />
          <circle cx="-14" cy="2" r="18" fill="#3f8248" />
          <circle cx="14" cy="0" r="20" fill="#3f8248" />
        </g>
      ))}
      {[[200, 300], [215, 310], [300, 290], [60, 305]].map(([x, y], i) => (
        <g key={i}>
          <circle cx={x} cy={y} r="6" fill="#f08a6b" />
          <circle cx={x + 10} cy={y + 4} r="5" fill="#f6d36b" />
        </g>
      ))}
    </svg>
  );
}

export function RoofArt({ className, title = "Home with new shingle roof" }: ArtProps) {
  return (
    <svg viewBox="0 0 400 340" className={className} role="img" preserveAspectRatio="xMidYMid slice">
      <A11y title={title} />
      <defs>
        <pattern id="rf-shingle" width="28" height="18" patternUnits="userSpaceOnUse">
          <rect width="28" height="18" fill="#2b3240" />
          <path d="M0 17.5 H28 M14 0 V9 M0 9 H28 M0 9 V18 M28 9 V18" stroke="#1b2130" strokeWidth="1.5" />
        </pattern>
        <linearGradient id="rf-sky" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0" stopColor="#cfe0ef" />
          <stop offset="1" stopColor="#f3f6f9" />
        </linearGradient>
      </defs>
      <rect width="400" height="340" fill="url(#rf-sky)" />
      <path d="M0 210 L80 140 L140 185 L220 110 L320 200 L400 150 V340 H0Z" fill="#b9c8d6" />
      <rect x="90" y="190" width="220" height="120" fill="#efe8dc" />
      <path d="M60 200 L200 95 L340 200 Z" fill="url(#rf-shingle)" />
      <path d="M52 204 L200 92 L348 204" fill="none" stroke="#f28c28" strokeWidth="8" strokeLinejoin="round" />
      <rect x="250" y="110" width="26" height="50" fill="#9c5b3c" />
      <rect x="180" y="240" width="44" height="70" fill="#3d4a5c" />
      <rect x="112" y="220" width="44" height="40" fill="#cde3f1" stroke="#3d4a5c" strokeWidth="4" />
      <rect x="246" y="220" width="44" height="40" fill="#cde3f1" stroke="#3d4a5c" strokeWidth="4" />
      <rect x="0" y="308" width="400" height="32" fill="#7ea36b" />
    </svg>
  );
}

export function CarArt({ className, title = "Detailed sports sedan" }: ArtProps) {
  return (
    <svg viewBox="0 0 480 220" className={className} role="img">
      <A11y title={title} />
      <defs>
        <linearGradient id="car-body" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0" stopColor="#3a3f4a" />
          <stop offset=".45" stopColor="#14161b" />
          <stop offset="1" stopColor="#050607" />
        </linearGradient>
        <linearGradient id="car-glass" x1="0" x2="1">
          <stop offset="0" stopColor="#6c7a8f" />
          <stop offset="1" stopColor="#1d232c" />
        </linearGradient>
      </defs>
      <ellipse cx="240" cy="190" rx="220" ry="14" fill="#000" opacity=".5" />
      <path d="M30 150 C 30 125, 60 112, 100 108 L 160 70 C 180 58, 220 52, 270 54 C 320 56, 350 70, 380 98 L 430 108 C 455 114, 462 130, 460 150 L 456 168 H 34 Z" fill="url(#car-body)" />
      <path d="M170 76 C 190 64, 220 60, 262 61 L 268 100 H 130 Z" fill="url(#car-glass)" />
      <path d="M280 61 C 318 64, 342 74, 366 98 L 286 100 Z" fill="url(#car-glass)" />
      <path d="M60 124 C 160 112, 330 110, 450 122" stroke="#ffffff" strokeOpacity=".35" strokeWidth="2" fill="none" />
      <path d="M440 120 h 16 v 10 h -16 z" fill="#ffd27a" />
      <path d="M34 128 h 14 v 10 h -14 z" fill="#ff3b3b" />
      {[120, 370].map((x) => (
        <g key={x}>
          <circle cx={x} cy="162" r="34" fill="#0a0a0a" />
          <circle cx={x} cy="162" r="22" fill="#9aa3ad" />
          <circle cx={x} cy="162" r="22" fill="none" stroke="#2c3138" strokeWidth="6" strokeDasharray="6 5" />
          <circle cx={x} cy="162" r="6" fill="#2c3138" />
        </g>
      ))}
      <path d="M200 40 l 6 -18 l 6 18 l 18 6 l -18 6 l -6 18 l -6 -18 l -18 -6 z" fill="#ffffff" opacity=".9" />
      <path d="M390 70 l 3 -9 l 3 9 l 9 3 l -9 3 l -3 9 l -3 -9 l -9 -3 z" fill="#ffffff" opacity=".7" />
    </svg>
  );
}

export function BeautyArt({ className, title = "Floral salon illustration" }: ArtProps) {
  const petals = Array.from({ length: 8 });
  return (
    <svg viewBox="0 0 400 340" className={className} role="img">
      <A11y title={title} />
      <path d="M90 340 V170 C 90 95, 150 40, 200 40 C 250 40, 310 95, 310 170 V340 Z" fill="#ead6cc" />
      <path d="M120 340 V178 C 120 115, 165 72, 200 72 C 235 72, 280 115, 280 178 V340 Z" fill="#f6ebe4" />
      {[[200, 175, 1], [150, 245, 0.7], [255, 255, 0.6]].map(([x, y, s], k) => (
        <g key={k} transform={`translate(${x} ${y}) scale(${s})`}>
          {petals.map((_, i) => (
            <ellipse key={i} cx="0" cy="-34" rx="16" ry="34" fill={k === 0 ? "#c98b7b" : "#d9a596"} opacity=".9" transform={`rotate(${i * 45})`} />
          ))}
          <circle r="14" fill="#a8695a" />
        </g>
      ))}
      <path d="M200 210 C 200 260, 190 300, 200 340" stroke="#7b8f6a" strokeWidth="5" fill="none" />
      <path d="M200 270 C 230 255, 250 262, 262 278 C 240 288, 215 284, 200 270 Z" fill="#8fa37c" />
      <path d="M198 300 C 170 288, 150 292, 140 306 C 160 316, 184 312, 198 300 Z" fill="#8fa37c" />
    </svg>
  );
}

export function PlumbingArt({ className, title = "Plumbing pipes and water drop" }: ArtProps) {
  return (
    <svg viewBox="0 0 400 340" className={className} role="img">
      <A11y title={title} />
      <circle cx="210" cy="170" r="150" fill="#e6f0ff" />
      <path d="M40 110 H200 C 230 110, 250 130, 250 160 V250" stroke="#1d4ed8" strokeWidth="34" fill="none" strokeLinecap="round" />
      <path d="M40 110 H200 C 230 110, 250 130, 250 160 V250" stroke="#3b82f6" strokeWidth="14" fill="none" strokeLinecap="round" opacity=".5" />
      {[90, 160].map((x) => <rect key={x} x={x} y="86" width="18" height="48" rx="4" fill="#0f2a6b" />)}
      <rect x="226" y="190" width="48" height="18" rx="4" fill="#0f2a6b" />
      <path d="M250 262 C 250 262, 222 296, 222 314 C 222 330, 235 340, 250 340 C 265 340, 278 330, 278 314 C 278 296, 250 262, 250 262 Z" fill="#38bdf8" transform="translate(0 -30)" />
      <g transform="translate(300 60) rotate(40)">
        <rect x="-8" y="0" width="16" height="120" rx="8" fill="#f97316" />
        <path d="M-26 -10 C -26 -36, 26 -36, 26 -10 L 14 -10 L 14 -24 L -14 -24 L -14 -10 Z" fill="#f97316" />
      </g>
    </svg>
  );
}

export function GoodsArt({ className, title = "Curated home goods still life" }: ArtProps) {
  return (
    <svg viewBox="0 0 400 340" className={className} role="img">
      <A11y title={title} />
      <rect x="0" y="250" width="400" height="90" fill="#d9cfbf" />
      <rect x="40" y="110" width="110" height="140" rx="6" fill="#c56b3c" />
      <path d="M65 110 C 65 70, 125 70, 125 110" stroke="#8a4524" strokeWidth="8" fill="none" />
      <text x="95" y="190" textAnchor="middle" fontFamily="sans-serif" fontWeight="700" fontSize="16" fill="#f5ead9" letterSpacing="2">UG</text>
      <rect x="170" y="150" width="58" height="100" rx="10" fill="#2d3b36" />
      <rect x="186" y="128" width="26" height="26" rx="4" fill="#2d3b36" />
      <rect x="178" y="185" width="42" height="34" rx="3" fill="#f2ead9" />
      <path d="M250 190 h 60 v 50 a 10 10 0 0 1 -10 10 h -40 a 10 10 0 0 1 -10 -10 z" fill="#f2ead9" stroke="#2d3b36" strokeWidth="4" />
      <path d="M310 200 c 22 0, 22 30, 0 30" stroke="#2d3b36" strokeWidth="5" fill="none" />
      <path d="M340 250 v -40 h 40 v 40 z" fill="#b8a48a" />
      <path d="M360 210 C 345 170, 350 140, 360 120 C 370 140, 375 170, 360 210 Z" fill="#5f7d54" />
      <path d="M360 210 C 330 190, 322 165, 326 150 C 344 160, 356 185, 360 210 Z" fill="#7a9a6c" />
      <path d="M360 210 C 390 190, 398 165, 394 150 C 376 160, 364 185, 360 210 Z" fill="#7a9a6c" />
    </svg>
  );
}

export const artBySlug = {
  "bella-napoli": PizzaArt,
  "freshhome-cleaning": HomeSparkleArt,
  "gentlemans-cut": BarberArt,
  "greenleaf-landscaping": LandscapeArt,
  "summit-roofing": RoofArt,
  "elite-auto-detailing": CarArt,
  "luxe-beauty": BeautyArt,
  "proflow-plumbing": PlumbingArt,
  "urban-goods": GoodsArt,
} as const;

/** Stylized, fictional street map with a pin. */
export function MapArt({
  className,
  land = "#efe9df",
  road = "#ffffff",
  water = "#cfe3ef",
  park = "#d6e6c8",
  pin = "#e44848",
  title = "Map (illustrative)",
}: ArtProps & { land?: string; road?: string; water?: string; park?: string; pin?: string }) {
  return (
    <svg viewBox="0 0 600 400" className={className} role="img" preserveAspectRatio="xMidYMid slice">
      <A11y title={title} />
      <rect width="600" height="400" fill={land} />
      <path d="M0 300 C 120 280, 200 340, 320 320 S 520 260, 600 290 V400 H0Z" fill={water} />
      <rect x="380" y="60" width="140" height="110" rx="10" fill={park} />
      <rect x="60" y="150" width="90" height="70" rx="8" fill={park} />
      {[80, 170, 250].map((y) => <rect key={y} x="0" y={y} width="600" height={y === 170 ? 18 : 10} fill={road} />)}
      {[120, 260, 360, 540].map((x) => <rect key={x} x={x} y="0" width={x === 260 ? 18 : 10} height="400" fill={road} />)}
      <path d="M0 40 L600 230" stroke={road} strokeWidth="12" />
      <g transform="translate(269 150)">
        <circle r="38" fill={pin} opacity=".15" />
        <path d="M0 18 C -14 0, -18 -8, -18 -16 A 18 18 0 1 1 18 -16 C 18 -8, 14 0, 0 18 Z" fill={pin} transform="translate(0 -14)" />
        <circle cx="0" cy="-30" r="6" fill="#fff" />
      </g>
    </svg>
  );
}
