import Link from "next/link";
import {
  ArrowRight,
  ArrowUpRight,
  Building2,
  Check,
  MessageSquare,
  MousePointerClick,
  PenTool,
  Plus,
  Puzzle,
  Search,
  ShieldCheck,
  Smartphone,
  Sparkles,
  Target,
} from "lucide-react";
import type { Plan } from "@/data/pricing";
import type { Project } from "@/data/portfolio";
import { MiniSite } from "./MiniSite";
import { QUOTE_PATH } from "@/config/site";
import { processSteps } from "@/data/content";

export const serviceIcons = { PenTool, Smartphone, Building2, MousePointerClick, MessageSquare, Search, ShieldCheck, Puzzle };

export function SectionHeading({
  eyebrow,
  title,
  intro,
  align = "left",
  dark = false,
  as: Tag = "h2",
}: {
  eyebrow?: string;
  title: React.ReactNode;
  intro?: React.ReactNode;
  align?: "left" | "center";
  dark?: boolean;
  as?: "h1" | "h2";
}) {
  return (
    <div className={`reveal max-w-2xl ${align === "center" ? "mx-auto text-center" : ""}`}>
      {eyebrow && <p className={`eyebrow ${align === "center" ? "justify-center" : ""} ${dark ? "!text-[#f28b82]" : ""}`}>{eyebrow}</p>}
      <Tag
        className={`mt-4 font-extrabold leading-[1.08] ${
          Tag === "h1" ? "text-[34px] min-[380px]:text-[40px] sm:text-[56px]" : "text-[30px] min-[380px]:text-[32px] sm:text-[44px]"
        } ${dark ? "text-white" : "text-ink"}`}
      >
        {title}
      </Tag>
      {intro && (
        <p className={`mt-5 text-[17px] leading-relaxed sm:text-lg ${dark ? "text-white/75" : "text-muted"}`}>{intro}</p>
      )}
    </div>
  );
}

export function PageHero({
  eyebrow,
  title,
  intro,
  children,
}: {
  eyebrow: string;
  title: React.ReactNode;
  intro: React.ReactNode;
  children?: React.ReactNode;
}) {
  return (
    <section className="relative overflow-hidden border-b border-line bg-paper">
      <div className="grid-bg pointer-events-none absolute inset-0 [mask-image:radial-gradient(ellipse_at_top,black,transparent_70%)]" />
      <div className="container-x relative py-16 sm:py-24">
        <div className="animate-fade-up">
          <SectionHeading as="h1" eyebrow={eyebrow} title={title} intro={intro} />
        </div>
        {children}
      </div>
    </section>
  );
}

export function BrowserFrame({ children, url, className = "" }: { children: React.ReactNode; url?: string; className?: string }) {
  return (
    <div className={`overflow-hidden rounded-xl border border-black/10 bg-white shadow-[0_30px_60px_-30px_rgba(16,24,39,.45)] ${className}`}>
      <div className="flex items-center gap-2 border-b border-black/5 bg-[#f6f7f9] px-3 py-2">
        <span className="flex gap-1.5">
          <span className="h-2.5 w-2.5 rounded-full bg-[#ff5f57]" />
          <span className="h-2.5 w-2.5 rounded-full bg-[#febc2e]" />
          <span className="h-2.5 w-2.5 rounded-full bg-[#28c840]" />
        </span>
        {url && (
          <span className="ml-2 hidden truncate rounded-md bg-white px-3 py-0.5 text-[11px] text-muted sm:block">{url}</span>
        )}
      </div>
      {children}
    </div>
  );
}

export function PortfolioCard({ project, detailed = false }: { project: Project; detailed?: boolean }) {
  return (
    <article className="card card-hover reveal group flex flex-col overflow-hidden" aria-labelledby={`pc-${project.slug}`}>
      <Link href={`/portfolio/${project.slug}`} className="block" aria-hidden="true" tabIndex={-1}>
        <div className="relative aspect-[16/10] overflow-hidden border-b border-line bg-paper">
          <div className="absolute inset-0 origin-top transition-transform duration-500 ease-out group-hover:scale-[1.03]">
            <MiniSite project={project} />
          </div>
          <span className="absolute top-3 left-3 rounded-md bg-white/95 px-2 py-1 text-[10.5px] font-bold tracking-[0.12em] text-ink uppercase shadow-sm">
            Demo · Fictional business
          </span>
        </div>
      </Link>
      <div className="flex flex-1 flex-col p-6">
        <div className="flex items-center justify-between gap-3">
          <p className="text-[12px] font-semibold tracking-[0.14em] text-accent-dark uppercase">{project.category}</p>
          <div className="flex gap-1" aria-hidden="true">
            {project.theme.swatches.map((c) => (
              <span key={c} className="h-3 w-3 rounded-full border border-black/10" style={{ background: c }} />
            ))}
          </div>
        </div>
        <h3 id={`pc-${project.slug}`} className="mt-2 text-xl font-bold text-ink">{project.name}</h3>
        {detailed ? (
          <dl className="mt-4 space-y-4 text-[14.5px] leading-relaxed">
            <div>
              <dt className="flex items-center gap-1.5 text-[12px] font-bold tracking-[0.12em] text-ink/70 uppercase"><Target className="h-3.5 w-3.5 text-accent" aria-hidden="true" /> Project goal</dt>
              <dd className="mt-1 text-muted">{project.goal}</dd>
            </div>
            <div>
              <dt className="text-[12px] font-bold tracking-[0.12em] text-ink/70 uppercase">Features shown</dt>
              <dd className="mt-2">
                <ul className="flex flex-wrap gap-1.5">
                  {project.features.map((f) => (
                    <li key={f} className="rounded-md bg-paper px-2 py-1 text-[12.5px] text-ink/80">{f}</li>
                  ))}
                </ul>
              </dd>
            </div>
            <div className="rounded-lg border border-line bg-paper/60 p-3.5">
              <dt className="flex items-center gap-1.5 text-[12px] font-bold tracking-[0.12em] text-ink/70 uppercase"><Sparkles className="h-3.5 w-3.5 text-accent" aria-hidden="true" /> Why it helps</dt>
              <dd className="mt-1 text-ink/80">{project.benefit}</dd>
            </div>
          </dl>
        ) : (
          <>
            <p className="mt-2 text-[15px] leading-relaxed text-muted">{project.short}</p>
            <ul className="mt-4 flex flex-wrap gap-1.5">
              {project.features.slice(0, 3).map((f) => (
                <li key={f} className="rounded-md bg-paper px-2 py-1 text-[12px] text-ink/80">{f}</li>
              ))}
            </ul>
          </>
        )}
        <div className="mt-auto pt-6">
          <Link
            href={`/portfolio/${project.slug}`}
            className="inline-flex min-h-11 items-center gap-1.5 text-[15px] font-semibold text-ink transition-colors group-hover:text-accent-dark"
          >
            View the Demo <span className="sr-only">: {project.name}</span>
            <ArrowUpRight className="h-4 w-4 transition-transform group-hover:translate-x-0.5 group-hover:-translate-y-0.5" aria-hidden="true" />
          </Link>
        </div>
      </div>
    </article>
  );
}

/** "From the First Conversation to Launch" — the 5-step process, reused across pages. */
export function ProcessSection({ dark = true, compact = false }: { dark?: boolean; compact?: boolean }) {
  return (
    <section id="process" className={`relative overflow-hidden ${compact ? "py-16 sm:py-20" : "py-20 sm:py-28"} ${dark ? "bg-navy text-white" : "bg-paper"}`}>
      {dark && <div className="grid-bg-dark pointer-events-none absolute inset-0 [mask-image:linear-gradient(to_bottom,black,transparent)]" />}
      <div className="container-x relative">
        <SectionHeading
          dark={dark}
          eyebrow="How it works"
          title="From the First Conversation to Launch"
          intro="We'll keep things clear, communicate with you throughout the process, and make sure you know what comes next."
        />
        <ol className="mt-14 grid gap-4 sm:grid-cols-2 lg:grid-cols-5 lg:gap-0">
          {processSteps.map((s, i) => (
            <li key={s.title} className="reveal group relative lg:pr-6">
              <div className={`h-full rounded-xl border p-6 lg:rounded-none lg:border-0 lg:p-0 ${dark ? "border-white/10 bg-white/[0.03] lg:bg-transparent" : "border-line bg-white lg:bg-transparent"}`}>
                <div className="flex items-center gap-3">
                  <span className={`flex h-11 w-11 shrink-0 items-center justify-center rounded-full border font-display text-[15px] font-bold transition-colors ${dark ? "border-white/25 group-hover:border-accent group-hover:bg-accent" : "border-ink/20 bg-white group-hover:border-accent group-hover:bg-accent group-hover:text-white"}`}>
                    {i + 1}
                  </span>
                  {i < processSteps.length - 1 && (
                    <span className={`hidden h-px flex-1 lg:block ${dark ? "bg-gradient-to-r from-white/30 to-white/5" : "bg-gradient-to-r from-ink/20 to-ink/5"}`} aria-hidden="true" />
                  )}
                </div>
                <p className={`mt-5 text-[12px] font-bold tracking-[0.14em] uppercase ${dark ? "text-white/55" : "text-muted"}`}>Step {i + 1}</p>
                <h3 className="mt-1 text-lg font-bold">{s.title}</h3>
                <p className={`mt-2 text-[15px] leading-relaxed ${dark ? "text-white/70" : "text-muted"}`}>{s.body}</p>
              </div>
            </li>
          ))}
        </ol>
        <div className="mt-12 flex flex-col gap-3 sm:flex-row">
          <Link href={QUOTE_PATH} className="btn-primary">Tell Us About Your Business <ArrowRight className="h-4 w-4" /></Link>
          <Link href="/#faq" className={dark ? "btn-ghost-dark" : "btn-ghost"}>Read the FAQ</Link>
        </div>
      </div>
    </section>
  );
}

export function PlanCard({ plan, ctaLabel = "Get Your Free Estimate", ctaHref }: { plan: Plan; ctaLabel?: string; ctaHref?: string }) {
  const href = ctaHref ?? `${QUOTE_PATH}?package=${plan.id}`;
  return (
    <div
      className={`reveal relative flex flex-col rounded-xl border p-7 transition-all duration-300 sm:p-8 ${
        plan.featured
          ? "border-ink bg-ink text-white shadow-[0_30px_60px_-30px_rgba(16,24,39,.6)]"
          : "border-line bg-white hover:border-ink/20"
      }`}
    >
      {plan.featured && (
        <span className="absolute -top-3 left-7 rounded-md bg-accent px-2.5 py-1 text-[11px] font-bold tracking-[0.12em] text-white uppercase">
          Most popular
        </span>
      )}
      <h3 className={`text-lg font-bold ${plan.featured ? "text-white" : "text-ink"}`}>{plan.name}</h3>
      <p className={`mt-2 text-[15px] lg:min-h-[72px] xl:min-h-[48px] leading-relaxed ${plan.featured ? "text-white/75" : "text-muted"}`}>{plan.tagline}</p>
      <p className="mt-6 flex items-baseline gap-2">
        <span className="font-display text-5xl font-extrabold tracking-tight">{plan.price}</span>
        <span className={plan.featured ? "text-white/75" : "text-muted"}>{plan.cadence}</span>
      </p>
      <Link href={href} className={`mt-7 w-full ${plan.featured ? "btn-primary" : "btn-dark"}`}>
        {ctaLabel} <ArrowRight className="h-4 w-4" />
      </Link>
      <ul className="mt-8 space-y-3.5">
        {plan.features.map((f) => (
          <li key={f} className="flex gap-3 text-[15px]">
            <Check className={`mt-0.5 h-[18px] w-[18px] shrink-0 ${plan.featured ? "text-accent" : "text-accent"}`} />
            <span className={plan.featured ? "text-white/90" : "text-ink/80"}>{f}</span>
          </li>
        ))}
      </ul>
      <div className={`mt-auto pt-8 text-[13px] leading-relaxed ${plan.featured ? "text-white/70" : "text-muted"}`}>
        <p><span className="font-semibold">Best for:</span> {plan.bestFor}</p>
        {plan.timeline && <p className="mt-1"><span className="font-semibold">Timeline:</span> {plan.timeline}</p>}
      </div>
    </div>
  );
}

export function FAQList({ items }: { items: { q: string; a: string }[] }) {
  return (
    <div className="divide-y divide-line border-y border-line">
      {items.map((item) => (
        <details key={item.q} className="group py-1 [&_summary::-webkit-details-marker]:hidden">
          <summary className="flex cursor-pointer list-none items-center justify-between gap-6 py-5 text-left font-display text-[17px] font-bold text-ink sm:text-lg">
            {item.q}
            <span className="flex h-8 w-8 shrink-0 items-center justify-center rounded-full border border-line transition-all duration-300 group-open:rotate-45 group-open:border-accent group-open:bg-accent group-open:text-white">
              <Plus className="h-4 w-4" />
            </span>
          </summary>
          <p className="max-w-3xl pb-6 text-[16px] leading-relaxed text-muted">{item.a}</p>
        </details>
      ))}
    </div>
  );
}

export function CTASection({
  title = "Let's build something together.",
  body = "Tell us a little about your business and what you have in mind. You'll get a clear, written estimate — no pressure and no obligation.",
}: {
  title?: string;
  body?: string;
}) {
  return (
    <section className="bg-white py-20 sm:py-28">
      <div className="container-x">
        <div className="reveal relative overflow-hidden rounded-2xl bg-navy px-6 py-14 text-white sm:px-14 sm:py-20">
          <div className="grid-bg-dark pointer-events-none absolute inset-0 [mask-image:radial-gradient(ellipse_at_right,black,transparent_70%)]" />
          <div className="pointer-events-none absolute -right-24 -bottom-24 h-80 w-80 rounded-full bg-accent/25 blur-3xl" />
          <div className="relative grid items-end gap-10 lg:grid-cols-[1.5fr_1fr]">
            <div>
              <p className="eyebrow !text-[#f28b82]">Free estimate</p>
              <h2 className="mt-4 text-[32px] leading-[1.08] font-extrabold sm:text-[48px]">{title}</h2>
              <p className="mt-5 max-w-xl text-lg text-white/75">{body}</p>
            </div>
            <div className="flex flex-col gap-3 sm:flex-row lg:justify-end">
              <Link href={QUOTE_PATH} className="btn-primary !px-6 !py-4">
                Get Your Free Estimate <ArrowRight className="h-4 w-4" />
              </Link>
              <Link href="/pricing" className="btn-ghost-dark !px-6 !py-4">
                See Pricing
              </Link>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
