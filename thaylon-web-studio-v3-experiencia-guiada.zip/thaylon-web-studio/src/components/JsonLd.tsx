import { AGENCY_EMAIL, AGENCY_NAME, SITE_DESCRIPTION, SITE_URL, socialLinks } from "@/config/site";

/**
 * ProfessionalService structured data. Intentionally contains NO street
 * address or phone number — only facts that are accurate for a remote,
 * independent studio serving the United States.
 */
export function JsonLd() {
  const data: Record<string, unknown> = {
    "@context": "https://schema.org",
    "@type": "ProfessionalService",
    name: AGENCY_NAME,
    url: SITE_URL,
    description: SITE_DESCRIPTION,
    areaServed: { "@type": "Country", name: "United States" },
    serviceType: [
      "Website Design",
      "Website Development",
      "Website Redesign",
      "Website Maintenance",
    ],
    priceRange: "$299–$699+",
  };
  if (AGENCY_EMAIL) data.email = AGENCY_EMAIL;
  if (socialLinks.length) data.sameAs = socialLinks.map((s) => s.href);

  return (
    <script
      type="application/ld+json"
      dangerouslySetInnerHTML={{ __html: JSON.stringify(data) }}
    />
  );
}
