# Thaylon Web Studio — Agency Website

A production-ready website for an independent web design & development studio serving U.S. small businesses.

**Stack:** Next.js 15 (App Router) · TypeScript · Tailwind CSS 4 · lucide-react · self-hosted fonts (Fontsource)
**Hosting:** Vercel, Netlify, or any static host (optional static export)
**Backend:** none. The quote form uses **Netlify Forms** (built into Netlify hosting). No external email API or form service.

---

## What's included

| Area | Details |
| --- | --- |
| Agency pages | Home (with an inline 4-step welcome tour), Services, Portfolio, Pricing, Maintenance, About, Contact / Get a Quote, Thank You (after a confirmed submission, `noindex`), Privacy Policy, Terms of Service, custom 404 |
| Portfolio | 9 complete demo websites for fictional businesses at `/portfolio/<slug>`, each with its own brand, typography, layout and interactive features. Each one shows a **"DEMO PROJECT — FICTIONAL BUSINESS"** label and a **"Want a Website Like This?"** CTA |
| Conversion | Header CTA, sticky mobile CTA, CTA sections on every page, pricing → quote prefill (`/contact?package=professional`), demo → quote prefill (`/contact?demo=Bella%20Napoli`) |
| Quote form | Netlify Forms (`thaylon-quote-request`), client-side validation, accessible error messages, Netlify honeypot, privacy consent, clear success/error states. A success message only appears after Netlify accepts the submission |
| SEO | Unique titles and descriptions, canonical URLs, Open Graph and Twitter cards, generated OG image, `sitemap.xml`, `robots.txt`, `ProfessionalService` JSON-LD (no fabricated address or phone number), semantic headings, alt text |
| Accessibility | Skip link, keyboard-friendly menus, focus styles, `aria-*` on forms and toggles, honors `prefers-reduced-motion` |
| Performance | Fully static pre-rendering, ~110 KB first-load JS, SVG illustrations instead of heavy photos, self-hosted fonts, no third-party trackers |

Demo pages:

```
/portfolio/bella-napoli            Restaurant
/portfolio/freshhome-cleaning      Cleaning company
/portfolio/gentlemans-cut          Barbershop
/portfolio/greenleaf-landscaping   Landscaping
/portfolio/summit-roofing          Roofing company
/portfolio/elite-auto-detailing    Auto detailing
/portfolio/luxe-beauty             Beauty salon
/portfolio/proflow-plumbing        Plumbing company
/portfolio/urban-goods             Retail store
```

Demo forms are interactive and validate input, but they **never send data**. On submit they show a notice that the form is a demo and link to the agency quote form. All demo phone numbers use the reserved fictional `555-01xx` range, and all demo emails use the reserved `.example` domain.

---

## Quick start

Requirements: **Node.js 18.18+** (20 LTS recommended).

```bash
npm install
cp .env.example .env.local     # then fill in your values
npm run dev                    # http://localhost:3000
```

Other scripts:

```bash
npm run build       # production build
npm start           # serve the production build locally
npm run typecheck   # TypeScript check
```

---

## Configuration (one place)

All brand and contact details come from **`src/config/site.ts`**, which reads these environment variables:

| Variable | Purpose | Example |
| --- | --- | --- |
| `NEXT_PUBLIC_AGENCY_NAME` | Agency name | `Thaylon Web Studio` |
| `NEXT_PUBLIC_AGENCY_EMAIL` | Public email (footer, contact page, form fallback) | `hello@yourdomain.com` |
| `NEXT_PUBLIC_AGENCY_DOMAIN` | Domain **without** `https://`. Used for canonical URLs, sitemap and OG tags. If empty on Netlify, the Netlify site URL is used | `thaylonwebstudio.com` |
| `NEXT_PUBLIC_PORTFOLIO_URL` | Portfolio link | `/portfolio` |
| `NEXT_PUBLIC_INSTAGRAM_URL` / `FACEBOOK_URL` / `LINKEDIN_URL` | Social profiles (hidden when empty) | `https://instagram.com/...` |
| `NEXT_PUBLIC_FOUNDER_NAME` / `FOUNDER_ROLE` | About page founder section | `Thaylon` |

> Every `NEXT_PUBLIC_*` value is embedded in the browser bundle, so never put secret keys here.
> Environment variables are read at **build time**. After you change them on your host, redeploy.

Nothing is invented. Empty values are simply hidden: no fake email, phone number, address or social profile is ever shown.

### Quote form: Netlify Forms

The form works with **Netlify Forms**, with no API keys and no third-party email service.

How it works with Next.js on Netlify (as documented by Netlify / OpenNext for the Next.js runtime v5):

1. **`public/__forms.html`** is a static, hidden HTML copy of the form (`name="thaylon-quote-request"`, `data-netlify="true"`, `netlify-honeypot="bot-field"`). Netlify scans it at deploy time to register the form and its fields. Visitors never see it.
2. **`src/components/QuoteForm.tsx`** is the visible form, in three short groups (About you, Your business, Your project). It validates the input, then sends a URL-encoded `POST` to `/__forms.html` with `form-name=thaylon-quote-request`. Only when Netlify answers with a 2xx status does it go to **`/thank-you`** (with an inline confirmation as a fallback); otherwise the visitor sees an error and keeps what they typed. Duplicate submissions are blocked while sending. Validation errors are always computed from the current values, so a budget option or the privacy checkbox registers on the first tap.
3. Field names must match in both files: `form-name`, `subject`, `bot-field`, `name`, `business`, `email`, `website`, `category`, `project`, `budget`, `description`, `consent`. If you add or rename a field, update **both** files.
4. The field named `email` makes Netlify set **Reply-To** in notification emails, so you can reply directly to the visitor. The hidden `subject` field sets the email subject (`New quote request — <business name>`).
5. `bot-field` is the honeypot: hidden from people with CSS, left for bots to fill. Netlify discards submissions where it's filled.

**One-time setup in the Netlify dashboard:**

1. **Forms → Enable form detection** (needed once per site), then **redeploy** so Netlify scans `__forms.html`.
2. Check that **Forms** lists `thaylon-quote-request`.
3. **Forms → Submission notifications → Add notification → Email notification.** Choose the `thaylon-quote-request` form and enter the address that should receive quote requests.
4. If that address isn't a member of your Netlify team, Netlify marks it **pending confirmation** and sends one confirmation email. Click **Confirm** in that email, or no notifications will be sent. (If your team doesn't have confirmation yet, Netlify only accepts team members' addresses. Invite that address to the team first.)
5. Submit a test request on the live site and check **Forms → thaylon-quote-request** and your inbox. Also check the **Spam submissions** list the first time.

> Netlify Forms only work on a Netlify deploy. With `npm run dev` or `npm start` on your computer, the POST is not handled, so the form shows its error message. Use a Netlify deploy preview, or `netlify dev` from the Netlify CLI, to test submissions.

---

## Editing content

| What | Where |
| --- | --- |
| Services (8, with what / who / how it helps / included), benefits, reasons, the 5-step process, FAQ, industries | `src/data/content.ts` |
| Website packages, maintenance plans, limits, pricing note | `src/data/pricing.ts` |
| Portfolio card info (goal, features, benefit) and thumbnail theme | `src/data/portfolio.ts` |
| Welcome tour on the home page | `src/components/WelcomeTour.tsx` (remembers "skipped/finished" per browser in `localStorage` key `tws-welcome-tour`) |
| Demo website pages | `src/demos/*.tsx` |
| Founder bio text and photo | `src/app/(site)/about/page.tsx` |
| Privacy Policy and Terms (fill in the highlighted `[PLACEHOLDERS]`) | `src/app/(site)/privacy/page.tsx`, `src/app/(site)/terms/page.tsx` |
| Colors and fonts | `src/app/globals.css` (`@theme`) |
| Favicon | `src/app/icon.svg` |
| Social share image | `src/app/opengraph-image.tsx` |

**Before launch, review these business decisions.** They are reasonable defaults, but they're yours to set:

- Delivery timelines (`src/data/pricing.ts`, FAQ)
- 50% deposit payment schedule (FAQ, Pricing terms, Terms of Service)
- "We typically reply within 1–2 business days" (contact page, form success message)
- Maintenance response times and monthly time allowances
- The legal placeholders (see the list below)

**Legal placeholders still to complete** (highlighted in yellow on the pages):

| Page | Placeholder |
| --- | --- |
| Privacy & Terms | `[DATE]`, `[BUSINESS LEGAL NAME / OWNER NAME]`, `[CONTACT EMAIL]` (set `NEXT_PUBLIC_AGENCY_EMAIL`) |
| Privacy | `[RETENTION PERIOD]`, `[BUSINESS MAILING ADDRESS (optional)]` |
| Terms | `[PAYMENT METHODS]`, `[HOURLY RATE]`, `[STATE / JURISDICTION]`, the `[30]`-day values (quote validity, maintenance cancellation notice, inactive-project pause, post-launch fix window) |

Already filled: the domain (from `NEXT_PUBLIC_AGENCY_DOMAIN`, or the Netlify site address), hosting and form provider (Netlify / Netlify Forms), the 50% deposit and the two revision rounds.

The legal pages are templates, not legal advice. Have them reviewed by a qualified attorney.

### Adding a founder photo
Put `founder.jpg` in `/public` and replace the initials block in `about/page.tsx` with:

```tsx
import Image from "next/image";
<Image src="/founder.jpg" alt="Thaylon, founder of Thaylon Web Studio" fill className="object-cover" sizes="(min-width:1024px) 40vw, 100vw" />
```

---

## Project structure

```
src/
  app/
    layout.tsx                 Root layout, global metadata, fonts
    globals.css                Design tokens (Tailwind @theme) and base styles
    (site)/                    Agency pages (shared header, footer and sticky CTA)
      page.tsx                 Home
      services/ portfolio/ pricing/ maintenance/ about/ contact/ privacy/ terms/
    (demos)/portfolio/[slug]/  Demo websites (own branding plus demo banner)
    not-found.tsx              Custom 404
    sitemap.ts robots.ts icon.svg opengraph-image.tsx
  components/                  Header, Footer, QuoteForm, UI primitives, SVG art
  config/site.ts               ← central configuration
  data/                        Editable content (services, pricing, portfolio)
  demos/                       The 9 demo website components
```

---

## Deployment

See **[DEPLOYMENT.md](./DEPLOYMENT.md)** for step-by-step instructions for GitHub, Vercel, Netlify and static hosting, custom domain and DNS records, HTTPS, and domain name suggestions.

---

## Quality checks performed

- Production build passes (25 static routes), and TypeScript runs in strict mode
- Crawled every internal link and anchor: 0 broken links. `sitemap.xml`, `robots.txt`, favicon and OG image return 200, and unknown URLs return 404
- No horizontal overflow at 320, 360, 375, 390, 414, 768, 820, 1024, 1280, 1440 and 1920 px, on all pages
- Emulated devices: iPhone SE, iPhone 13, iPhone 15 Pro Max, Pixel 7, Galaxy S9+, iPad Mini, iPad Pro 11 (touch taps on the form and the tour)
- axe-core (WCAG 2 A/AA): no issues on agency pages except inside decorative demo thumbnails and some fictional demo brand colors
- No console errors
- Automated interaction tests: mobile menu, pricing → quote prefill, demo → quote prefill, form validation and focus management, Netlify Forms submit (URL-encoded payload, success, and server error without a false confirmation), honeypot not visible, portfolio filter, and each demo's interactive features (price toggles, estimate calculator, before/after slider, tabs, ZIP checker, catalog filter, demo-form notice)
