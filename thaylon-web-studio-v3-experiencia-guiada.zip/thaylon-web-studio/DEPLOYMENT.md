# Deployment & Custom Domain Guide

This project is a standard Next.js app with no database and no server secrets. Every page is pre-rendered at build time, so it deploys to almost any host.

**Recommended:** GitHub → Vercel (free Hobby plan, zero configuration).
**Also supported:** Netlify, or any static host through static export.

---

## 1. Prepare the GitHub repository

```bash
cd thaylon-web-studio
git init
git add .
git commit -m "Initial commit: Thaylon Web Studio website"
git branch -M main
# Create an empty repo on github.com first (no README), then:
git remote add origin https://github.com/<your-username>/thaylon-web-studio.git
git push -u origin main
```

`.gitignore` already excludes `node_modules`, `.next`, `out` and all `.env*` files, except `.env.example`.
Never commit `.env.local`.

---

## 2A. Deploy on Vercel (recommended)

1. Sign in at <https://vercel.com> with GitHub, then click **Add New → Project** and import the repository.
2. The framework is detected as **Next.js**. Keep the default build settings.
3. Open **Environment Variables** and add the values from `.env.example`. At minimum, set:
   - `NEXT_PUBLIC_AGENCY_EMAIL`
   - `NEXT_PUBLIC_AGENCY_DOMAIN`, once you own the domain
4. Click **Deploy**. You'll get a `*.vercel.app` preview URL.
5. Every push to `main` redeploys automatically. Other branches get preview URLs.

> After changing any environment variable, trigger a redeploy (Deployments → ⋯ → Redeploy), because the values are baked in at build time.

## 2B. Deploy on Netlify

1. At <https://app.netlify.com>, choose **Add new site → Import an existing project** and pick the GitHub repo.
2. Netlify reads `netlify.toml` (build command `npm run build`, Node 20) and uses its built-in Next.js runtime.
3. Add the environment variables under **Site configuration → Environment variables** (`NEXT_PUBLIC_AGENCY_EMAIL`, and `NEXT_PUBLIC_AGENCY_DOMAIN` once you own a domain).
4. Deploy. You'll get a `*.netlify.app` URL.
5. Set up the quote form: **Forms → Enable form detection**, redeploy, then **Forms → Submission notifications → Add notification → Email notification** for the `thaylon-quote-request` form. If you use an email address that isn't on your Netlify team, confirm it from the email Netlify sends. Details are in the README ("Quote form: Netlify Forms").

> The quote form uses Netlify Forms, so form submissions only work when the site is hosted on Netlify. On Vercel or a static host you'd need to connect a different form service.

## 2C. Any static host (Cloudflare Pages, GitHub Pages, S3, cPanel…)

```bash
STATIC_EXPORT=true npm run build     # outputs plain HTML/CSS/JS to /out
```

Upload the contents of `/out` to your host. On Windows PowerShell, use `$env:STATIC_EXPORT="true"; npm run build`.
Configure your host to serve `404.html` for unknown paths. Most hosts do this automatically.

---

## 3. Choose and buy a domain

Nothing has been registered for you. Here are some ideas. **Availability is not guaranteed, so check each one at a registrar** (Cloudflare Registrar, Namecheap, Porkbun, Google/Squarespace Domains, GoDaddy, etc.):

- `thaylonwebstudio.com` ← best match for the brand
- `thaylonstudio.com`
- `thaylonweb.com`
- `thaylondesign.com`
- `buildwiththaylon.com`
- `thaylonwebdesign.com`

Tips: choose the `.com`, avoid hyphens, and turn on WHOIS privacy and auto-renew. A professional email on the same domain (for example `hello@thaylonwebstudio.com`, through Google Workspace, Zoho Mail or your registrar's email service) builds a lot of trust.

---

## 4. Connect the custom domain

### Vercel

1. Go to **Project → Settings → Domains → Add** and enter `yourdomain.com`. When Vercel offers to add `www.yourdomain.com` with a redirect, accept.
2. Vercel shows the exact DNS records to create. **Use the values shown in your dashboard.** Newer projects receive project-specific values. The records are typically:

   | Type | Name / Host | Value |
   | --- | --- | --- |
   | `A` | `@` | the IPv4 address Vercel shows (historically `76.76.21.21`) |
   | `CNAME` | `www` | the CNAME target Vercel shows (historically `cname.vercel-dns.com`) |

3. Add those records at your registrar's DNS settings, and remove any old `A`/`AAAA` records on `@` or `www` that conflict.
4. *Alternative:* switch your registrar's nameservers to Vercel's (`ns1.vercel-dns.com`, `ns2.vercel-dns.com`) and let Vercel manage DNS.

### Netlify

1. Go to **Domain management → Add a domain** and enter `yourdomain.com`.
2. Using external DNS at your registrar:

   | Type | Name / Host | Value |
   | --- | --- | --- |
   | `A` | `@` | `75.2.60.5` (Netlify's load balancer; confirm in your dashboard) |
   | `CNAME` | `www` | `<your-site-name>.netlify.app` |

3. *Alternative:* use **Netlify DNS** by switching your nameservers to the four Netlify nameservers shown in the dashboard.

### Keep email working
If you use email on the domain, **don't touch your `MX`, `TXT` (SPF/DKIM/DMARC) records** when changing the website records.

### Propagation
DNS changes usually take a few minutes, but can take up to 48 hours. You can check progress at <https://dnschecker.org>.

---

## 5. HTTPS

Both Vercel and Netlify **issue and renew free SSL certificates automatically** (Let's Encrypt) as soon as DNS points to them. You don't need to do anything else.

- Wait until the dashboard shows the domain as **Valid / Verified** and the certificate as issued.
- Vercel and Netlify redirect HTTP → HTTPS automatically.
- If you have a `CAA` DNS record, make sure it allows `letsencrypt.org`.
- If you use Cloudflare as a DNS proxy in front of Vercel or Netlify, set SSL mode to **Full (strict)**. Otherwise, set those records to "DNS only".

---

## 6. Final launch checklist

- [ ] `NEXT_PUBLIC_AGENCY_DOMAIN` set to your real domain, and the site redeployed (this fixes canonical URLs, sitemap and OG tags)
- [ ] `NEXT_PUBLIC_AGENCY_EMAIL` set to your professional email
- [ ] Netlify form detection enabled, `thaylon-quote-request` listed under Forms, email notification added (and confirmed), test submission received
- [ ] Legal placeholders in Privacy Policy and Terms completed (and reviewed by an attorney)
- [ ] Timelines, payment terms and response times reviewed (see README)
- [ ] Social links added (or left empty to hide)
- [ ] Visited `https://yourdomain.com/sitemap.xml`, then submitted it in **Google Search Console** (verify the domain with a DNS TXT record)
- [ ] Shared a page on social media / [opengraph.xyz](https://www.opengraph.xyz) to check the preview image
- [ ] Optional: create a **Google Business Profile** as a service-area business (no public address required)

---

## Troubleshooting

| Symptom | Fix |
| --- | --- |
| Form shows "could not be sent" | Form detection is off or the deploy happened before it was enabled. Enable it under Forms, then redeploy. Check that `public/__forms.html` is deployed (`/__forms.html` returns 200) |
| No notification emails | Add one under Forms → Submission notifications, and confirm the address if Netlify asks. Check the Spam submissions list |
| Sitemap shows `localhost` or `*.netlify.app` URLs | Set `NEXT_PUBLIC_AGENCY_DOMAIN`, then redeploy |
| Domain shows "Invalid Configuration" | DNS records don't match the dashboard values, an old conflicting record exists, or propagation is still in progress |
| Certificate pending for hours | Check for a conflicting `AAAA` record or a restrictive `CAA` record |
| Build fails on host | Make sure Node 18.18+ is used (20 recommended). `.nvmrc` and `netlify.toml` pin Node 20 |
